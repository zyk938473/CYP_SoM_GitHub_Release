# Figure release scope and numbering

Released image files correspond directly to the completed supplementary items:

- `FigureS4A`–`FigureS4D`: Stage 11 protein-pairing and Stage 12 retrieval-ranking paired forest plots.
- `FigureS5A`–`FigureS5D`: identity × molecule-similarity applicability maps for G00, G01, G10 and G11.
- `FigureS5E`–`FigureS5H`: identity × MCS-coverage applicability maps for G00, G01, G10 and G11.

Main Figure 1–6 layout files and incomplete supplementary composites are not included here. Figure S8 fixed-case images and row-level provenance are also withheld because they disclose individual source-derived examples. Exact released-file hashes are listed in `MANIFEST_SHA256.tsv`.
