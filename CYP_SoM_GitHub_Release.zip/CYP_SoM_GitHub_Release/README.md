# CYP SoM Applicability Domain

Code and aggregate artifacts for **Mapping the Applicability Domain of Protein Signals in CYP Site-of-Metabolism Prediction: A Dual-OOD Benchmark with Reliability-Aware Retrieval**.

## Repository contents

- `src/` and `scripts/` — final analysis code.
- `configs/final_protocol.yaml` — frozen protocol configuration.
- `tests/` — synthetic unit tests.
- `manifests/frozen_splits/` — minimal frozen-split manifests and checksums of withheld assignments.
- `results/figure_source_data/` — aggregate source data numbered to match the manuscript.
- `results/statistics/` — final cluster-aware paired summaries.
- `figures/supplementary/` — final vector supplementary figures S4 and S5.

## Endpoint and statistical unit

The primary endpoint is `ANY_OBSERVED_SITE_UNION`. Unreported candidate bonds are operational non-positives under the collected-evidence endpoint and are not experimentally confirmed inactive bonds. Metrics use reaction-equal weighting. Five frozen outer splits are the primary evaluation replicates; five optimization seeds per split are not treated as independent biological samples.

## Data access

This repository intentionally excludes row-level benchmark tables, protein sequences, molecular records, split assignment rows, retrieval banks, MCS mappings and fixed-case provenance. Obtain source data from their official providers and follow the restrictions in `DATA_AVAILABILITY.md`.

## Installation

```bash
python -m venv .venv
python -m pip install -e ".[dev]"
pytest -q
```

Optional neural training dependencies: `python -m pip install -e ".[train]"`.

## Integrity

`MANIFEST_SHA256.tsv` records path, size and SHA256 for every released file. Exact hashes of frozen but withheld split assignment files are in `manifests/frozen_splits/FROZEN_ASSIGNMENT_CHECKSUMS.tsv`.

## License

Original repository code is released under the MIT License; see `LICENSE`. Third-party data and provider-governed artifacts are not covered by the MIT License and remain subject to their original terms.
