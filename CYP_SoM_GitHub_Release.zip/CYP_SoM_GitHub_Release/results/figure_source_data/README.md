# Figure and table source-data numbering

Names follow the captions in `CYP_R1.docx`: Figure 2A–D, Figure 3A–C, Figure 4A–B and Figure 5A–C. `Table2_benchmark_composition_and_support.csv` corresponds to manuscript Table 2. Figure 1 data provide aggregate support for the dual-OOD matrix within the workflow figure. Figure 6 source data are excluded because they contain row-level fixed-case records.
