from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from rdkit import Chem

ATOM_NUMBERS = [1, 6, 7, 8, 9, 15, 16, 17, 35, 53]
HYBRIDIZATIONS = [
    Chem.HybridizationType.S,
    Chem.HybridizationType.SP,
    Chem.HybridizationType.SP2,
    Chem.HybridizationType.SP3,
    Chem.HybridizationType.SP3D,
    Chem.HybridizationType.SP3D2,
]
ATOM_FEATURE_DIM = 39
BOND_FEATURE_DIM = 4


@dataclass
class GraphSample:
    reaction_id: str
    molecule_key: str
    bond_idx: int
    atom_features: np.ndarray
    edge_index: np.ndarray
    edge_features: np.ndarray
    target_bond: tuple[int, int]
    target_bond_feature: np.ndarray
    label: int


def one_hot(value: object, choices: list[object]) -> list[float]:
    return [float(value == choice) for choice in choices] + [float(value not in choices)]


def _atom_features(atom: Chem.Atom) -> list[float]:
    return (
        one_hot(atom.GetAtomicNum(), ATOM_NUMBERS)
        + one_hot(min(atom.GetTotalDegree(), 5), list(range(6)))
        + one_hot(min(atom.GetTotalNumHs(), 4), list(range(5)))
        + one_hot(max(-2, min(atom.GetFormalCharge(), 2)), list(range(-2, 3)))
        + [float(atom.GetIsAromatic()), float(atom.IsInRing())]
        + one_hot(atom.GetHybridization(), HYBRIDIZATIONS)
    )


def bond_features(bond: Chem.Bond) -> list[float]:
    return [
        float(bond.GetBondTypeAsDouble()) / 3.0,
        float(bond.GetIsAromatic()),
        float(bond.GetIsConjugated()),
        float(bond.IsInRing()),
    ]


def molecule_graph(
    smiles: str,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict[tuple[int, int], np.ndarray]]:
    heavy = Chem.MolFromSmiles(smiles)
    if heavy is None:
        raise ValueError(f"Invalid SMILES: {smiles}")
    molecule = Chem.AddHs(heavy)
    atoms = np.asarray([_atom_features(atom) for atom in molecule.GetAtoms()], dtype=np.float32)
    if atoms.shape[1] != ATOM_FEATURE_DIM:
        raise AssertionError(f"Unexpected atom feature dimension: {atoms.shape[1]}")
    edges: list[tuple[int, int]] = []
    edge_features: list[list[float]] = []
    target_features: dict[tuple[int, int], np.ndarray] = {}
    for bond in molecule.GetBonds():
        begin, end = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
        feature = bond_features(bond)
        edges.extend([(begin, end), (end, begin)])
        edge_features.extend([feature, feature])
        target_features[tuple(sorted((begin, end)))] = np.asarray(feature, dtype=np.float32)
    return (
        atoms,
        np.asarray(edges, dtype=np.int64).T,
        np.asarray(edge_features, dtype=np.float32),
        target_features,
    )


def load_bond_samples_for_reactions(
    bonds_path: str | Path, reaction_ids: set[str]
) -> list[GraphSample]:
    bonds = pd.read_parquet(bonds_path)
    data = bonds[bonds["reaction_id"].isin(reaction_ids) & bonds["atom_mapping_ok"]].copy()
    cache: dict[
        str, tuple[np.ndarray, np.ndarray, np.ndarray, dict[tuple[int, int], np.ndarray]]
    ] = {}
    samples: list[GraphSample] = []
    for row in data.itertuples(index=False):
        if row.molecule not in cache:
            cache[row.molecule] = molecule_graph(row.molecule)
        atoms, edges, edge_features, target_features = cache[row.molecule]
        target_bond = (int(row.atom1_idx), int(row.atom2_idx))
        target_key = tuple(sorted(target_bond))
        if target_key not in target_features:
            raise ValueError(f"Target bond {target_key} missing from graph for {row.reaction_id}")
        samples.append(
            GraphSample(
                reaction_id=row.reaction_id,
                molecule_key=row.molecule,
                bond_idx=int(row.bond_idx),
                atom_features=atoms,
                edge_index=edges,
                edge_features=edge_features,
                target_bond=target_bond,
                target_bond_feature=target_features[target_key],
                label=int(row.label),
            )
        )
    if not samples:
        raise ValueError("No usable bond samples for requested reactions")
    return samples


def load_bond_samples(
    bonds_path: str | Path, splits_path: str | Path, group: str
) -> list[GraphSample]:
    splits = pd.read_parquet(splits_path)
    reaction_ids = set(splits.loc[splits["benchmark_group"].eq(group), "reaction_id"])
    if not reaction_ids:
        raise ValueError(f"No reactions for group={group}")
    return load_bond_samples_for_reactions(bonds_path, reaction_ids)
