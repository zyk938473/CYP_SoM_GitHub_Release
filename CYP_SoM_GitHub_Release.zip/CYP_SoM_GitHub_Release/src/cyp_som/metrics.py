from __future__ import annotations

from collections.abc import Iterable

import numpy as np
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    matthews_corrcoef,
    precision_recall_fscore_support,
    roc_auc_score,
)


def expected_calibration_error(
    y_true: Iterable[int], y_score: Iterable[float], bins: int = 15
) -> float:
    truth = np.asarray(list(y_true), dtype=float)
    scores = np.asarray(list(y_score), dtype=float)
    edges = np.linspace(0.0, 1.0, bins + 1)
    assignments = np.clip(np.digitize(scores, edges[1:-1], right=False), 0, bins - 1)
    error = 0.0
    for bin_index in range(bins):
        mask = assignments == bin_index
        if mask.any():
            error += mask.mean() * abs(truth[mask].mean() - scores[mask].mean())
    return float(error)


def binary_metrics(
    y_true: Iterable[int], y_score: Iterable[float], threshold: float = 0.5
) -> dict[str, float]:
    truth = np.asarray(list(y_true), dtype=int)
    scores = np.asarray(list(y_score), dtype=float)
    prediction = (scores >= threshold).astype(int)
    precision, recall, f1, _ = precision_recall_fscore_support(
        truth, prediction, average="binary", zero_division=0
    )
    return {
        "mcc": float(matthews_corrcoef(truth, prediction)),
        "pr_auc": float(average_precision_score(truth, scores)),
        "roc_auc": float(roc_auc_score(truth, scores))
        if len(np.unique(truth)) == 2
        else float("nan"),
        "precision": float(precision),
        "recall": float(recall),
        "f1": float(f1),
        "brier": float(brier_score_loss(truth, scores)),
        "ece_15": expected_calibration_error(truth, scores, bins=15),
        "prevalence": float(truth.mean()),
    }


def best_mcc_threshold(y_true: Iterable[int], y_score: Iterable[float]) -> tuple[float, float]:
    truth = np.asarray(list(y_true), dtype=int)
    scores = np.asarray(list(y_score), dtype=float)
    candidates = np.unique(np.quantile(scores, np.linspace(0, 1, 201)))
    results = [
        (threshold, matthews_corrcoef(truth, scores >= threshold)) for threshold in candidates
    ]
    threshold, mcc = max(results, key=lambda item: item[1])
    return float(threshold), float(mcc)
