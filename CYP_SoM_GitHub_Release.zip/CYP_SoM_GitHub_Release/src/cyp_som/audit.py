from __future__ import annotations

from pathlib import Path

import pandas as pd

from .utils import write_json


def audit_processed(processed_dir: str | Path, report_dir: str | Path) -> dict[str, object]:
    source = Path(processed_dir)
    target = Path(report_dir)
    target.mkdir(parents=True, exist_ok=True)
    reactions = pd.read_parquet(source / "reactions.parquet")
    bonds = pd.read_parquet(source / "candidate_bonds.parquet")

    pair_conflicts = (
        reactions.groupby("pair_id")["positive_bonds"]
        .nunique()
        .loc[lambda series: series > 1]
        .sort_values(ascending=False)
    )
    released_overlap = {}
    for entity in ("sequence_hash", "inchikey", "scaffold", "pair_id"):
        sets = {split: set(group[entity]) for split, group in reactions.groupby("released_split")}
        released_overlap[entity] = {
            f"{a}__{b}": len(sets[a].intersection(sets[b]))
            for index, a in enumerate(sorted(sets))
            for b in sorted(sets)[index + 1 :]
        }

    report = {
        "reaction_records": len(reactions),
        "candidate_bonds": len(bonds),
        "positive_prevalence": float(bonds["label"].mean()),
        "pair_label_conflicts": len(pair_conflicts),
        "released_split_overlap": released_overlap,
        "proteins_per_reaction_quantiles": reactions.groupby("sequence_hash")
        .size()
        .quantile([0, 0.25, 0.5, 0.75, 1])
        .to_dict(),
        "molecules_per_reaction_quantiles": reactions.groupby("inchikey")
        .size()
        .quantile([0, 0.25, 0.5, 0.75, 1])
        .to_dict(),
    }
    pair_conflicts.rename("distinct_site_sets").to_csv(target / "pair_label_conflicts.csv")
    write_json(report, target / "audit.json")
    return report
