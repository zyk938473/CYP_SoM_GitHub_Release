from __future__ import annotations

import re
from dataclasses import dataclass

from rdkit import Chem
from rdkit.Chem.MolStandardize import rdMolStandardize


@dataclass(frozen=True)
class CanonicalSite:
    key: str
    kind: str
    atom_indices: tuple[int, ...]
    bond_indices: tuple[int, ...]


@dataclass
class SiteContext:
    molecule: Chem.Mol
    raw_explicit: Chem.Mol
    raw_to_standard: dict[int, int]
    canonical_classes: dict[int, int]
    enumerate_equivalents: bool


def _inchi_canonical_classes(molecule: Chem.Mol) -> dict[int, int]:
    _, aux_info = Chem.MolToInchiAndAuxInfo(molecule)
    match = re.search(r"/N:([^/]+)", aux_info)
    if match is None:
        raise ValueError("InChI AuxInfo lacks canonical atom numbering")
    original_atom_order = [int(value) for value in re.findall(r"\d+", match.group(1).split(";")[0])]
    if len(original_atom_order) != molecule.GetNumAtoms():
        raise ValueError(
            f"InChI canonical numbering covers {len(original_atom_order)} of "
            f"{molecule.GetNumAtoms()} atoms"
        )
    classes = {
        original_atom_number - 1: canonical_number
        for canonical_number, original_atom_number in enumerate(original_atom_order, start=1)
    }
    equivalence_match = re.search(r"/E:([^/]+)", aux_info)
    if equivalence_match:
        for encoded_group in re.findall(r"\(([^)]+)\)", equivalence_match.group(1)):
            canonical_numbers = [int(value) for value in re.findall(r"\d+", encoded_group)]
            if not canonical_numbers:
                continue
            representative = min(canonical_numbers)
            for atom_index, canonical_number in list(classes.items()):
                if canonical_number in canonical_numbers:
                    classes[atom_index] = representative
    return classes


def build_site_context(smiles: str, enumerate_equivalents: bool = True) -> SiteContext:
    raw = Chem.MolFromSmiles(smiles)
    if raw is None:
        raise ValueError(f"Invalid SMILES: {smiles}")
    mapped = Chem.Mol(raw)
    for atom in mapped.GetAtoms():
        atom.SetAtomMapNum(atom.GetIdx() + 1)

    standard = rdMolStandardize.Cleanup(mapped)
    Chem.SanitizeMol(standard)
    standard = rdMolStandardize.FragmentParent(standard, skipStandardize=True)
    Chem.SanitizeMol(standard)
    standard = rdMolStandardize.Uncharger().uncharge(standard)
    Chem.SanitizeMol(standard)

    raw_to_standard: dict[int, int] = {}
    for atom in standard.GetAtoms():
        atom_map = atom.GetAtomMapNum()
        if atom_map:
            raw_to_standard[atom_map - 1] = atom.GetIdx()
        atom.SetAtomMapNum(0)
    return SiteContext(
        molecule=standard,
        raw_explicit=Chem.AddHs(raw),
        raw_to_standard=raw_to_standard,
        canonical_classes=_inchi_canonical_classes(standard),
        enumerate_equivalents=enumerate_equivalents,
    )


def _descriptor(context: SiteContext, standard_index: int) -> tuple[int, int]:
    atom = context.molecule.GetAtomWithIdx(standard_index)
    return atom.GetAtomicNum(), context.canonical_classes[standard_index]


def canonicalize_bond_site(context: SiteContext, atom1_idx: int, atom2_idx: int) -> CanonicalSite:
    explicit = context.raw_explicit
    if min(atom1_idx, atom2_idx) < 0 or max(atom1_idx, atom2_idx) >= explicit.GetNumAtoms():
        raise IndexError(f"Candidate endpoints outside explicit molecule: {atom1_idx}, {atom2_idx}")
    atom1 = explicit.GetAtomWithIdx(atom1_idx)
    atom2 = explicit.GetAtomWithIdx(atom2_idx)
    if explicit.GetBondBetweenAtoms(atom1_idx, atom2_idx) is None:
        raise ValueError(f"Candidate endpoints are not bonded: {atom1_idx}, {atom2_idx}")

    hydrogen_flags = (atom1.GetAtomicNum() == 1, atom2.GetAtomicNum() == 1)
    if hydrogen_flags == (True, True):
        raise ValueError("H-H metabolic candidate is unsupported")
    if any(hydrogen_flags):
        heavy_raw = atom2_idx if hydrogen_flags[0] else atom1_idx
        if heavy_raw not in context.raw_to_standard:
            raise ValueError("Heavy atom was removed during fragment standardization")
        heavy_standard = context.raw_to_standard[heavy_raw]
        atomic_number, canonical_class = _descriptor(context, heavy_standard)
        equivalent_atoms = (
            tuple(
                index
                for index in range(context.molecule.GetNumAtoms())
                if _descriptor(context, index) == (atomic_number, canonical_class)
            )
            if context.enumerate_equivalents
            else (heavy_standard,)
        )
        return CanonicalSite(
            key=f"H3|Z{atomic_number}|C{canonical_class}",
            kind="heavy_hydrogen",
            atom_indices=equivalent_atoms,
            bond_indices=(),
        )

    if atom1_idx not in context.raw_to_standard or atom2_idx not in context.raw_to_standard:
        raise ValueError("Bond atom was removed during fragment standardization")
    standard1 = context.raw_to_standard[atom1_idx]
    standard2 = context.raw_to_standard[atom2_idx]
    descriptor1 = _descriptor(context, standard1)
    descriptor2 = _descriptor(context, standard2)
    left, right = sorted((descriptor1, descriptor2))
    key = f"B3|Z{left[0]}C{left[1]}|Z{right[0]}C{right[1]}"

    matching_bonds = []
    matching_atoms = set()
    if context.enumerate_equivalents:
        for bond in context.molecule.GetBonds():
            begin = _descriptor(context, bond.GetBeginAtomIdx())
            end = _descriptor(context, bond.GetEndAtomIdx())
            if sorted((begin, end)) == [left, right]:
                matching_bonds.append(bond.GetIdx())
                matching_atoms.update((bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()))
    else:
        bond = context.molecule.GetBondBetweenAtoms(standard1, standard2)
        if bond is not None:
            matching_bonds.append(bond.GetIdx())
            matching_atoms.update((standard1, standard2))
    return CanonicalSite(
        key=key,
        kind="heavy_heavy",
        atom_indices=tuple(sorted(matching_atoms)),
        bond_indices=tuple(sorted(matching_bonds)),
    )
