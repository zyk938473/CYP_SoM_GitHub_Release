from __future__ import annotations

import copy
import random
from collections import defaultdict
from typing import Any

import numpy as np

from .gnn import require_torch
from .graph_data import GraphSample
from .metrics import binary_metrics


def group_by_reaction(samples: list[GraphSample]) -> list[list[GraphSample]]:
    groups: dict[str, list[GraphSample]] = defaultdict(list)
    for sample in samples:
        groups[sample.reaction_id].append(sample)
    return list(groups.values())


def reaction_tensors(group: list[GraphSample], device: Any):
    torch, _ = require_torch()
    first = group[0]
    atoms = torch.as_tensor(first.atom_features, dtype=torch.float32, device=device)
    edges = torch.as_tensor(first.edge_index, dtype=torch.long, device=device)
    edge_features = torch.as_tensor(first.edge_features, dtype=torch.float32, device=device)
    targets = torch.as_tensor(
        [sample.target_bond for sample in group], dtype=torch.long, device=device
    )
    target_features = torch.as_tensor(
        np.stack([sample.target_bond_feature for sample in group]),
        dtype=torch.float32,
        device=device,
    )
    labels = torch.as_tensor([sample.label for sample in group], dtype=torch.float32, device=device)
    return atoms, edges, edge_features, targets, target_features, labels


def predict_reactions(
    model: Any,
    groups: list[list[GraphSample]],
    device: Any,
    protein_embeddings: dict[str, np.ndarray] | None = None,
    reaction_to_sequence: dict[str, str] | None = None,
) -> tuple[np.ndarray, np.ndarray, list[tuple[str, int]]]:
    torch, _ = require_torch()
    model.eval()
    probabilities: list[float] = []
    labels: list[int] = []
    identifiers: list[tuple[str, int]] = []
    with torch.inference_mode():
        for group in groups:
            atoms, edges, edge_features, targets, target_features, truth = reaction_tensors(
                group, device
            )
            protein = None
            if protein_embeddings is not None:
                if reaction_to_sequence is None:
                    raise ValueError("reaction_to_sequence is required with protein embeddings")
                sequence_hash = reaction_to_sequence[group[0].reaction_id]
                protein = torch.as_tensor(
                    protein_embeddings[sequence_hash], dtype=torch.float32, device=device
                )
            node = model.encode(atoms, edges, edge_features)
            logits = model.predict_bonds(node, targets, target_features, protein)
            probabilities.extend(torch.sigmoid(logits).cpu().tolist())
            labels.extend(truth.cpu().to(dtype=torch.int64).tolist())
            identifiers.extend((sample.reaction_id, sample.bond_idx) for sample in group)
    return np.asarray(labels, dtype=int), np.asarray(probabilities), identifiers


def train_epochs(
    model: Any,
    groups: list[list[GraphSample]],
    device: Any,
    epochs: int,
    learning_rate: float,
    positive_weight: float,
    protein_embeddings: dict[str, np.ndarray] | None = None,
    reaction_to_sequence: dict[str, str] | None = None,
) -> Any:
    torch, _ = require_torch()
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=1e-4)
    loss_fn = torch.nn.BCEWithLogitsLoss(
        pos_weight=torch.tensor(positive_weight, dtype=torch.float32, device=device),
        reduction="mean",
    )
    for _ in range(epochs):
        model.train()
        random.shuffle(groups)
        for group in groups:
            atoms, edges, edge_features, targets, target_features, labels = reaction_tensors(
                group, device
            )
            protein = None
            if protein_embeddings is not None:
                if reaction_to_sequence is None:
                    raise ValueError("reaction_to_sequence is required with protein embeddings")
                protein = torch.as_tensor(
                    protein_embeddings[reaction_to_sequence[group[0].reaction_id]],
                    dtype=torch.float32,
                    device=device,
                )
            optimizer.zero_grad(set_to_none=True)
            node = model.encode(atoms, edges, edge_features)
            logits = model.predict_bonds(node, targets, target_features, protein)
            loss_fn(logits, labels).backward()
            optimizer.step()
    return model


def select_epoch_on_inner_fold(
    model: Any,
    train_groups: list[list[GraphSample]],
    validation_groups: list[list[GraphSample]],
    device: Any,
    maximum_epochs: int,
    learning_rate: float,
    positive_weight: float,
    patience: int,
    protein_embeddings: dict[str, np.ndarray] | None = None,
    reaction_to_sequence: dict[str, str] | None = None,
) -> tuple[int, Any, np.ndarray, np.ndarray, list[tuple[str, int]]]:
    torch, _ = require_torch()
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=1e-4)
    loss_fn = torch.nn.BCEWithLogitsLoss(
        pos_weight=torch.tensor(positive_weight, dtype=torch.float32, device=device)
    )
    best_epoch = 1
    best_pr_auc = -np.inf
    best_state = copy.deepcopy(model.state_dict())
    best_truth = np.asarray([], dtype=int)
    best_scores = np.asarray([], dtype=float)
    best_identifiers: list[tuple[str, int]] = []
    stale = 0
    for epoch in range(1, maximum_epochs + 1):
        model.train()
        random.shuffle(train_groups)
        for group in train_groups:
            atoms, edges, edge_features, targets, target_features, labels = reaction_tensors(
                group, device
            )
            protein = None
            if protein_embeddings is not None:
                if reaction_to_sequence is None:
                    raise ValueError("reaction_to_sequence is required with protein embeddings")
                protein = torch.as_tensor(
                    protein_embeddings[reaction_to_sequence[group[0].reaction_id]],
                    dtype=torch.float32,
                    device=device,
                )
            optimizer.zero_grad(set_to_none=True)
            node = model.encode(atoms, edges, edge_features)
            loss_fn(model.predict_bonds(node, targets, target_features, protein), labels).backward()
            optimizer.step()
        truth, scores, identifiers = predict_reactions(
            model,
            validation_groups,
            device,
            protein_embeddings,
            reaction_to_sequence,
        )
        pr_auc = binary_metrics(truth, scores)["pr_auc"]
        if pr_auc > best_pr_auc:
            best_pr_auc = pr_auc
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
            best_truth = truth
            best_scores = scores
            best_identifiers = identifiers
            stale = 0
        else:
            stale += 1
        if stale >= patience:
            break
    model.load_state_dict(best_state)
    return best_epoch, model, best_truth, best_scores, best_identifiers
