from __future__ import annotations

import numpy as np


def aggregate_neighbor_predictions(
    base_prediction: np.ndarray,
    neighbor_predictions: np.ndarray,
    similarities: np.ndarray,
    gate: float,
    temperature: float = 0.1,
) -> np.ndarray:
    if neighbor_predictions.ndim != 2:
        raise ValueError("neighbor_predictions must have shape [K, candidate_sites]")
    if len(similarities) != len(neighbor_predictions):
        raise ValueError("One similarity is required per neighbor")
    centered = similarities - similarities.max()
    weights = np.exp(centered / max(temperature, 1e-8))
    weights /= weights.sum()
    retrieved = np.sum(neighbor_predictions * weights[:, None], axis=0)
    bounded_gate = float(np.clip(gate, 0.0, 1.0))
    return (1.0 - bounded_gate) * base_prediction + bounded_gate * retrieved
