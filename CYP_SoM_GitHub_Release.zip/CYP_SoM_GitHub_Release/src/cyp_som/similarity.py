from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd
from Bio import Align


def _aligner() -> Align.PairwiseAligner:
    aligner = Align.PairwiseAligner()
    aligner.mode = "global"
    aligner.match_score = 1.0
    aligner.mismatch_score = 0.0
    aligner.open_gap_score = -1.0
    aligner.extend_gap_score = -0.1
    return aligner


def _identity_batch(
    payload: tuple[list[str], list[tuple[int, int]]],
) -> list[tuple[int, int, float]]:
    sequences, pairs = payload
    aligner = _aligner()
    output = []
    for i, j in pairs:
        counts = aligner.align(sequences[i], sequences[j])[0].counts()
        denominator = counts.aligned + counts.gaps
        identity = counts.identities / denominator if denominator else 0.0
        output.append((i, j, float(identity)))
    return output


def global_identity_matrix(
    proteins_path: str | Path,
    output_path: str | Path,
    workers: int = 8,
    batch_size: int = 1000,
) -> np.ndarray:
    proteins = pd.read_parquet(proteins_path).sort_values("sequence_hash").reset_index(drop=True)
    sequences = proteins["protein_sequence"].tolist()
    count = len(sequences)
    matrix = np.eye(count, dtype=np.float32)
    pairs = [(i, j) for i in range(count) for j in range(i + 1, count)]
    batches = [
        (sequences, pairs[start : start + batch_size]) for start in range(0, len(pairs), batch_size)
    ]
    with ProcessPoolExecutor(max_workers=workers) as executor:
        for result in executor.map(_identity_batch, batches):
            for i, j, identity in result:
                matrix[i, j] = matrix[j, i] = identity
    target = Path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(target, identity=matrix, sequence_hash=proteins["sequence_hash"].to_numpy())
    return matrix
