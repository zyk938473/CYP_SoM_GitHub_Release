from __future__ import annotations

import html
import json
from collections import Counter
from pathlib import Path

import pandas as pd
from rdkit.Chem.Draw import rdMolDraw2D

from .sites import CanonicalSite, build_site_context, canonicalize_bond_site
from .utils import write_json


def _relation(site_sets: list[frozenset[str]]) -> str:
    unique = list(dict.fromkeys(site_sets))
    if len(unique) <= 1:
        return "IDENTICAL"
    if all(left <= right or right <= left for left in unique for right in unique):
        return "SUBSET_CHAIN"
    common = set.intersection(*(set(values) for values in unique))
    if common:
        return "PARTIAL_OVERLAP"
    return "DISJOINT"


def _recommendation(relation: str, mapping_errors: int) -> tuple[str, str, bool]:
    if mapping_errors:
        return "MAPPING_REVIEW", "medium", False
    if relation == "IDENTICAL":
        return "MERGE_IDENTICAL", "high", True
    if relation == "SUBSET_CHAIN":
        return "EVIDENCE_REVIEW_BEFORE_UNION", "medium", False
    if relation == "PARTIAL_OVERLAP":
        return "PRODUCT_OR_CONDITION_REVIEW", "low", False
    return "SOURCE_REVIEW_OR_EXCLUDE_PRIMARY", "low", False


def _draw_svg(smiles: str, sites: list[CanonicalSite], legend: str) -> str:
    context = build_site_context(smiles)
    drawer = rdMolDraw2D.MolDraw2DSVG(520, 360)
    options = drawer.drawOptions()
    options.addAtomIndices = True
    highlight_atoms = sorted({index for site in sites for index in site.atom_indices})
    highlight_bonds = sorted({index for site in sites for index in site.bond_indices})
    drawer.DrawMolecule(
        context.molecule,
        legend=legend,
        highlightAtoms=highlight_atoms,
        highlightBonds=highlight_bonds,
    )
    drawer.FinishDrawing()
    return drawer.GetDrawingText()


def curate_site_discrepancies(
    bonds_path: str | Path,
    reactions_path: str | Path,
    output_dir: str | Path,
) -> dict[str, object]:
    bonds = pd.read_parquet(bonds_path)
    reactions = pd.read_parquet(reactions_path)
    target = Path(output_dir)
    cards_dir = target / "cards"
    cards_dir.mkdir(parents=True, exist_ok=True)

    reaction_to_pair = reactions.set_index("reaction_id")["pair_id"].to_dict()
    positives = bonds[bonds["label"] == 1].copy()
    positives["pair_id"] = positives["reaction_id"].map(reaction_to_pair)
    raw_sets = positives.groupby("reaction_id")["bond_idx"].agg(
        lambda values: tuple(sorted(set(values)))
    )
    reaction_counts = reactions.groupby("pair_id")["reaction_id"].nunique()
    raw_unique_counts = (
        reactions.assign(raw_set=reactions["reaction_id"].map(raw_sets))
        .groupby("pair_id")["raw_set"]
        .nunique(dropna=False)
    )
    candidate_pairs = set(raw_unique_counts[raw_unique_counts > 1].index)

    detailed_rows: list[dict[str, object]] = []
    pair_rows: list[dict[str, object]] = []
    html_sections = []
    for pair_id in sorted(candidate_pairs):
        pair_reactions = reactions[reactions["pair_id"] == pair_id].copy()
        reaction_sites: dict[str, frozenset[str]] = {}
        reaction_site_objects: dict[str, list[CanonicalSite]] = {}
        reaction_smiles: dict[str, str] = {}
        mapping_errors = 0
        for reaction in pair_reactions.itertuples(index=False):
            all_group = bonds[bonds["reaction_id"] == reaction.reaction_id]
            group = all_group[all_group["label"] == 1]
            source_smiles = str(all_group.iloc[0]["molecule"])
            context_cache = {}
            site_objects: list[CanonicalSite] = []
            errors = []
            for row in group.itertuples(index=False):
                try:
                    if row.molecule not in context_cache:
                        context_cache[row.molecule] = build_site_context(row.molecule)
                    context = context_cache[row.molecule]
                    site_objects.append(
                        canonicalize_bond_site(context, int(row.atom1_idx), int(row.atom2_idx))
                    )
                except (ValueError, IndexError, RuntimeError) as exc:
                    errors.append(str(exc))
            mapping_errors += len(errors)
            site_set = frozenset(site.key for site in site_objects)
            reaction_sites[reaction.reaction_id] = site_set
            reaction_site_objects[reaction.reaction_id] = site_objects
            reaction_smiles[reaction.reaction_id] = source_smiles
            detailed_rows.append(
                {
                    "pair_id": pair_id,
                    "reaction_id": reaction.reaction_id,
                    "protein_name": reaction.protein_name,
                    "sequence_hash": reaction.sequence_hash,
                    "canonical_smiles": reaction.canonical_smiles,
                    "inchikey": reaction.inchikey,
                    "released_split": reaction.released_split,
                    "reaction_site_raw": reaction.reaction_site_raw,
                    "raw_positive_bonds": reaction.positive_bonds,
                    "canonical_site_set": json.dumps(sorted(site_set)),
                    "mapping_errors": " | ".join(errors),
                }
            )

        unique_sets = list(dict.fromkeys(reaction_sites.values()))
        relation = _relation(unique_sets)
        action, confidence, include_primary = _recommendation(relation, mapping_errors)
        first = pair_reactions.iloc[0]
        pair_rows.append(
            {
                "pair_id": pair_id,
                "protein_name": first["protein_name"],
                "sequence_hash": first["sequence_hash"],
                "canonical_smiles": first["canonical_smiles"],
                "inchikey": first["inchikey"],
                "reaction_records": len(pair_reactions),
                "raw_site_sets": int(raw_unique_counts[pair_id]),
                "canonical_site_sets": len(unique_sets),
                "canonical_relation": relation,
                "mapping_error_count": mapping_errors,
                "recommended_action": action,
                "agent_confidence": confidence,
                "include_primary_recommended": include_primary,
                "review_class": "",
                "human_decision": "",
                "reviewer": "",
                "citation_or_accession": "",
                "notes": "",
            }
        )

        card_parts = [
            f"<h2>{html.escape(pair_id)} — {html.escape(str(first['protein_name']))}</h2>",
            (
                f"<p><b>Relation:</b> {relation}; <b>recommendation:</b> {action}; "
                f"<b>confidence:</b> {confidence}</p>"
            ),
            (
                f"<p><code>{html.escape(str(first['canonical_smiles']))}</code><br>"
                f"InChIKey: {html.escape(str(first['inchikey']))}</p>"
            ),
        ]
        for reaction in pair_reactions.itertuples(index=False):
            sites = reaction_site_objects[reaction.reaction_id]
            legend = f"{reaction.reaction_id} | {reaction.released_split} | {sorted(reaction_sites[reaction.reaction_id])}"
            try:
                svg = _draw_svg(reaction_smiles[reaction.reaction_id], sites, legend)
            except (ValueError, RuntimeError) as exc:
                svg = f"<pre>Drawing failed: {html.escape(str(exc))}</pre>"
            card_parts.append(svg)
        section = "\n".join(card_parts)
        (cards_dir / f"{pair_id}.html").write_text(
            "<html><meta charset='utf-8'><body>" + section + "</body></html>", encoding="utf-8"
        )
        html_sections.append(section)

    detail = pd.DataFrame(detailed_rows)
    pairs = pd.DataFrame(pair_rows)
    detail.to_csv(target / "pair_site_conflicts_detailed.csv", index=False)
    detail.to_parquet(target / "pair_site_conflicts_detailed.parquet", index=False)
    pairs.to_csv(target / "pair_review_queue.csv", index=False)
    (target / "review_cards.html").write_text(
        "<html><meta charset='utf-8'><style>svg{border:1px solid #ccc;margin:8px}</style><body>"
        + "<h1>CYP–molecule site discrepancy review cards</h1>"
        + "<hr>".join(html_sections)
        + "</body></html>",
        encoding="utf-8",
    )
    summary = {
        "raw_candidate_pairs": len(candidate_pairs),
        "reaction_records": int(reaction_counts.loc[list(candidate_pairs)].sum()),
        "relation_counts": dict(Counter(pairs["canonical_relation"])),
        "recommendation_counts": dict(Counter(pairs["recommended_action"])),
        "mapping_error_pairs": int((pairs["mapping_error_count"] > 0).sum()),
        "automatically_mergeable_pairs": int(
            (pairs["recommended_action"] == "MERGE_IDENTICAL").sum()
        ),
        "human_review_pairs": int((~pairs["include_primary_recommended"]).sum()),
    }
    write_json(summary, target / "pair_site_conflict_summary.json")
    return summary
