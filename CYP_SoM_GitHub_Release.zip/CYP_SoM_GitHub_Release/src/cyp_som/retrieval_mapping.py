from __future__ import annotations

import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit.Chem import rdFMCS


def _candidate_lookup(
    frame: pd.DataFrame, heavy_atoms: int
) -> tuple[dict[tuple[int, int], int], dict[int, list[int]]]:
    heavy_bonds: dict[tuple[int, int], int] = {}
    hydrogen_sites: dict[int, list[int]] = {}
    for row in frame.itertuples(index=False):
        first, second = int(row.atom1_idx), int(row.atom2_idx)
        if first < heavy_atoms and second < heavy_atoms:
            heavy_bonds[tuple(sorted((first, second)))] = int(row.label)
        elif (first < heavy_atoms) != (second < heavy_atoms):
            parent = first if first < heavy_atoms else second
            hydrogen_sites.setdefault(parent, []).append(int(row.label))
    return heavy_bonds, hydrogen_sites


def transfer_neighbor_labels(
    train_smiles: str,
    query_smiles: str,
    train_bonds: pd.DataFrame,
    query_bonds: pd.DataFrame,
    minimum_coverage: float = 0.5,
    timeout_seconds: int = 2,
) -> tuple[np.ndarray, np.ndarray, float]:
    """Transfer train labels through heavy-atom MCS; NaN means query site was unmapped."""
    train_molecule = Chem.MolFromSmiles(train_smiles)
    query_molecule = Chem.MolFromSmiles(query_smiles)
    if train_molecule is None or query_molecule is None:
        return np.full(len(query_bonds), np.nan), np.zeros(len(query_bonds)), 0.0
    result = rdFMCS.FindMCS(
        [train_molecule, query_molecule],
        atomCompare=rdFMCS.AtomCompare.CompareElements,
        bondCompare=rdFMCS.BondCompare.CompareOrder,
        ringMatchesRingOnly=True,
        completeRingsOnly=False,
        timeout=timeout_seconds,
    )
    if result.canceled or not result.smartsString:
        return np.full(len(query_bonds), np.nan), np.zeros(len(query_bonds)), 0.0
    pattern = Chem.MolFromSmarts(result.smartsString)
    coverage = min(
        pattern.GetNumAtoms() / max(train_molecule.GetNumAtoms(), 1),
        pattern.GetNumAtoms() / max(query_molecule.GetNumAtoms(), 1),
    )
    if coverage < minimum_coverage:
        return np.full(len(query_bonds), np.nan), np.zeros(len(query_bonds)), float(coverage)
    train_matches = train_molecule.GetSubstructMatches(pattern, uniquify=True, maxMatches=16)
    query_matches = query_molecule.GetSubstructMatches(pattern, uniquify=True, maxMatches=16)
    train_heavy, train_hydrogen = _candidate_lookup(train_bonds, train_molecule.GetNumAtoms())
    values: list[list[float]] = [[] for _ in range(len(query_bonds))]
    for train_match in train_matches:
        for query_match in query_matches:
            query_to_train = dict(zip(query_match, train_match))
            for output_index, row in enumerate(query_bonds.itertuples(index=False)):
                first, second = int(row.atom1_idx), int(row.atom2_idx)
                first_heavy = first < query_molecule.GetNumAtoms()
                second_heavy = second < query_molecule.GetNumAtoms()
                if (
                    first_heavy
                    and second_heavy
                    and first in query_to_train
                    and second in query_to_train
                ):
                    key = tuple(sorted((query_to_train[first], query_to_train[second])))
                    if key in train_heavy:
                        values[output_index].append(float(train_heavy[key]))
                elif first_heavy != second_heavy:
                    parent = first if first_heavy else second
                    if parent in query_to_train and query_to_train[parent] in train_hydrogen:
                        values[output_index].append(
                            float(max(train_hydrogen[query_to_train[parent]]))
                        )
    transferred = np.asarray([np.mean(value) if value else np.nan for value in values])
    ambiguity = np.asarray([len(value) for value in values], dtype=float)
    return transferred, ambiguity, float(coverage)
