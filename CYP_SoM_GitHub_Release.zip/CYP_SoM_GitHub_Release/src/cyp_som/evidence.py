from __future__ import annotations

import re
from pathlib import Path

import pandas as pd
from rdkit import Chem

from .utils import write_json


def _human_cyp_field(protein_name: str) -> str | None:
    match = re.fullmatch(r"Cytochrome P450 ([123]\w+)", str(protein_name))
    return f"CYP{match.group(1)}" if match else None


def map_metacyp_evidence(
    review_queue_path: str | Path,
    metacyp_sdf_dir: str | Path,
    output_dir: str | Path,
) -> dict[str, object]:
    queue = pd.read_csv(review_queue_path)
    records = {}
    property_fields = {
        "Name",
        "InChIKey",
        "PubChem_CID",
        "References",
        "Comments",
        "CYP1A2",
        "CYP2A6",
        "CYP2B6",
        "CYP2C8",
        "CYP2C9",
        "CYP2C19",
        "CYP2D6",
        "CYP2E1",
        "CYP3A4",
    }
    for path in Path(metacyp_sdf_dir).glob("*_smiles.sdf"):
        supplier = Chem.SDMolSupplier(str(path), removeHs=False)
        for molecule in supplier:
            if molecule is None or not molecule.HasProp("InChIKey"):
                continue
            payload = {
                field: molecule.GetProp(field) if molecule.HasProp(field) else ""
                for field in property_fields
            }
            payload["sdf_file"] = path.name
            records[payload["InChIKey"]] = payload

    rows = []
    for row in queue.itertuples(index=False):
        cyp_field = _human_cyp_field(row.protein_name)
        evidence = records.get(row.inchikey, {})
        annotation = evidence.get(cyp_field, "") if cyp_field else ""
        rows.append(
            {
                "pair_id": row.pair_id,
                "protein_name": row.protein_name,
                "inchikey": row.inchikey,
                "metacyp_compound_name": evidence.get("Name", ""),
                "pubchem_cid": evidence.get("PubChem_CID", ""),
                "metacyp_cyp_field": cyp_field or "",
                "metacyp_site_annotation": annotation,
                "references": evidence.get("References", ""),
                "comments": evidence.get("Comments", ""),
                "sdf_file": evidence.get("sdf_file", ""),
                "evidence_match": bool(evidence and annotation),
                "suggested_search_query": f'"{evidence.get("Name", row.inchikey)}" "{row.protein_name}" metabolism',
            }
        )
    output = pd.DataFrame(rows)
    target = Path(output_dir)
    target.mkdir(parents=True, exist_ok=True)
    output.to_csv(target / "metacyp_evidence_matches.csv", index=False)
    summary = {
        "review_pairs": len(output),
        "compound_matches": int((output["metacyp_compound_name"] != "").sum()),
        "cyp_specific_annotation_matches": int(output["evidence_match"].sum()),
        "references_available": int((output["references"] != "").sum()),
        "source_limitation": "CYPMol BoM.csv has no per-reaction citation/condition columns; MetaCYP SDF matching only covers overlapping human CYP records.",
    }
    write_json(summary, target / "source_traceability_summary.json")
    return summary
