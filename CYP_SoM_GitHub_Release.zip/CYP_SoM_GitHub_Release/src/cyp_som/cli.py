from __future__ import annotations

import argparse
import json

from .audit import audit_processed
from .baseline import train_molecule_baseline
from .curation import curate_site_discrepancies
from .datasets import prepare_cypmol_bom
from .evidence import map_metacyp_evidence
from .pair_dataset import build_any_site_pair_dataset
from .similarity import global_identity_matrix
from .splits import build_dual_ood_split


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="cyp-som")
    commands = parser.add_subparsers(dest="command", required=True)

    prepare = commands.add_parser("prepare-cypmol", help="Prepare CYPMol BoM tables")
    prepare.add_argument("--input", required=True)
    prepare.add_argument("--output", required=True)

    audit = commands.add_parser("audit", help="Audit prepared CYPMol tables")
    audit.add_argument("--processed", required=True)
    audit.add_argument("--report", required=True)

    similarity = commands.add_parser("protein-identity", help="Compute global protein identity")
    similarity.add_argument("--proteins", required=True)
    similarity.add_argument("--output", required=True)
    similarity.add_argument("--workers", type=int, default=8)

    split = commands.add_parser("make-splits", help="Build protein/scaffold dual-OOD splits")
    split.add_argument("--reactions", required=True)
    split.add_argument("--identity", required=True)
    split.add_argument("--output", required=True)
    split.add_argument("--threshold", type=float, default=0.4)
    split.add_argument("--seed", type=int, default=20260829)

    baseline = commands.add_parser("train-molecule-baseline", help="Train the chemistry-only floor")
    baseline.add_argument("--bonds", required=True)
    baseline.add_argument("--splits", required=True)
    baseline.add_argument("--output", required=True)

    curation = commands.add_parser(
        "curate-conflicts", help="Normalize and review site discrepancies"
    )
    curation.add_argument("--bonds", required=True)
    curation.add_argument("--reactions", required=True)
    curation.add_argument("--output", required=True)

    pair_dataset = commands.add_parser(
        "build-any-site-dataset", help="Collapse CYP–molecule records to any-observed-site labels"
    )
    pair_dataset.add_argument("--bonds", required=True)
    pair_dataset.add_argument("--reactions", required=True)
    pair_dataset.add_argument("--output", required=True)

    evidence = commands.add_parser("map-metacyp-evidence", help="Map MetaCYP SDF evidence")
    evidence.add_argument("--queue", required=True)
    evidence.add_argument("--sdf-dir", required=True)
    evidence.add_argument("--output", required=True)
    return parser


def main() -> None:
    args = _parser().parse_args()
    if args.command == "prepare-cypmol":
        result = prepare_cypmol_bom(args.input, args.output)
    elif args.command == "audit":
        result = audit_processed(args.processed, args.report)
    elif args.command == "protein-identity":
        matrix = global_identity_matrix(args.proteins, args.output, workers=args.workers)
        result = {
            "proteins": len(matrix),
            "minimum": float(matrix.min()),
            "maximum": float(matrix.max()),
        }
    elif args.command == "make-splits":
        result = build_dual_ood_split(
            args.reactions, args.identity, args.output, threshold=args.threshold, seed=args.seed
        )
    elif args.command == "train-molecule-baseline":
        result = train_molecule_baseline(args.bonds, args.splits, args.output)
    elif args.command == "curate-conflicts":
        result = curate_site_discrepancies(args.bonds, args.reactions, args.output)
    elif args.command == "build-any-site-dataset":
        result = build_any_site_pair_dataset(args.bonds, args.reactions, args.output)
    elif args.command == "map-metacyp-evidence":
        result = map_metacyp_evidence(args.queue, args.sdf_dir, args.output)
    else:
        raise AssertionError(args.command)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
