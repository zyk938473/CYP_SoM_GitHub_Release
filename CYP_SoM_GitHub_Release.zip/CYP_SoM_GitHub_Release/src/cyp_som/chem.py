from __future__ import annotations

import hashlib
from dataclasses import dataclass

from rdkit import Chem
from rdkit.Chem import AllChem, DataStructs
from rdkit.Chem.MolStandardize import rdMolStandardize
from rdkit.Chem.Scaffolds import MurckoScaffold


@dataclass(frozen=True)
class MoleculeRecord:
    original_smiles: str
    canonical_smiles: str
    inchikey: str
    scaffold_smiles: str
    molecule_hash: str
    heavy_atom_count: int
    explicit_atom_count: int
    explicit_bond_count: int
    original_to_standard: dict[int, int]


def standardize_smiles(
    smiles: object, remove_salts: bool = True, uncharge: bool = True
) -> MoleculeRecord:
    original_smiles = str(smiles).strip()
    original = Chem.MolFromSmiles(original_smiles)
    if original is None:
        raise ValueError(f"RDKit failed to parse SMILES: {original_smiles}")

    # CYPMol enumerates candidate bonds after RDKit AddHs(), so atom indices include
    # explicit hydrogens. Preserve that graph exactly for labels/model input. Build a
    # separate standardized heavy-atom copy only for identity and scaffold grouping.
    explicit = Chem.AddHs(Chem.Mol(original))
    original_to_standard = {atom.GetIdx(): atom.GetIdx() for atom in explicit.GetAtoms()}

    molecule = rdMolStandardize.Cleanup(Chem.Mol(original))
    Chem.SanitizeMol(molecule)
    if remove_salts:
        molecule = rdMolStandardize.FragmentParent(molecule, skipStandardize=True)
        Chem.SanitizeMol(molecule)
    if uncharge:
        molecule = rdMolStandardize.Uncharger().uncharge(molecule)
        Chem.SanitizeMol(molecule)
    canonical_smiles = Chem.MolToSmiles(molecule, canonical=True, isomericSmiles=True)
    inchikey = Chem.MolToInchiKey(molecule)
    scaffold = MurckoScaffold.GetScaffoldForMol(molecule)
    scaffold_smiles = Chem.MolToSmiles(scaffold, canonical=True, isomericSmiles=False)
    molecule_hash = hashlib.sha256(canonical_smiles.encode("utf-8")).hexdigest()
    return MoleculeRecord(
        original_smiles=original_smiles,
        canonical_smiles=canonical_smiles,
        inchikey=inchikey,
        scaffold_smiles=scaffold_smiles or f"SCAFFOLDLESS:{inchikey}",
        molecule_hash=molecule_hash,
        heavy_atom_count=molecule.GetNumAtoms(),
        explicit_atom_count=explicit.GetNumAtoms(),
        explicit_bond_count=explicit.GetNumBonds(),
        original_to_standard=original_to_standard,
    )


def tanimoto(smiles_a: str, smiles_b: str, radius: int = 2, bits: int = 2048) -> float:
    molecule_a = Chem.MolFromSmiles(smiles_a)
    molecule_b = Chem.MolFromSmiles(smiles_b)
    if molecule_a is None or molecule_b is None:
        raise ValueError("Invalid SMILES for Tanimoto calculation")
    fp_a = AllChem.GetMorganGenerator(radius=radius, fpSize=bits).GetFingerprint(molecule_a)
    fp_b = AllChem.GetMorganGenerator(radius=radius, fpSize=bits).GetFingerprint(molecule_b)
    return float(DataStructs.TanimotoSimilarity(fp_a, fp_b))
