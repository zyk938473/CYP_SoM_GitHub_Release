"""CYP SoM applicability-domain benchmark."""

__version__ = "0.1.0"
