from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .utils import write_json


class UnionFind:
    def __init__(self, size: int):
        self.parent = list(range(size))

    def find(self, item: int) -> int:
        while self.parent[item] != item:
            self.parent[item] = self.parent[self.parent[item]]
            item = self.parent[item]
        return item

    def union(self, a: int, b: int) -> None:
        root_a, root_b = self.find(a), self.find(b)
        if root_a != root_b:
            self.parent[root_b] = root_a


def components_from_identity(identity: np.ndarray, threshold: float) -> np.ndarray:
    union_find = UnionFind(len(identity))
    rows, columns = np.where(np.triu(identity >= threshold, k=1))
    for row, column in zip(rows, columns, strict=True):
        union_find.union(int(row), int(column))
    roots = [union_find.find(index) for index in range(len(identity))]
    labels = {root: label for label, root in enumerate(sorted(set(roots)))}
    return np.asarray([labels[root] for root in roots], dtype=int)


def _assign_groups(
    weights: dict[object, int], fractions: tuple[float, float, float], seed: int
) -> dict[object, str]:
    rng = np.random.default_rng(seed)
    items = list(weights)
    rng.shuffle(items)
    items.sort(key=lambda item: weights[item], reverse=True)
    names = ("train", "valid", "test")
    targets = dict(zip(names, np.asarray(fractions) * sum(weights.values()), strict=True))
    loads = dict.fromkeys(names, 0.0)
    assignment = {}
    for item in items:
        split = min(names, key=lambda name: loads[name] / max(targets[name], 1.0))
        assignment[item] = split
        loads[split] += weights[item]
    return assignment


def build_dual_ood_split(
    reactions_path: str | Path,
    identity_path: str | Path,
    output_dir: str | Path,
    threshold: float = 0.4,
    seed: int = 20260829,
) -> dict[str, object]:
    reactions = pd.read_parquet(reactions_path).copy()
    payload = np.load(identity_path, allow_pickle=True)
    matrix = payload["identity"]
    hashes = payload["sequence_hash"].astype(str)
    components = components_from_identity(matrix, threshold)
    protein_component = dict(zip(hashes, components, strict=True))
    reactions["protein_cluster"] = reactions["sequence_hash"].map(protein_component)

    protein_weights = reactions.groupby("protein_cluster").size().to_dict()
    protein_split = _assign_groups(protein_weights, (0.70, 0.15, 0.15), seed)
    reactions["protein_partition"] = reactions["protein_cluster"].map(protein_split)

    scaffold_weights = reactions.groupby("scaffold").size().to_dict()
    scaffold_split = _assign_groups(scaffold_weights, (0.70, 0.15, 0.15), seed + 1)
    reactions["scaffold_partition"] = reactions["scaffold"].map(scaffold_split)

    # Within train scaffolds, hold out exact molecules while retaining another training
    # molecule with the same scaffold. This creates scaffold-ID tests without molecule leakage.
    molecule_partition: dict[str, str] = {}
    rng = np.random.default_rng(seed + 2)
    for scaffold, group in reactions[reactions["scaffold_partition"] == "train"].groupby(
        "scaffold"
    ):
        molecules = sorted(group["inchikey"].unique())
        rng.shuffle(molecules)
        if len(molecules) >= 3:
            molecule_partition[molecules[0]] = "test_id"
            molecule_partition[molecules[1]] = "valid_id"
            for molecule in molecules[2:]:
                molecule_partition[molecule] = "train"
        else:
            for molecule in molecules:
                molecule_partition[molecule] = "train"
    for scaffold_part, label in (("valid", "valid_ood"), ("test", "test_ood")):
        for molecule in reactions.loc[
            reactions["scaffold_partition"] == scaffold_part, "inchikey"
        ].unique():
            molecule_partition[molecule] = label
    reactions["molecule_partition"] = reactions["inchikey"].map(molecule_partition)

    def final_group(row: pd.Series) -> str:
        protein, molecule = row["protein_partition"], row["molecule_partition"]
        if protein == "train" and molecule == "train":
            return "train"
        if protein == "valid" and molecule == "valid_id":
            return "V01_protein_ood"
        if protein == "train" and molecule == "valid_id":
            return "V00_control"
        if protein == "train" and molecule == "valid_ood":
            return "V10_scaffold_ood"
        if protein == "valid" and molecule == "valid_ood":
            return "V11_double_ood"
        if protein == "train" and molecule == "test_id":
            return "G00_control"
        if protein == "test" and molecule == "test_id":
            return "G01_protein_ood"
        if protein == "train" and molecule == "test_ood":
            return "G10_scaffold_ood"
        if protein == "test" and molecule == "test_ood":
            return "G11_double_ood"
        return "excluded_diagnostic"

    reactions["benchmark_group"] = reactions.apply(final_group, axis=1)
    target = Path(output_dir)
    target.mkdir(parents=True, exist_ok=True)
    reactions.to_parquet(target / "reaction_splits.parquet", index=False)
    reactions.to_csv(target / "reaction_splits.csv", index=False)

    summary = {}
    for group_name, group in reactions.groupby("benchmark_group"):
        summary[group_name] = {
            "reactions": len(group),
            "proteins": int(group["sequence_hash"].nunique()),
            "protein_clusters": int(group["protein_cluster"].nunique()),
            "molecules": int(group["inchikey"].nunique()),
            "scaffolds": int(group["scaffold"].nunique()),
            "positive_bonds": int(group["positive_bond_count"].sum()),
        }
    write_json(summary, target / "split_summary.json")
    return summary
