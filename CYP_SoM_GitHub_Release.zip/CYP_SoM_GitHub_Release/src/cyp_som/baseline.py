from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit.Chem import rdFingerprintGenerator
from sklearn.linear_model import LogisticRegression

from .metrics import best_mcc_threshold, binary_metrics
from .utils import write_json


def _bond_features(frame: pd.DataFrame, fingerprint_bits: int = 512) -> np.ndarray:
    generator = rdFingerprintGenerator.GetMorganGenerator(radius=2, fpSize=fingerprint_bits)
    features = np.zeros((len(frame), fingerprint_bits + 11), dtype=np.float32)
    cache: dict[str, tuple[np.ndarray, Chem.Mol]] = {}
    for output_index, row in enumerate(frame.itertuples(index=False)):
        smiles = row.molecule
        if smiles not in cache:
            heavy = Chem.MolFromSmiles(smiles)
            explicit = Chem.AddHs(heavy)
            fingerprint = generator.GetFingerprintAsNumPy(heavy).astype(np.float32)
            cache[smiles] = (fingerprint, explicit)
        fingerprint, molecule = cache[smiles]
        atom1 = molecule.GetAtomWithIdx(int(row.atom1_idx))
        atom2 = molecule.GetAtomWithIdx(int(row.atom2_idx))
        bond = molecule.GetBondBetweenAtoms(int(row.atom1_idx), int(row.atom2_idx))
        local = np.asarray(
            [
                atom1.GetAtomicNum(),
                atom2.GetAtomicNum(),
                atom1.GetDegree(),
                atom2.GetDegree(),
                atom1.GetFormalCharge(),
                atom2.GetFormalCharge(),
                float(atom1.GetIsAromatic()),
                float(atom2.GetIsAromatic()),
                float(bond.GetBondTypeAsDouble()) if bond else float(row.bond_type),
                float(bond.GetIsConjugated()) if bond else 0.0,
                float(bond.IsInRing()) if bond else 0.0,
            ],
            dtype=np.float32,
        )
        features[output_index, :fingerprint_bits] = fingerprint
        features[output_index, fingerprint_bits:] = local
    return features


def train_molecule_baseline(
    bonds_path: str | Path,
    splits_path: str | Path,
    output_dir: str | Path,
) -> dict[str, object]:
    bonds = pd.read_parquet(bonds_path)
    splits = pd.read_parquet(splits_path)[["reaction_id", "benchmark_group"]]
    data = bonds.merge(splits, on="reaction_id", how="inner", validate="many_to_one")
    data = data[data["atom_mapping_ok"]].copy()
    train = data[data["benchmark_group"] == "train"].copy()
    validation = data[data["benchmark_group"].str.startswith("V", na=False)].copy()
    tests = data[data["benchmark_group"].str.startswith("G", na=False)].copy()
    if train.empty or validation.empty or tests.empty:
        raise ValueError("Train, validation, and test rows are required")

    x_train = _bond_features(train)
    y_train = train["label"].to_numpy(dtype=int)
    reaction_size = train.groupby("reaction_id")["label"].transform("size").to_numpy()
    class_count = np.bincount(y_train, minlength=2)
    class_weight = len(y_train) / (2.0 * np.maximum(class_count, 1))
    sample_weight = class_weight[y_train] / reaction_size
    sample_weight *= len(sample_weight) / sample_weight.sum()

    model = LogisticRegression(
        max_iter=1000, class_weight=None, solver="liblinear", random_state=20260829
    )
    model.fit(x_train, y_train, sample_weight=sample_weight)
    validation_scores = model.predict_proba(_bond_features(validation))[:, 1]
    threshold, validation_mcc = best_mcc_threshold(validation["label"], validation_scores)

    target = Path(output_dir)
    target.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, target / "molecule_logistic.joblib")
    predictions = []
    metrics = {"threshold": threshold, "validation_mcc": validation_mcc, "groups": {}}
    for group_name, group in tests.groupby("benchmark_group"):
        scores = model.predict_proba(_bond_features(group))[:, 1]
        group_output = group[["reaction_id", "bond_idx", "label", "benchmark_group"]].copy()
        group_output["molecule_only_probability"] = scores
        predictions.append(group_output)
        metrics["groups"][group_name] = binary_metrics(group["label"], scores, threshold)
    pd.concat(predictions, ignore_index=True).to_parquet(
        target / "test_predictions.parquet", index=False
    )
    write_json(metrics, target / "metrics.json")
    return metrics
