from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass

STANDARD_AA = set("ACDEFGHIKLMNPQRSTVWY")


@dataclass(frozen=True)
class ProteinRecord:
    sequence: str
    sequence_hash: str
    length: int
    nonstandard_fraction: float
    has_heme_motif: bool
    has_exxr_motif: bool


def normalize_sequence(sequence: object) -> ProteinRecord:
    cleaned = re.sub(r"\s+", "", str(sequence)).upper()
    if not cleaned:
        raise ValueError("Empty protein sequence")
    nonstandard = sum(amino_acid not in STANDARD_AA for amino_acid in cleaned)
    return ProteinRecord(
        sequence=cleaned,
        sequence_hash=hashlib.sha256(cleaned.encode("ascii", errors="ignore")).hexdigest(),
        length=len(cleaned),
        nonstandard_fraction=nonstandard / len(cleaned),
        has_heme_motif=bool(re.search(r"F.G...C.G", cleaned[-120:])),
        has_exxr_motif=bool(re.search(r"E..R", cleaned)),
    )


def simple_identity(sequence_a: str, sequence_b: str) -> float:
    """Ungapped positional identity; a fast diagnostic, not the final global identity."""
    if not sequence_a or not sequence_b:
        return 0.0
    matches = sum(a == b for a, b in zip(sequence_a, sequence_b))
    return matches / max(len(sequence_a), len(sequence_b))
