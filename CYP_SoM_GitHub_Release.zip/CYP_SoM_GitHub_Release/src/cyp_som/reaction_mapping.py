from __future__ import annotations

from dataclasses import dataclass

from rdkit import Chem
from rdkit.Chem import rdFMCS

from .sites import build_site_context, canonicalize_bond_site


@dataclass(frozen=True)
class ReactionSiteMapping:
    status: str
    site_keys: tuple[str, ...]
    site_kinds: tuple[str, ...]
    changed_substrate_bonds: tuple[tuple[int, int], ...]
    hydrogen_substitution_atoms: tuple[int, ...]
    new_mapped_bonds: tuple[tuple[int, int], ...]
    mapped_heavy_atoms: int
    substrate_heavy_atoms: int
    product_heavy_atoms: int
    edit_count: int
    warning: str = ""


def _bond_order(bond: Chem.Bond) -> float:
    return float(bond.GetBondTypeAsDouble())


def _mapping_edits(
    substrate: Chem.Mol, product: Chem.Mol, mapping: dict[int, int]
) -> dict[str, list[tuple[int, int]] | list[int]]:
    inverse = {product_index: substrate_index for substrate_index, product_index in mapping.items()}
    changed: list[tuple[int, int]] = []
    removed_boundary: list[tuple[int, int]] = []
    added_attachments: list[int] = []
    new_mapped: list[tuple[int, int]] = []

    for bond in substrate.GetBonds():
        begin, end = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
        begin_mapped, end_mapped = begin in mapping, end in mapping
        if begin_mapped and end_mapped:
            product_bond = product.GetBondBetweenAtoms(mapping[begin], mapping[end])
            if product_bond is None or _bond_order(product_bond) != _bond_order(bond):
                changed.append(tuple(sorted((begin, end))))
        elif begin_mapped != end_mapped:
            removed_boundary.append(tuple(sorted((begin, end))))

    for bond in product.GetBonds():
        begin, end = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
        begin_mapped, end_mapped = begin in inverse, end in inverse
        if begin_mapped and end_mapped:
            substrate_pair = tuple(sorted((inverse[begin], inverse[end])))
            if substrate.GetBondBetweenAtoms(*substrate_pair) is None:
                new_mapped.append(substrate_pair)
        elif begin_mapped != end_mapped:
            mapped_product_index = begin if begin_mapped else end
            added_attachments.append(inverse[mapped_product_index])

    return {
        "changed": sorted(set(changed + removed_boundary)),
        "added_attachments": sorted(set(added_attachments)),
        "new_mapped": sorted(set(new_mapped)),
    }


def _mapping_score(
    substrate: Chem.Mol,
    product: Chem.Mol,
    mapping: dict[int, int],
) -> tuple[int, tuple[tuple[int, int], ...], tuple[int, ...]]:
    edits = _mapping_edits(substrate, product, mapping)
    changed = tuple(edits["changed"])
    attachments = tuple(edits["added_attachments"])
    new_mapped = tuple(edits["new_mapped"])
    score = len(changed) + len(attachments) + len(new_mapped)
    return score, changed + new_mapped, attachments


def _best_mcs_mapping(
    substrate: Chem.Mol, product: Chem.Mol, timeout: int = 5
) -> tuple[dict[int, int], str]:
    result = rdFMCS.FindMCS(
        [substrate, product],
        atomCompare=rdFMCS.AtomCompare.CompareElements,
        bondCompare=rdFMCS.BondCompare.CompareAny,
        ringMatchesRingOnly=False,
        completeRingsOnly=False,
        matchValences=False,
        timeout=timeout,
    )
    if result.canceled:
        return {}, "MCS_TIMEOUT"
    if result.numAtoms == 0:
        return {}, "NO_COMMON_SUBSTRUCTURE"
    query = Chem.MolFromSmarts(result.smartsString)
    if query is None:
        return {}, "INVALID_MCS_QUERY"
    substrate_matches = substrate.GetSubstructMatches(query, uniquify=False, maxMatches=256)
    product_matches = product.GetSubstructMatches(query, uniquify=False, maxMatches=256)
    if not substrate_matches or not product_matches:
        return {}, "MCS_MATCH_FAILED"

    best: tuple[tuple[object, ...], dict[int, int]] | None = None
    for substrate_match in substrate_matches:
        for product_match in product_matches:
            mapping = dict(zip(substrate_match, product_match, strict=True))
            score, changed, attachments = _mapping_score(substrate, product, mapping)
            hydrogen_delta = sum(
                abs(
                    substrate.GetAtomWithIdx(substrate_index).GetTotalNumHs()
                    - product.GetAtomWithIdx(product_index).GetTotalNumHs()
                )
                for substrate_index, product_index in mapping.items()
            )
            charge_delta = sum(
                abs(
                    substrate.GetAtomWithIdx(substrate_index).GetFormalCharge()
                    - product.GetAtomWithIdx(product_index).GetFormalCharge()
                )
                for substrate_index, product_index in mapping.items()
            )
            tie_break = (
                score,
                hydrogen_delta,
                charge_delta,
                changed,
                attachments,
                tuple(sorted(mapping.items())),
            )
            if best is None or tie_break < best[0]:
                best = (tie_break, mapping)
    assert best is not None
    return best[1], ""


def infer_existing_bond_sites(
    substrate_smiles: str, product_smiles: str, timeout: int = 5
) -> ReactionSiteMapping:
    substrate = Chem.MolFromSmiles(str(substrate_smiles))
    product = Chem.MolFromSmiles(str(product_smiles))
    if substrate is None or product is None:
        return ReactionSiteMapping(
            "INVALID_SMILES", (), (), (), (), (), 0, 0, 0, 0, "RDKit parse failure"
        )
    substrate = Chem.RemoveHs(substrate)
    product = Chem.RemoveHs(product)
    mapping, warning = _best_mcs_mapping(substrate, product, timeout=timeout)
    if not mapping:
        return ReactionSiteMapping(
            warning,
            (),
            (),
            (),
            (),
            (),
            0,
            substrate.GetNumHeavyAtoms(),
            product.GetNumHeavyAtoms(),
            0,
            warning,
        )

    edits = _mapping_edits(substrate, product, mapping)
    changed_bonds = tuple(edits["changed"])
    new_mapped_bonds = tuple(edits["new_mapped"])
    changed_atoms = {atom for bond in changed_bonds for atom in bond}
    hydrogen_atoms = []
    for atom_index in edits["added_attachments"]:
        atom = substrate.GetAtomWithIdx(atom_index)
        # If an existing substrate bond at this atom changed (e.g. epoxidation), that
        # bond is the target. Otherwise an added product substituent replaces H.
        if atom_index not in changed_atoms and atom.GetTotalNumHs() > 0:
            hydrogen_atoms.append(atom_index)

    edit_count = len(changed_bonds) + len(edits["added_attachments"]) + len(new_mapped_bonds)
    try:
        context = build_site_context(substrate_smiles, enumerate_equivalents=False)
    except (ValueError, RuntimeError) as exc:
        return ReactionSiteMapping(
            status="SITE_CANONICALIZATION_FAILED",
            site_keys=(),
            site_kinds=(),
            changed_substrate_bonds=changed_bonds,
            hydrogen_substitution_atoms=tuple(sorted(set(hydrogen_atoms))),
            new_mapped_bonds=new_mapped_bonds,
            mapped_heavy_atoms=len(mapping),
            substrate_heavy_atoms=substrate.GetNumHeavyAtoms(),
            product_heavy_atoms=product.GetNumHeavyAtoms(),
            edit_count=edit_count,
            warning=str(exc),
        )
    site_keys: list[str] = []
    site_kinds: list[str] = []
    for begin, end in changed_bonds:
        try:
            site = canonicalize_bond_site(context, begin, end)
        except (ValueError, IndexError) as exc:
            warning = f"{warning}; {exc}".strip("; ")
            continue
        site_keys.append(site.key)
        site_kinds.append(site.kind)
    explicit = context.raw_explicit
    for heavy_index in sorted(set(hydrogen_atoms)):
        hydrogens = [
            neighbor.GetIdx()
            for neighbor in explicit.GetAtomWithIdx(heavy_index).GetNeighbors()
            if neighbor.GetAtomicNum() == 1
        ]
        if not hydrogens:
            warning = f"{warning}; inferred H substitution without explicit H".strip("; ")
            continue
        site = canonicalize_bond_site(context, heavy_index, hydrogens[0])
        site_keys.append(site.key)
        site_kinds.append(site.kind)

    unique_sites = sorted(set(zip(site_keys, site_kinds, strict=True)))
    site_keys = [item[0] for item in unique_sites]
    site_kinds = [item[1] for item in unique_sites]
    coverage = len(mapping) / max(1, substrate.GetNumHeavyAtoms())
    if new_mapped_bonds and not site_keys:
        status = "NEW_BOND_OUTSIDE_OUTPUT_SPACE"
    elif not site_keys:
        status = "NO_EXISTING_BOND_SITE_INFERRED"
    elif coverage < 0.5:
        status = "LOW_SCAFFOLD_COVERAGE"
    elif len(site_keys) > 3:
        status = "COMPLEX_MULTISITE"
    else:
        status = "MAPPED"
    return ReactionSiteMapping(
        status=status,
        site_keys=tuple(site_keys),
        site_kinds=tuple(site_kinds),
        changed_substrate_bonds=changed_bonds,
        hydrogen_substitution_atoms=tuple(sorted(set(hydrogen_atoms))),
        new_mapped_bonds=new_mapped_bonds,
        mapped_heavy_atoms=len(mapping),
        substrate_heavy_atoms=substrate.GetNumHeavyAtoms(),
        product_heavy_atoms=product.GetNumHeavyAtoms(),
        edit_count=edit_count,
        warning=warning,
    )
