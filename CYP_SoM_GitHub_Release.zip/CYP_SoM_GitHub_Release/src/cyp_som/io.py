from __future__ import annotations

import zipfile
from pathlib import Path

import pandas as pd

CYPMOL_BOM_COLUMNS = {
    "protein_name",
    "protein_seq",
    "protein_pocket",
    "protein_SRS",
    "molecule",
    "bond_idx",
    "atom1_idx",
    "atom2_idx",
    "reaction_site",
    "dataset_type",
    "label",
}


def _read_only_csv_from_zip(path: str | Path) -> pd.DataFrame:
    archive = Path(path)
    with zipfile.ZipFile(archive) as handle:
        csv_names = [name for name in handle.namelist() if name.lower().endswith(".csv")]
        if len(csv_names) != 1:
            raise ValueError(f"Expected one CSV in {archive}, found {csv_names}")
        with handle.open(csv_names[0]) as stream:
            return pd.read_csv(stream)


def read_cypmol_bom(path: str | Path) -> pd.DataFrame:
    frame = _read_only_csv_from_zip(path)
    missing = CYPMOL_BOM_COLUMNS.difference(frame.columns)
    if missing:
        raise ValueError(f"CYPMol BoM missing required columns: {sorted(missing)}")
    frame["source"] = "CYPMol"
    frame["source_row"] = range(len(frame))
    return frame


def read_metacyp_bom(path: str | Path) -> pd.DataFrame:
    frame = _read_only_csv_from_zip(path)
    frame["source"] = "MetaCYP"
    frame["source_row"] = range(len(frame))
    return frame


def write_parquet(frame: pd.DataFrame, path: str | Path) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    frame.to_parquet(target, index=False)
