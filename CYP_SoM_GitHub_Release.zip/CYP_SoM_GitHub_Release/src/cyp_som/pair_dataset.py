from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from .sites import build_site_context, canonicalize_bond_site
from .utils import stable_id, write_json


def build_any_site_pair_dataset(
    bonds_path: str | Path,
    reactions_path: str | Path,
    output_dir: str | Path,
) -> dict[str, object]:
    bonds = pd.read_parquet(bonds_path).copy()
    reactions = pd.read_parquet(reactions_path).copy()
    target = Path(output_dir)
    target.mkdir(parents=True, exist_ok=True)

    context_cache = {}
    site_keys = []
    mapping_errors = []
    for row in bonds.itertuples(index=False):
        try:
            if row.molecule not in context_cache:
                context_cache[row.molecule] = build_site_context(row.molecule)
            context = context_cache[row.molecule]
            site = canonicalize_bond_site(context, int(row.atom1_idx), int(row.atom2_idx))
            site_keys.append(site.key)
            mapping_errors.append("")
        except (ValueError, IndexError, RuntimeError) as exc:
            site_keys.append("")
            mapping_errors.append(str(exc))
    bonds["canonical_site_key"] = site_keys
    bonds["site_mapping_error"] = mapping_errors
    reaction_to_pair = reactions.set_index("reaction_id")["pair_id"].to_dict()
    bonds["pair_id"] = bonds["reaction_id"].map(reaction_to_pair)

    curated_bonds = []
    curated_reactions = []
    exclusions = []
    for pair_id, pair_reactions in reactions.groupby("pair_id", sort=True):
        pair_bonds = bonds[bonds["pair_id"] == pair_id]
        positive_union = set(
            pair_bonds.loc[
                (pair_bonds["label"] == 1) & (pair_bonds["canonical_site_key"] != ""),
                "canonical_site_key",
            ]
        )
        zero_positive = pair_reactions.loc[
            pair_reactions["positive_bond_count"] == 0, "reaction_id"
        ].tolist()
        if not positive_union:
            exclusions.append(
                {
                    "pair_id": pair_id,
                    "reason": "NO_REPRESENTABLE_POSITIVE_BOND",
                    "reaction_ids": json.dumps(pair_reactions["reaction_id"].tolist()),
                    "reaction_sites_raw": json.dumps(pair_reactions["reaction_site_raw"].tolist()),
                }
            )
            continue

        candidates = []
        for reaction_id, group in pair_bonds.groupby("reaction_id"):
            available = set(group.loc[group["canonical_site_key"] != "", "canonical_site_key"])
            candidates.append((len(positive_union & available), len(group), reaction_id, available))
        _, _, representative_id, available = max(candidates)
        missing = positive_union - available
        if missing:
            exclusions.append(
                {
                    "pair_id": pair_id,
                    "reason": "UNION_NOT_REPRESENTABLE_ON_ONE_GRAPH",
                    "reaction_ids": json.dumps(pair_reactions["reaction_id"].tolist()),
                    "reaction_sites_raw": json.dumps(sorted(missing)),
                }
            )
            continue

        representative = pair_bonds[pair_bonds["reaction_id"] == representative_id].copy()
        representative["original_label"] = representative["label"]
        representative["label"] = (
            representative["canonical_site_key"].isin(positive_union).astype(int)
        )
        curated_id = stable_id(pair_id, "any_observed_site_v1", prefix="curated_")
        representative["source_reaction_id"] = representative["reaction_id"]
        representative["reaction_id"] = curated_id
        representative["curation_endpoint"] = "ANY_OBSERVED_SITE_UNION"
        curated_bonds.append(representative)

        first = pair_reactions.iloc[0]
        curated_reactions.append(
            {
                "reaction_id": curated_id,
                "pair_id": pair_id,
                "source": "CYPMol_any_observed_site_union_v1",
                "protein_name": first["protein_name"],
                "sequence_hash": first["sequence_hash"],
                "protein_sequence": first["protein_sequence"],
                "protein_pocket": first["protein_pocket"],
                "protein_srs": first["protein_srs"],
                "canonical_smiles": first["canonical_smiles"],
                "inchikey": first["inchikey"],
                "scaffold": first["scaffold"],
                "canonical_positive_sites": json.dumps(sorted(positive_union)),
                "source_reaction_ids": json.dumps(pair_reactions["reaction_id"].tolist()),
                "released_splits": json.dumps(sorted(pair_reactions["released_split"].unique())),
                "source_reaction_count": len(pair_reactions),
                "zero_positive_source_records": json.dumps(zero_positive),
                "candidate_bond_count": len(representative),
                "positive_bond_count": int(representative["label"].sum()),
                "curation_endpoint": "ANY_OBSERVED_SITE_UNION",
                "atom_mapping_ok": True,
            }
        )

    curated_bond_frame = pd.concat(curated_bonds, ignore_index=True)
    curated_reaction_frame = pd.DataFrame(curated_reactions)
    exclusion_frame = pd.DataFrame(exclusions)
    curated_bond_frame.to_parquet(target / "candidate_bonds.parquet", index=False)
    curated_reaction_frame.to_parquet(target / "reactions.parquet", index=False)
    curated_reaction_frame.to_csv(target / "reactions.csv", index=False)
    exclusion_frame.to_csv(target / "excluded_pairs.csv", index=False)
    summary = {
        "site_key_version": 3,
        "input_reaction_records": len(reactions),
        "input_pairs": int(reactions["pair_id"].nunique()),
        "curated_pair_reactions": len(curated_reaction_frame),
        "curated_candidate_bonds": len(curated_bond_frame),
        "curated_positive_bonds": int(curated_bond_frame["label"].sum()),
        "excluded_pairs": len(exclusion_frame),
        "exclusion_reasons": exclusion_frame["reason"].value_counts().to_dict()
        if not exclusion_frame.empty
        else {},
        "source_zero_positive_records": int((reactions["positive_bond_count"] == 0).sum()),
        "candidate_mapping_errors": int((bonds["site_mapping_error"] != "").sum()),
    }
    write_json(summary, target / "manifest.json")
    return summary
