from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

import pandas as pd

from .chem import standardize_smiles
from .io import read_cypmol_bom, write_parquet
from .protein import normalize_sequence
from .utils import stable_id, write_json


def prepare_cypmol_bom(input_path: str | Path, output_dir: str | Path) -> dict[str, object]:
    raw = read_cypmol_bom(input_path)
    target = Path(output_dir)
    target.mkdir(parents=True, exist_ok=True)

    protein_cache = {}
    molecule_cache = {}
    errors: list[dict[str, object]] = []

    for sequence in raw["protein_seq"].drop_duplicates():
        try:
            protein_cache[sequence] = normalize_sequence(sequence)
        except ValueError as exc:  # audit failures rather than silently dropping
            errors.append({"kind": "protein", "value": str(sequence)[:80], "error": str(exc)})

    for smiles in raw["molecule"].drop_duplicates():
        try:
            molecule_cache[smiles] = standardize_smiles(smiles)
        except (ValueError, RuntimeError) as exc:
            errors.append({"kind": "molecule", "value": str(smiles), "error": str(exc)})

    valid = raw[
        raw["protein_seq"].isin(protein_cache) & raw["molecule"].isin(molecule_cache)
    ].copy()
    valid["sequence_hash"] = valid["protein_seq"].map(
        lambda value: protein_cache[value].sequence_hash
    )
    valid["canonical_smiles"] = valid["molecule"].map(
        lambda value: molecule_cache[value].canonical_smiles
    )
    valid["inchikey"] = valid["molecule"].map(lambda value: molecule_cache[value].inchikey)
    valid["scaffold"] = valid["molecule"].map(lambda value: molecule_cache[value].scaffold_smiles)

    def map_atom(row: pd.Series, column: str) -> int | None:
        mapping = molecule_cache[row["molecule"]].original_to_standard
        return mapping.get(int(row[column]))

    valid["standard_atom1_idx"] = valid.apply(map_atom, axis=1, column="atom1_idx")
    valid["standard_atom2_idx"] = valid.apply(map_atom, axis=1, column="atom2_idx")
    valid["atom_mapping_ok"] = (
        valid["standard_atom1_idx"].notna() & valid["standard_atom2_idx"].notna()
    )

    # Keep every record for audit. The reaction split key prevents the same CYP–molecule pair leaking.
    valid["pair_id"] = [
        stable_id(sequence_hash, inchikey, prefix="pair_")
        for sequence_hash, inchikey in zip(valid["sequence_hash"], valid["inchikey"], strict=True)
    ]
    valid["reaction_id"] = [
        stable_id(sequence_hash, inchikey, reaction_site, prefix="rxn_")
        for sequence_hash, inchikey, reaction_site in zip(
            valid["sequence_hash"], valid["inchikey"], valid["reaction_site"], strict=True
        )
    ]

    reaction_rows = []
    for reaction_id, group in valid.groupby("reaction_id", sort=True):
        first = group.iloc[0]
        reaction_rows.append(
            {
                "reaction_id": reaction_id,
                "pair_id": first["pair_id"],
                "source": "CYPMol",
                "protein_name": first["protein_name"],
                "sequence_hash": first["sequence_hash"],
                "protein_sequence": first["protein_seq"],
                "protein_pocket": first["protein_pocket"],
                "protein_srs": first["protein_SRS"],
                "canonical_smiles": first["canonical_smiles"],
                "inchikey": first["inchikey"],
                "scaffold": first["scaffold"],
                "reaction_site_raw": str(first["reaction_site"]),
                "positive_bonds": json.dumps(
                    sorted(group.loc[group["label"] == 1, "bond_idx"].astype(int).unique().tolist())
                ),
                "candidate_bond_count": len(group),
                "positive_bond_count": int(group["label"].sum()),
                "released_split": first["dataset_type"],
                "atom_mapping_ok": bool(group["atom_mapping_ok"].all()),
            }
        )
    reactions = pd.DataFrame(reaction_rows)

    proteins = pd.DataFrame(
        [
            {
                "sequence_hash": record.sequence_hash,
                "protein_sequence": record.sequence,
                "length": record.length,
                "nonstandard_fraction": record.nonstandard_fraction,
                "has_heme_motif": record.has_heme_motif,
                "has_exxr_motif": record.has_exxr_motif,
            }
            for record in protein_cache.values()
        ]
    ).drop_duplicates("sequence_hash")

    molecules = pd.DataFrame(
        [
            {
                "molecule_hash": record.molecule_hash,
                "original_smiles": record.original_smiles,
                "canonical_smiles": record.canonical_smiles,
                "inchikey": record.inchikey,
                "scaffold": record.scaffold_smiles,
                "heavy_atom_count": record.heavy_atom_count,
                "explicit_atom_count": record.explicit_atom_count,
                "explicit_bond_count": record.explicit_bond_count,
            }
            for record in molecule_cache.values()
        ]
    ).drop_duplicates("inchikey")

    write_parquet(valid, target / "candidate_bonds.parquet")
    write_parquet(reactions, target / "reactions.parquet")
    write_parquet(proteins, target / "proteins.parquet")
    write_parquet(molecules, target / "molecules.parquet")
    write_json(errors, target / "preparation_errors.json")

    manifest = {
        "candidate_bond_rows": len(valid),
        "positive_bond_rows": int(valid["label"].sum()),
        "reaction_records": len(reactions),
        "pair_records": int(reactions["pair_id"].nunique()),
        "unique_sequences": int(reactions["sequence_hash"].nunique()),
        "unique_molecules": int(reactions["inchikey"].nunique()),
        "unique_scaffolds": int(reactions["scaffold"].nunique()),
        "atom_mapping_failures": int((~valid["atom_mapping_ok"]).sum()),
        "released_splits": dict(Counter(valid["dataset_type"])),
        "errors": len(errors),
    }
    write_json(manifest, target / "manifest.json")
    return manifest
