from __future__ import annotations

from typing import Any

from .graph_data import ATOM_FEATURE_DIM, BOND_FEATURE_DIM


def require_torch() -> tuple[Any, Any]:
    try:
        import torch
        from torch import nn
    except ImportError as error:
        raise RuntimeError(
            "GNN training requires the optional train dependencies: pip install -e '.[train]'"
        ) from error
    return torch, nn


def build_bond_centered_gnn(hidden: int = 128, layers: int = 3, protein_dim: int = 0):
    torch, nn = require_torch()

    class MessageLayer(nn.Module):
        def __init__(self) -> None:
            super().__init__()
            self.message = nn.Sequential(
                nn.Linear(hidden + BOND_FEATURE_DIM, hidden),
                nn.SiLU(),
                nn.Linear(hidden, hidden),
            )
            self.update = nn.GRUCell(hidden, hidden)
            self.norm = nn.LayerNorm(hidden)

        def forward(self, node, edge_index, edge_features):
            source, target = edge_index
            messages = self.message(torch.cat([node[source], edge_features], dim=-1))
            aggregate = torch.zeros_like(node)
            aggregate.index_add_(0, target, messages)
            return self.norm(self.update(aggregate, node))

    class BondModel(nn.Module):
        def __init__(self) -> None:
            super().__init__()
            self.protein_dim = protein_dim
            self.node = nn.Sequential(nn.Linear(ATOM_FEATURE_DIM, hidden), nn.SiLU())
            self.layers = nn.ModuleList(MessageLayer() for _ in range(layers))
            self.bond = nn.Sequential(
                nn.Linear(hidden * 2 + BOND_FEATURE_DIM, hidden),
                nn.SiLU(),
                nn.LayerNorm(hidden),
            )
            if protein_dim:
                self.protein = nn.Sequential(
                    nn.LayerNorm(protein_dim),
                    nn.Linear(protein_dim, hidden),
                    nn.SiLU(),
                )
                self.film = nn.Linear(hidden, hidden * 2)
            self.head = nn.Sequential(
                nn.Linear(hidden, hidden),
                nn.SiLU(),
                nn.Dropout(0.15),
                nn.Linear(hidden, 1),
            )

        def encode(self, atom_features, edge_index, edge_features):
            node = self.node(atom_features)
            for layer in self.layers:
                node = layer(node, edge_index, edge_features)
            return node

        def bond_representations(self, node, target_bonds, target_bond_features):
            left, right = target_bonds[:, 0], target_bonds[:, 1]
            return self.bond(torch.cat([node[left], node[right], target_bond_features], dim=-1))

        def predict_bonds(
            self,
            node,
            target_bonds,
            target_bond_features,
            protein_embedding=None,
        ):
            bond = self.bond_representations(node, target_bonds, target_bond_features)
            if self.protein_dim:
                if protein_embedding is None:
                    raise ValueError("protein_embedding is required for the conditioned model")
                condition = self.protein(protein_embedding.reshape(1, -1))
                gamma, beta = self.film(condition).chunk(2, dim=-1)
                bond = bond * (1.0 + torch.tanh(gamma)) + beta
            return self.head(bond).squeeze(-1)

        def forward(
            self,
            atom_features,
            edge_index,
            edge_features,
            target_bond,
            target_bond_feature,
            protein_embedding=None,
        ):
            node = self.encode(atom_features, edge_index, edge_features)
            return self.predict_bonds(
                node,
                target_bond.reshape(1, 2),
                target_bond_feature.reshape(1, BOND_FEATURE_DIM),
                protein_embedding,
            ).squeeze(0)

    return BondModel()
