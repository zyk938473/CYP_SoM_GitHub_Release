from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score

RELIABILITY_COLUMNS = {
    "sequence": ["retrieval_max_sequence_identity"],
    "mapping": [
        "retrieval_max_molecule_similarity",
        "retrieval_max_mcs_coverage",
        "retrieval_effective_neighbors",
        "retrieval_neighbor_count",
    ],
    "joint": [
        "retrieval_max_sequence_identity",
        "retrieval_max_molecule_similarity",
        "retrieval_max_mcs_coverage",
        "retrieval_effective_neighbors",
        "retrieval_neighbor_count",
    ],
}


def reaction_weights(reaction_ids: Iterable[str]) -> np.ndarray:
    values = pd.Series(list(reaction_ids), dtype=str)
    counts = values.value_counts()
    weights = values.map(counts.rdiv(1.0)).to_numpy(dtype=float)
    return weights * (len(weights) / weights.sum())


def reliability_matrix(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    data = frame[columns].fillna(0.0).to_numpy(dtype=float)
    for index, column in enumerate(columns):
        if column in {"retrieval_effective_neighbors", "retrieval_neighbor_count"}:
            data[:, index] = np.log1p(np.maximum(data[:, index], 0.0)) / np.log(9.0)
    return np.clip(data, 0.0, 1.5)


def weighted_ece(
    truth: np.ndarray, scores: np.ndarray, weights: np.ndarray, bins: int = 15
) -> float:
    edges = np.linspace(0.0, 1.0, bins + 1)
    assignments = np.clip(np.digitize(scores, edges[1:-1]), 0, bins - 1)
    total = weights.sum()
    error = 0.0
    for index in range(bins):
        mask = assignments == index
        if mask.any():
            mass = weights[mask].sum()
            error += (
                mass
                / total
                * abs(
                    np.average(truth[mask], weights=weights[mask])
                    - np.average(scores[mask], weights=weights[mask])
                )
            )
    return float(error)


def weighted_mcc(truth: np.ndarray, prediction: np.ndarray, weights: np.ndarray) -> float:
    truth = truth.astype(bool)
    prediction = prediction.astype(bool)
    tp = weights[truth & prediction].sum()
    tn = weights[~truth & ~prediction].sum()
    fp = weights[~truth & prediction].sum()
    fn = weights[truth & ~prediction].sum()
    denominator = np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    return float((tp * tn - fp * fn) / denominator) if denominator else 0.0


def weighted_metrics(
    truth: Iterable[int], scores: Iterable[float], weights: Iterable[float], threshold: float
) -> dict[str, float]:
    y = np.asarray(list(truth), dtype=int)
    p = np.clip(np.asarray(list(scores), dtype=float), 0.0, 1.0)
    w = np.asarray(list(weights), dtype=float)
    predicted = p >= threshold
    tp = w[(y == 1) & predicted].sum()
    fp = w[(y == 0) & predicted].sum()
    fn = w[(y == 1) & ~predicted].sum()
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    return {
        "weighted_mcc": weighted_mcc(y, predicted, w),
        "weighted_pr_auc": float(average_precision_score(y, p, sample_weight=w))
        if len(np.unique(y)) == 2
        else float("nan"),
        "weighted_roc_auc": float(roc_auc_score(y, p, sample_weight=w))
        if len(np.unique(y)) == 2
        else float("nan"),
        "weighted_precision": float(precision),
        "weighted_recall": float(recall),
        "weighted_f1": float(2 * precision * recall / (precision + recall))
        if precision + recall
        else 0.0,
        "weighted_brier": float(np.average(np.square(p - y), weights=w)),
        "weighted_ece_15": weighted_ece(y, p, w),
        "weighted_prevalence": float(np.average(y, weights=w)),
    }


def best_weighted_mcc_threshold(
    truth: np.ndarray, scores: np.ndarray, weights: np.ndarray
) -> tuple[float, float]:
    candidates = np.unique(np.quantile(scores, np.linspace(0.0, 1.0, 201)))
    values = [(value, weighted_mcc(truth, scores >= value, weights)) for value in candidates]
    return tuple(map(float, max(values, key=lambda item: item[1])))


@dataclass
class MonotonicReliabilityGate:
    columns: list[str]
    regularization: float = 0.1
    intercept_: float = 0.0
    coefficients_: np.ndarray | None = None

    def fit(self, frame: pd.DataFrame) -> MonotonicReliabilityGate:
        x = reliability_matrix(frame, self.columns)
        truth = frame["label"].to_numpy(dtype=float)
        base = frame["base_probability"].to_numpy(dtype=float)
        retrieved = frame["retrieval_probability"].fillna(0.0).to_numpy(dtype=float)
        available = frame["retrieval_available"].to_numpy(dtype=float)
        weights = reaction_weights(frame["reaction_id"])

        def objective(raw: np.ndarray) -> tuple[float, np.ndarray]:
            intercept = raw[0]
            coefficients = np.logaddexp(0.0, raw[1:])
            eta = intercept + x @ coefficients
            gate = expit(eta) * available
            probability = np.clip(base + gate * (retrieved - base), 1e-7, 1 - 1e-7)
            loss = (
                -np.average(
                    truth * np.log(probability) + (1 - truth) * np.log1p(-probability),
                    weights=weights,
                )
                + self.regularization * np.square(coefficients).sum()
            )
            derivative_probability = (probability - truth) / (probability * (1 - probability))
            derivative_eta = (
                derivative_probability * (retrieved - base) * gate * (1 - np.clip(gate, 0.0, 1.0))
            )
            weighted = weights * derivative_eta / weights.sum()
            gradient = np.empty_like(raw)
            gradient[0] = weighted.sum()
            gradient[1:] = (x.T @ weighted) * expit(raw[1:])
            gradient[1:] += 2 * self.regularization * coefficients * expit(raw[1:])
            return float(loss), gradient

        result = minimize(
            objective,
            np.zeros(len(self.columns) + 1),
            jac=True,
            method="L-BFGS-B",
            options={"maxiter": 300, "ftol": 1e-10},
        )
        if not result.success:
            raise RuntimeError(f"Reliability gate failed to converge: {result.message}")
        self.intercept_ = float(result.x[0])
        self.coefficients_ = np.logaddexp(0.0, result.x[1:])
        return self

    def gate(self, frame: pd.DataFrame) -> np.ndarray:
        if self.coefficients_ is None:
            raise RuntimeError("Gate has not been fit")
        value = expit(
            self.intercept_ + reliability_matrix(frame, self.columns) @ self.coefficients_
        )
        return value * frame["retrieval_available"].to_numpy(dtype=float)

    def predict(self, frame: pd.DataFrame) -> np.ndarray:
        base = frame["base_probability"].to_numpy(dtype=float)
        retrieved = frame["retrieval_probability"].fillna(0.0).to_numpy(dtype=float)
        gate = self.gate(frame)
        return np.clip(base + gate * (retrieved - base), 0.0, 1.0)

    def to_dict(self) -> dict[str, object]:
        return {
            "columns": self.columns,
            "regularization": self.regularization,
            "intercept": self.intercept_,
            "coefficients": dict(zip(self.columns, self.coefficients_, strict=True))
            if self.coefficients_ is not None
            else None,
        }


def platt_fit(scores: np.ndarray, truth: np.ndarray, weights: np.ndarray) -> LogisticRegression:
    model = LogisticRegression(solver="lbfgs", C=1e6)
    model.fit(scores.reshape(-1, 1), truth, sample_weight=weights)
    return model
