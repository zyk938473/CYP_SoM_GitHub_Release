# Data availability

The repository contains analysis code, minimal frozen-split manifests and checksums, aggregate figure source data, paired statistical summaries, and non-row-level figures.

It does **not** include row-level merged benchmark records, source-derived molecular tables, protein sequences, reaction-level split assignments, retrieval banks, mapped-neighbor records, permission correspondence, or fixed-case provenance.

| Resource | Release treatment |
|---|---|
| CYPMol | Obtain from the official provider; source-derived rows are not redistributed here. |
| P450Rdb v2 | Provider-governed; use under the provider terms and applicable written permission. |
| Rhea | Obtain from Rhea and retain CC BY 4.0 attribution. |
| UniProtKB/Swiss-Prot | Obtain from UniProt and follow current provider terms. |
| Pfam/InterPro PF00067.28 | Obtain from EMBL-EBI and preserve accession/version attribution. |

The MIT License applies only to original repository code and does not replace any third-party terms.
