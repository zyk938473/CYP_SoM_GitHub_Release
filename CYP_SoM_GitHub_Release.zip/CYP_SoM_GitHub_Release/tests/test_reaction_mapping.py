from cyp_som.reaction_mapping import infer_existing_bond_sites


def test_infer_aliphatic_hydroxylation() -> None:
    result = infer_existing_bond_sites("CCC", "CCCO")
    assert result.status == "MAPPED"
    assert result.site_kinds == ("heavy_hydrogen",)


def test_infer_epoxidation_as_alkene_bond() -> None:
    result = infer_existing_bond_sites("CC=C", "CC1CO1")
    assert result.status == "MAPPED"
    assert result.site_kinds == ("heavy_heavy",)
    assert len(result.changed_substrate_bonds) == 1


def test_infer_dealkylation_as_broken_bond() -> None:
    result = infer_existing_bond_sites("COC", "CO")
    assert result.status == "MAPPED"
    assert result.site_kinds == ("heavy_heavy",)
