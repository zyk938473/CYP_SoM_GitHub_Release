from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path


def load_cache_module():
    path = Path(__file__).parents[1] / "scripts" / "cache_esm2_embeddings.py"
    spec = spec_from_file_location("cache_esm2_embeddings", path)
    module = module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def test_token_budget_batches_cover_each_sequence_once():
    module = load_cache_module()
    records = [("a", "A" * 100), ("b", "A" * 200), ("c", "A" * 300)]
    batches = module.make_batches(records, token_budget=500, max_batch_size=2)
    flattened = [record for batch in batches for record in batch]
    assert sorted(flattened) == sorted(records)
    assert all(
        (max(len(sequence) + 2 for _, sequence in batch) * len(batch)) <= 500 for batch in batches
    )
