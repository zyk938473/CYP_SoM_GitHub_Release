import numpy as np

from scripts.train_global_protein_model import make_control_embeddings


def test_mean_control_uses_only_training_pool() -> None:
    embeddings = {
        "a": np.array([1.0, 0.0], dtype=np.float32),
        "b": np.array([3.0, 2.0], dtype=np.float32),
        "test": np.array([100.0, 100.0], dtype=np.float32),
    }
    output = make_control_embeddings(embeddings, {"a", "b"}, {"a", "b", "test"}, "mean", 1)
    assert np.allclose(output["test"], [2.0, 1.0])


def test_permuted_control_is_deterministic_and_train_only() -> None:
    embeddings = {
        "a": np.array([1.0]),
        "b": np.array([2.0]),
        "test": np.array([100.0]),
    }
    first = make_control_embeddings(embeddings, {"a", "b"}, set(embeddings), "permuted", 7)
    second = make_control_embeddings(embeddings, {"a", "b"}, set(embeddings), "permuted", 7)
    assert all(np.array_equal(first[key], second[key]) for key in first)
    assert all(float(value[0]) in {1.0, 2.0} for value in first.values())
