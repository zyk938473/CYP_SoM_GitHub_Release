import numpy as np
import pandas as pd

from cyp_som.reliability import (
    MonotonicReliabilityGate,
    reaction_weights,
    weighted_mcc,
)


def example_frame() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "reaction_id": ["a", "a", "b", "b", "b", "c"],
            "label": [0, 1, 0, 0, 1, 1],
            "base_probability": [0.1, 0.3, 0.2, 0.4, 0.4, 0.6],
            "retrieval_probability": [0.0, 1.0, 0.0, 0.0, 1.0, np.nan],
            "retrieval_available": [True, True, True, True, True, False],
            "retrieval_max_sequence_identity": [0.8, 0.8, 0.7, 0.7, 0.7, 0.0],
            "retrieval_max_molecule_similarity": [0.9, 0.9, 0.8, 0.8, 0.8, 0.0],
            "retrieval_max_mcs_coverage": [0.9, 0.9, 0.8, 0.8, 0.8, 0.0],
            "retrieval_effective_neighbors": [3, 3, 2, 2, 2, 0],
            "retrieval_neighbor_count": [4, 4, 3, 3, 3, 0],
        }
    )


def test_reaction_weights_give_equal_mass() -> None:
    frame = example_frame()
    frame["weight"] = reaction_weights(frame["reaction_id"])
    masses = frame.groupby("reaction_id")["weight"].sum().to_numpy()
    assert np.allclose(masses, masses[0])


def test_monotonic_gate_fits_and_falls_back() -> None:
    frame = example_frame()
    columns = ["retrieval_max_molecule_similarity", "retrieval_max_mcs_coverage"]
    gate = MonotonicReliabilityGate(columns, regularization=0.1).fit(frame)
    scores = gate.predict(frame)
    assert np.all((0 <= scores) & (scores <= 1))
    assert np.all(gate.coefficients_ >= 0)
    assert scores[-1] == frame.loc[5, "base_probability"]


def test_weighted_mcc_is_bounded() -> None:
    value = weighted_mcc(
        np.array([0, 0, 1, 1]),
        np.array([0, 1, 1, 1]),
        np.ones(4),
    )
    assert -1 <= value <= 1
