# Tests

These are small synthetic unit tests for the released final code; they contain no benchmark rows, protein records or third-party data.

- `test_core.py` — molecular standardization, graph features, metrics and retrieval aggregation.
- `test_sites.py` — site-key v3 invariance and symmetry handling.
- `test_reaction_mapping.py` — hydroxylation, epoxidation and dealkylation mapping rules.
- `test_retrieval_mapping.py` — MCS site transfer.
- `test_reliability.py` — reaction weighting, monotonic gate and fallback behavior.
- `test_protein_controls.py` — train-only mean/permuted controls.
- `test_gnn.py` — verifies that protein conditioning changes bond logits.
- `test_esm_cache.py` — ESM batching/token-budget logic.

The GNN test is skipped automatically when the optional PyTorch dependency is unavailable.
