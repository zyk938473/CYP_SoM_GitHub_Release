from cyp_som.sites import build_site_context, canonicalize_bond_site


def _find_oh_site(smiles: str) -> str:
    context = build_site_context(smiles)
    explicit = context.raw_explicit
    for bond in explicit.GetBonds():
        atoms = (bond.GetBeginAtom(), bond.GetEndAtom())
        numbers = {atom.GetAtomicNum() for atom in atoms}
        if numbers == {1, 8}:
            site = canonicalize_bond_site(context, bond.GetBeginAtomIdx(), bond.GetEndAtomIdx())
            return site.key
    raise AssertionError("No O-H bond")


def test_site_key_survives_smiles_reordering():
    assert _find_oh_site("CC(O)C") == _find_oh_site("CC(C)O")


def test_tautomeric_smiles_share_remote_site_key():
    first = "CCCSc1ccc2nc(NC(=O)OC)[nH]c2c1"
    second = "CCCSc1ccc2[nH]c(NC(=O)OC)nc2c1"
    keys = []
    for smiles in (first, second):
        context = build_site_context(smiles)
        explicit = context.raw_explicit
        hydrogen = next(
            neighbor.GetIdx()
            for neighbor in explicit.GetAtomWithIdx(0).GetNeighbors()
            if neighbor.GetAtomicNum() == 1
        )
        keys.append(canonicalize_bond_site(context, 0, hydrogen).key)
    assert keys[0] == keys[1]


def test_equivalent_methyl_hydrogens_collapse():
    context = build_site_context("CC")
    sites = []
    for bond in context.raw_explicit.GetBonds():
        begin, end = bond.GetBeginAtom(), bond.GetEndAtom()
        if 1 in {begin.GetAtomicNum(), end.GetAtomicNum()}:
            sites.append(canonicalize_bond_site(context, begin.GetIdx(), end.GetIdx()).key)
    assert len(set(sites)) == 1
