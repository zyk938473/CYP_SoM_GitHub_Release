import numpy as np

from cyp_som.chem import standardize_smiles
from cyp_som.graph_data import ATOM_FEATURE_DIM, molecule_graph
from cyp_som.metrics import binary_metrics
from cyp_som.protein import normalize_sequence
from cyp_som.retrieval import aggregate_neighbor_predictions


def test_molecule_mapping_is_preserved():
    record = standardize_smiles("CCO")
    assert record.canonical_smiles == "CCO"
    assert all(record.original_to_standard[index] == index for index in range(3))
    assert record.explicit_atom_count == 9


def test_graph_features_include_target_bonds():
    atoms, edges, edge_features, target_features = molecule_graph("CCO")
    assert atoms.shape[1] == ATOM_FEATURE_DIM
    assert edges.shape[0] == 2
    assert edge_features.shape[1] == 4
    assert (0, 1) in target_features


def test_protein_normalization():
    record = normalize_sequence(" ACDEFGHIK ")
    assert record.sequence == "ACDEFGHIK"
    assert record.length == 9


def test_metrics_and_retrieval():
    result = binary_metrics([0, 1, 0, 1], [0.1, 0.8, 0.4, 0.6])
    assert result["mcc"] == 1.0
    assert 0.0 <= result["ece_15"] <= 1.0
    assert result["prevalence"] == 0.5
    output = aggregate_neighbor_predictions(
        np.array([0.2, 0.8]),
        np.array([[0.3, 0.7], [0.4, 0.6]]),
        np.array([0.9, 0.5]),
        gate=0.5,
    )
    assert output.shape == (2,)
