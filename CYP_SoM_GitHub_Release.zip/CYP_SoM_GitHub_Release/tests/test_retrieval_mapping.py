import pandas as pd

from cyp_som.retrieval_mapping import transfer_neighbor_labels


def test_mcs_transfer_maps_shared_carbon_bond():
    train = pd.DataFrame(
        [
            {"atom1_idx": 0, "atom2_idx": 1, "label": 1},
            {"atom1_idx": 1, "atom2_idx": 2, "label": 0},
        ]
    )
    query = pd.DataFrame(
        [
            {"atom1_idx": 0, "atom2_idx": 1, "label": 0},
            {"atom1_idx": 1, "atom2_idx": 2, "label": 0},
        ]
    )
    values, ambiguity, coverage = transfer_neighbor_labels(
        "CCO", "CCN", train, query, minimum_coverage=0.5
    )
    assert values[0] == 1.0
    assert ambiguity[0] >= 1
    assert coverage >= 0.5
