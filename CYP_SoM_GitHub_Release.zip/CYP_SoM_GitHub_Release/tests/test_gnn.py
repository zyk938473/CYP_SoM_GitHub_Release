import numpy as np
import pytest


def test_protein_conditioning_changes_bond_logits():
    torch = pytest.importorskip("torch")
    from cyp_som.gnn import build_bond_centered_gnn
    from cyp_som.graph_data import molecule_graph

    atoms, edges, edge_features, targets = molecule_graph("CCO")
    model = build_bond_centered_gnn(hidden=16, layers=1, protein_dim=8).eval()
    atom_tensor = torch.tensor(atoms)
    edge_tensor = torch.tensor(edges)
    edge_feature_tensor = torch.tensor(edge_features)
    target_bonds = torch.tensor([[0, 1]])
    target_features = torch.tensor(np.stack([targets[(0, 1)]]))
    node = model.encode(atom_tensor, edge_tensor, edge_feature_tensor)
    with torch.no_grad():
        first = model.predict_bonds(node, target_bonds, target_features, torch.arange(8.0))
        second = model.predict_bonds(node, target_bonds, target_features, torch.arange(8.0).flip(0))
    assert not torch.allclose(first, second)
