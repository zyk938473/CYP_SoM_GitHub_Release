from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import pyhmmer


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--proteins", required=True)
    parser.add_argument("--hmm", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--cpus", type=int, default=8)
    args = parser.parse_args()

    proteins = pd.read_parquet(args.proteins).copy()
    alphabet = pyhmmer.easel.Alphabet.amino()
    sequences = [
        pyhmmer.easel.TextSequence(
            name=row.sequence_hash.encode(), sequence=row.protein_sequence
        ).digitize(alphabet)
        for row in proteins.itertuples(index=False)
    ]
    with pyhmmer.plan7.HMMFile(args.hmm) as hmm_file:
        hmm = hmm_file.read()
    assert hmm is not None
    result = next(pyhmmer.hmmsearch([hmm], sequences, cpus=args.cpus))
    hits = {
        hit.name.decode() if isinstance(hit.name, bytes) else str(hit.name): hit for hit in result
    }

    rows = []
    for row in proteins.itertuples(index=False):
        hit = hits.get(row.sequence_hash)
        if hit is None or not hit.domains:
            rows.append(
                {
                    **row._asdict(),
                    "sequence_length": len(row.protein_sequence),
                    "domain_count": 0,
                    "domain_sequence": "",
                    "domain_start": None,
                    "domain_end": None,
                    "domain_length": 0,
                    "hmm_from": None,
                    "hmm_to": None,
                    "hmm_coverage": 0.0,
                    "domain_i_evalue": None,
                    "domain_score": None,
                    "domain_qc": "FAIL_NO_PF00067_DOMAIN",
                }
            )
            continue
        included = [domain for domain in hit.domains if domain.i_evalue <= 1e-5]
        if not included:
            best = min(hit.domains, key=lambda domain: domain.i_evalue)
            qc = "FAIL_WEAK_PF00067_DOMAIN"
        else:
            best = max(included, key=lambda domain: domain.score)
            qc = (
                "PASS_SINGLE_PF00067_DOMAIN" if len(included) == 1 else "AMBIGUOUS_MULTIPLE_DOMAINS"
            )
        alignment = best.alignment
        hmm_coverage = (alignment.hmm_to - alignment.hmm_from + 1) / hmm.M
        if qc.startswith("PASS") and hmm_coverage < 0.6:
            qc = "FAIL_PARTIAL_PF00067_DOMAIN"
        start, end = best.env_from, best.env_to
        rows.append(
            {
                **row._asdict(),
                "sequence_length": len(row.protein_sequence),
                "domain_count": len(included),
                "domain_sequence": row.protein_sequence[start - 1 : end],
                "domain_start": start,
                "domain_end": end,
                "domain_length": end - start + 1,
                "hmm_from": alignment.hmm_from,
                "hmm_to": alignment.hmm_to,
                "hmm_coverage": hmm_coverage,
                "domain_i_evalue": best.i_evalue,
                "domain_score": best.score,
                "domain_qc": qc,
            }
        )

    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(rows)
    full_length_pass = (
        frame["sequence_length"].between(300, 700)
        & frame["domain_i_evalue"].notna()
        & frame["domain_i_evalue"].le(1e-5)
    )
    extracted_fusion_pass = (
        frame["sequence_length"].gt(700)
        & frame["domain_length"].ge(300)
        & frame["hmm_coverage"].ge(0.6)
        & frame["domain_i_evalue"].le(1e-5)
    )
    frame["identity_qc"] = "EXCLUDE_SEQUENCE_OR_DOMAIN_QC"
    frame.loc[full_length_pass, "identity_qc"] = "PASS_FULL_LENGTH_P450"
    frame.loc[extracted_fusion_pass, "identity_qc"] = "PASS_EXTRACTED_P450_DOMAIN"
    frame["identity_sequence"] = ""
    frame.loc[full_length_pass, "identity_sequence"] = frame.loc[
        full_length_pass, "protein_sequence"
    ]
    frame.loc[extracted_fusion_pass, "identity_sequence"] = frame.loc[
        extracted_fusion_pass, "domain_sequence"
    ]
    frame.to_parquet(output / "protein_domains.parquet", index=False)
    frame.to_csv(output / "protein_domains.csv", index=False)
    passed = frame[frame["identity_qc"].str.startswith("PASS")].copy()
    passed[["sequence_hash", "protein_name", "identity_sequence"]].rename(
        columns={"identity_sequence": "protein_sequence"}
    ).to_parquet(output / "domain_proteins_for_identity.parquet", index=False)
    summary = {
        "input_sequences": len(frame),
        "pfam_model": "PF00067.28",
        "pfam_length": hmm.M,
        "domain_qc_counts": frame["domain_qc"].value_counts().to_dict(),
        "identity_qc_counts": frame["identity_qc"].value_counts().to_dict(),
        "passed_sequences": len(passed),
        "identity_sequence_length_summary": passed["identity_sequence"]
        .str.len()
        .describe()
        .to_dict(),
        "coordinate_convention": "1-based inclusive in domain_start/domain_end",
        "identity_policy": "Use full sequence for 300-700 aa proteins with PF00067 i-Evalue <=1e-5; use extracted PF00067 envelope for >700 aa fusions only when envelope >=300 aa and HMM coverage >=0.6.",
    }
    (output / "domain_qc_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
