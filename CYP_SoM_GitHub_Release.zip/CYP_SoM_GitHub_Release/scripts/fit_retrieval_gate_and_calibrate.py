from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss

from cyp_som.metrics import best_mcc_threshold, binary_metrics


def blend(frame: pd.DataFrame, minimum_identity: float, alpha: float) -> np.ndarray:
    base = frame["base_probability"].to_numpy(dtype=float)
    retrieved = frame["retrieval_probability"].fillna(0.0).to_numpy(dtype=float)
    active = frame["retrieval_available"].to_numpy(dtype=bool) & (
        frame["retrieval_max_sequence_identity"].to_numpy(dtype=float) >= minimum_identity
    )
    output = base.copy()
    output[active] = (1.0 - alpha) * base[active] + alpha * retrieved[active]
    return np.clip(output, 0.0, 1.0)


def risk_coverage(frame: pd.DataFrame, scores: np.ndarray, threshold: float) -> pd.DataFrame:
    data = frame[["reaction_id", "label"]].copy()
    data["score"] = scores
    reaction_confidence = (
        data.assign(confidence=np.abs(scores - 0.5) * 2.0)
        .groupby("reaction_id")["confidence"]
        .mean()
        .sort_values(ascending=False)
    )
    rows = []
    for coverage in np.linspace(0.1, 1.0, 10):
        count = max(1, round(len(reaction_confidence) * coverage))
        selected = set(reaction_confidence.head(count).index)
        keep = data[data["reaction_id"].isin(selected)]
        metrics = binary_metrics(keep["label"], keep["score"], threshold)
        rows.append(
            {
                "coverage": float(coverage),
                "reactions": len(selected),
                "candidate_bonds": len(keep),
                **metrics,
            }
        )
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Fit a reliability gate and Platt calibration on train-derived OOF features"
    )
    parser.add_argument("--calibration", nargs="+", required=True)
    parser.add_argument("--test", nargs="+", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    calibration = pd.concat([pd.read_parquet(path) for path in args.calibration], ignore_index=True)
    tests = pd.concat([pd.read_parquet(path) for path in args.test], ignore_index=True)
    if set(calibration["reaction_id"]) & set(tests["reaction_id"]):
        raise ValueError("Calibration and test reactions overlap")

    candidates = []
    for minimum_identity in np.linspace(0.0, 0.9, 10):
        for alpha in np.linspace(0.0, 1.0, 5):
            scores = blend(calibration, float(minimum_identity), float(alpha))
            candidates.append(
                (
                    brier_score_loss(calibration["label"], scores),
                    float(minimum_identity),
                    float(alpha),
                )
            )
    calibration_brier, minimum_identity, alpha = min(candidates)
    blended_calibration = blend(calibration, minimum_identity, alpha)
    platt = LogisticRegression(solver="lbfgs")
    platt.fit(blended_calibration.reshape(-1, 1), calibration["label"])
    calibrated_oof = platt.predict_proba(blended_calibration.reshape(-1, 1))[:, 1]
    threshold, threshold_mcc = best_mcc_threshold(calibration["label"], calibrated_oof)

    target = Path(args.output)
    target.mkdir(parents=True, exist_ok=True)
    joblib.dump(platt, target / "platt_calibrator.joblib")
    output_frames = []
    group_metrics = {}
    for group, frame in tests.groupby("benchmark_group"):
        blended = blend(frame, minimum_identity, alpha)
        calibrated = platt.predict_proba(blended.reshape(-1, 1))[:, 1]
        output = frame.copy()
        output["gated_probability"] = blended
        output["calibrated_probability"] = calibrated
        output_frames.append(output)
        group_metrics[group] = binary_metrics(frame["label"], calibrated, threshold)
        risk_coverage(output, calibrated, threshold).to_csv(
            target / f"{group}_risk_coverage.csv", index=False
        )
    pd.concat(output_frames, ignore_index=True).to_parquet(
        target / "test_predictions.parquet", index=False
    )
    metrics = {
        "selection_data": "train-derived inner-fold OOF only",
        "minimum_identity": minimum_identity,
        "alpha": alpha,
        "calibration_brier_before_platt": calibration_brier,
        "threshold": threshold,
        "threshold_oof_mcc": threshold_mcc,
        "groups": group_metrics,
    }
    (target / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
