from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def make_batches(
    records: list[tuple[str, str]], token_budget: int, max_batch_size: int
) -> list[list[tuple[str, str]]]:
    ordered = sorted(records, key=lambda item: len(item[1]))
    batches: list[list[tuple[str, str]]] = []
    current: list[tuple[str, str]] = []
    longest = 0
    for record in ordered:
        proposed_longest = max(longest, len(record[1]) + 2)
        if current and (
            len(current) >= max_batch_size or proposed_longest * (len(current) + 1) > token_budget
        ):
            batches.append(current)
            current = []
            longest = 0
        current.append(record)
        longest = max(longest, len(record[1]) + 2)
    if current:
        batches.append(current)
    return batches


def normalize_sequence(value: object, fallback: str | None = None) -> str:
    text = str(value).strip()
    if text.startswith("(") and text.endswith(")"):
        indices = ast.literal_eval(text)
        if fallback is None:
            raise ValueError("Region indices require a model_sequence fallback")
        return "".join(fallback[int(index)] for index in indices)
    return text


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Cache resumable frozen ESM-2 650M global protein embeddings"
    )
    parser.add_argument("--proteins", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--sequence-column", default="model_sequence")
    parser.add_argument("--output", required=True)
    parser.add_argument("--resume-dir")
    parser.add_argument("--token-budget", type=int, default=10000)
    parser.add_argument("--max-batch-size", type=int, default=16)
    parser.add_argument("--repr-layer", type=int, default=33)
    parser.add_argument("--dtype", choices=["float16", "bfloat16", "float32"], default="bfloat16")
    args = parser.parse_args()
    try:
        import esm
        import torch
    except ImportError as error:
        raise RuntimeError("Install PyTorch and fair-esm before caching ESM-2") from error

    checkpoint = Path(args.checkpoint).resolve()
    regression = checkpoint.with_suffix("")
    regression = regression.with_name(regression.name + "-contact-regression.pt")
    if not checkpoint.is_file() or checkpoint.stat().st_size < 2_000_000_000:
        raise ValueError(f"Missing or incomplete fair-esm checkpoint: {checkpoint}")
    if not regression.is_file():
        raise ValueError(f"Missing co-located contact-regression checkpoint: {regression}")

    proteins = pd.read_parquet(args.proteins)
    required = {"sequence_hash", args.sequence_column}
    if not required.issubset(proteins.columns):
        raise ValueError(f"Protein table must contain {sorted(required)}")
    if args.sequence_column in {"pocket_sequence", "srs_sequence"}:
        region = proteins[["sequence_hash", args.sequence_column]].copy()
        model_path = Path(args.proteins).with_name("proteins_for_model.parquet")
        model = pd.read_parquet(model_path)[["sequence_hash", "model_sequence"]]
        proteins = region.merge(model, on="sequence_hash", how="left")
        proteins["model_sequence"] = proteins.apply(
            lambda row: normalize_sequence(row[args.sequence_column], row["model_sequence"]),
            axis=1,
        )
        proteins = proteins[["sequence_hash", "model_sequence"]]
    else:
        proteins = proteins[["sequence_hash", args.sequence_column]].rename(
            columns={args.sequence_column: "model_sequence"}
        )
    proteins = (
        proteins.dropna(subset=["model_sequence"])
        .drop_duplicates("sequence_hash")
        .sort_values("sequence_hash")
    )
    proteins = proteins[proteins["model_sequence"].astype(str).str.len().gt(0)]
    records = [
        (str(row.sequence_hash), str(row.model_sequence))
        for row in proteins.itertuples(index=False)
    ]
    if not records or max(len(sequence) for _, sequence in records) > 1022:
        raise ValueError("Model sequences must be non-empty and at most 1,022 residues")

    target = Path(args.output)
    resume = Path(args.resume_dir) if args.resume_dir else target.with_suffix(".parts")
    resume.mkdir(parents=True, exist_ok=True)
    missing = [
        (key, sequence) for key, sequence in records if not (resume / f"{key}.npy").is_file()
    ]
    if missing:
        # fair-esm 2.0 checkpoints contain argparse.Namespace metadata. PyTorch 2.6+
        # defaults to weights_only=True, so explicitly allow the trusted, checksum-pinned file.
        os.environ.setdefault("TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD", "1")
        model, alphabet = esm.pretrained.load_model_and_alphabet_local(str(checkpoint))
        model.eval()
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model = model.to(device)
        batch_converter = alphabet.get_batch_converter()
        torch_dtype = {
            "float16": torch.float16,
            "bfloat16": torch.bfloat16,
            "float32": torch.float32,
        }[args.dtype]
        batches = make_batches(missing, args.token_budget, args.max_batch_size)
        completed = len(records) - len(missing)
        with torch.inference_mode():
            for batch_index, batch in enumerate(batches, start=1):
                _, _, tokens = batch_converter(batch)
                tokens = tokens.to(device, non_blocking=True)
                with torch.autocast(
                    device_type=device.type,
                    dtype=torch_dtype,
                    enabled=device.type == "cuda" and torch_dtype != torch.float32,
                ):
                    result = model(tokens, repr_layers=[args.repr_layer], return_contacts=False)
                representation = result["representations"][args.repr_layer]
                for index, (sequence_hash, sequence) in enumerate(batch):
                    vector = representation[index, 1 : len(sequence) + 1].float().mean(dim=0)
                    np.save(
                        resume / f"{sequence_hash}.npy", vector.cpu().numpy().astype(np.float32)
                    )
                completed += len(batch)
                print(
                    f"batch {batch_index}/{len(batches)}; cached {completed}/{len(records)}",
                    flush=True,
                )
        del model
        if device.type == "cuda":
            torch.cuda.empty_cache()
    else:
        device = "cache-only"

    hashes = np.asarray([key for key, _ in records], dtype="U64")
    matrix = np.stack([np.load(resume / f"{key}.npy") for key in hashes]).astype(np.float32)
    target.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(target, sequence_hash=hashes, embedding=matrix)
    manifest = {
        "model": "esm2_t33_650M_UR50D",
        "checkpoint": checkpoint.name,
        "checkpoint_bytes": checkpoint.stat().st_size,
        "checkpoint_sha256": sha256(checkpoint),
        "contact_regression_sha256": sha256(regression),
        "repr_layer": args.repr_layer,
        "device": str(device),
        "proteins": len(hashes),
        "embedding_dim": int(matrix.shape[1]),
        "model_sequence_min": min(len(sequence) for _, sequence in records),
        "model_sequence_max": max(len(sequence) for _, sequence in records),
        "dtype_on_disk": "float32",
        "resume_dir": str(resume),
    }
    target.with_suffix(".json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
