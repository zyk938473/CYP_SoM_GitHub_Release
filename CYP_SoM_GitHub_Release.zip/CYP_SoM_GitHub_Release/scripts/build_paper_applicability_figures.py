from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

from cyp_som.reliability import reaction_weights, weighted_mcc

matplotlib.use("Agg")
import matplotlib.pyplot as plt

GROUPS = ["G00_control", "G01_protein_ood", "G10_scaffold_ood", "G11_double_ood"]
IDENTITY_EDGES = [0.0, 0.2, 0.4, 0.6, 0.8, 1.001]
X_DEFINITIONS = {
    "molecule_similarity": (
        "retrieval_max_molecule_similarity",
        [0.0, 0.3, 0.5, 0.7, 0.85, 1.001],
        "Maximum molecule similarity",
    ),
    "mcs_coverage": (
        "retrieval_max_mcs_coverage",
        [0.0, 0.4, 0.6, 0.75, 0.9, 1.001],
        "Maximum MCS coverage",
    ),
}
KEY = ["reaction_id", "bond_idx", "label"]


def reaction_metrics(frame: pd.DataFrame) -> dict[str, float]:
    truth = frame["label"].to_numpy(int)
    base = np.clip(frame["probability_base"].to_numpy(float), 1e-7, 1 - 1e-7)
    joint = np.clip(frame["probability_joint"].to_numpy(float), 1e-7, 1 - 1e-7)
    base_loss = -np.mean(truth * np.log(base) + (1 - truth) * np.log1p(-base))
    joint_loss = -np.mean(truth * np.log(joint) + (1 - truth) * np.log1p(-joint))
    ap_delta = (
        average_precision_score(truth, joint) - average_precision_score(truth, base)
        if len(np.unique(truth)) == 2
        else float("nan")
    )
    return {
        "delta_logloss": float(joint_loss - base_loss),
        "delta_reaction_ap": float(ap_delta),
    }


def collect_runs(stage10a: Path, splits: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    reaction_rows = []
    candidate_rows = []
    for run in sorted((stage10a / "global").glob("outer_*/seed_*")):
        split = run.parent.name
        seed = run.name.removeprefix("seed_")
        data = pd.read_parquet(run / "test_predictions.parquet")
        base = data[data["variant"].eq("R0_base")][
            KEY + ["calibrated_probability", "threshold"]
        ].rename(
            columns={
                "calibrated_probability": "probability_base",
                "threshold": "threshold_base",
            }
        )
        columns = KEY + [
            "benchmark_group",
            "calibrated_probability",
            "threshold",
            "retrieval_max_sequence_identity",
            "retrieval_max_molecule_similarity",
            "retrieval_max_mcs_coverage",
            "retrieval_effective_neighbors",
        ]
        joint = data[data["variant"].eq("R4_joint")][columns].rename(
            columns={
                "calibrated_probability": "probability_joint",
                "threshold": "threshold_joint",
            }
        )
        frame = base.merge(joint, on=KEY, validate="one_to_one")
        metadata = pd.read_parquet(splits / split / "reaction_splits.parquet")[
            [
                "reaction_id",
                "protein_cluster",
                "scaffold",
            ]
        ]
        frame = frame.merge(metadata, on="reaction_id", validate="many_to_one")
        for reaction_id, group in frame.groupby("reaction_id", sort=False):
            metrics = reaction_metrics(group)
            reaction_rows.append(
                {
                    "split": split,
                    "seed": seed,
                    "reaction_id": reaction_id,
                    "group": group["benchmark_group"].iloc[0],
                    "protein_cluster": group["protein_cluster"].iloc[0],
                    "scaffold": group["scaffold"].iloc[0],
                    "sequence_identity": group["retrieval_max_sequence_identity"].max(),
                    "molecule_similarity": group["retrieval_max_molecule_similarity"].max(),
                    "mcs_coverage": group["retrieval_max_mcs_coverage"].max(),
                    "effective_neighbors": group["retrieval_effective_neighbors"].max(),
                    **metrics,
                }
            )
        candidate_rows.append(frame.assign(split=split, seed=seed))
    return pd.DataFrame(reaction_rows), pd.concat(candidate_rows, ignore_index=True)


def bin_frame(frame: pd.DataFrame, x_name: str, x_edges: list[float]) -> pd.DataFrame:
    result = frame.copy()
    result["identity_bin"] = pd.cut(
        result["sequence_identity"], IDENTITY_EDGES, right=False, include_lowest=True
    ).astype(str)
    result["x_bin"] = pd.cut(result[x_name], x_edges, right=False, include_lowest=True).astype(str)
    return result


def calculate_cells(
    reactions: pd.DataFrame, candidates: pd.DataFrame, x_key: str, x_edges: list[float]
) -> pd.DataFrame:
    binned = bin_frame(reactions, x_key, x_edges)
    instances = (
        binned.groupby(["split", "reaction_id", "group", "identity_bin", "x_bin"], observed=True)
        .agg(
            protein_cluster=("protein_cluster", "first"),
            scaffold_cluster=("scaffold", "first"),
            sequence_identity=("sequence_identity", "mean"),
            x_value=(x_key, "mean"),
            delta_logloss=("delta_logloss", "mean"),
            delta_reaction_ap=("delta_reaction_ap", "mean"),
        )
        .reset_index()
    )
    instances["negative_transfer"] = instances["delta_logloss"] > 0
    cells = (
        instances.groupby(["group", "identity_bin", "x_bin"], observed=True)
        .agg(
            evaluation_instances=("reaction_id", "size"),
            unique_reactions=("reaction_id", "nunique"),
            protein_clusters=("protein_cluster", "nunique"),
            scaffold_clusters=("scaffold_cluster", "nunique"),
            mean_delta_logloss=("delta_logloss", "mean"),
            mean_delta_reaction_ap=("delta_reaction_ap", "mean"),
            negative_transfer_rate=("negative_transfer", "mean"),
        )
        .reset_index()
    )
    run_reactions = reactions[["split", "seed", "reaction_id", x_key, "sequence_identity"]]
    run_reactions = bin_frame(run_reactions, x_key, x_edges)[
        ["split", "seed", "reaction_id", "identity_bin", "x_bin"]
    ]
    candidate = candidates.merge(
        run_reactions,
        on=["split", "seed", "reaction_id"],
        how="left",
        validate="many_to_one",
    )
    mcc_rows = []
    for keys, group in candidate.groupby(
        ["split", "seed", "benchmark_group", "identity_bin", "x_bin"], observed=True
    ):
        if group["reaction_id"].nunique() < 3:
            continue
        weights = reaction_weights(group["reaction_id"])
        truth = group["label"].to_numpy(int)
        delta = weighted_mcc(
            truth,
            group["probability_joint"].to_numpy() >= group["threshold_joint"].iloc[0],
            weights,
        ) - weighted_mcc(
            truth,
            group["probability_base"].to_numpy() >= group["threshold_base"].iloc[0],
            weights,
        )
        mcc_rows.append(
            {
                "split": keys[0],
                "seed": keys[1],
                "group": keys[2],
                "identity_bin": keys[3],
                "x_bin": keys[4],
                "delta_mcc": delta,
            }
        )
    mcc = (
        pd.DataFrame(mcc_rows)
        .groupby(["group", "identity_bin", "x_bin"], observed=True)["delta_mcc"]
        .mean()
        .reset_index()
    )
    cells = cells.merge(
        mcc, on=["group", "identity_bin", "x_bin"], how="left", validate="one_to_one"
    )
    cells["supported"] = (
        (cells["evaluation_instances"] >= 10)
        & (cells["protein_clusters"] >= 3)
        & (cells["scaffold_clusters"] >= 3)
    )
    cells["x_axis"] = x_key
    return cells


def matrix(frame: pd.DataFrame, value: str) -> pd.DataFrame:
    return frame.pivot(index="identity_bin", columns="x_bin", values=value).sort_index(
        ascending=True
    )


def plot_group(frame: pd.DataFrame, group: str, x_label: str, output: Path, x_key: str) -> None:
    data = frame[frame["group"].eq(group)].copy()
    support = matrix(data, "supported").astype("boolean").fillna(False).astype(bool)
    panels = [
        ("evaluation_instances", "Evaluation instances", "Blues", 0, None),
        ("delta_mcc", "R4 − R0 reaction-weighted MCC", "RdBu", -0.4, 0.4),
        ("mean_delta_logloss", "Mean Δ reaction log loss", "RdBu_r", -0.15, 0.15),
        ("negative_transfer_rate", "Negative-transfer rate", "magma", 0, 1),
    ]
    figure, axes = plt.subplots(2, 2, figsize=(10.2, 7.7), constrained_layout=True)
    for axis, (value, title, cmap, vmin, vmax) in zip(axes.ravel(), panels, strict=True):
        table = matrix(data, value).reindex(index=support.index, columns=support.columns)
        shown = table.where(support | (value == "evaluation_instances"))
        image = axis.imshow(
            shown.to_numpy(float), origin="lower", aspect="auto", cmap=cmap, vmin=vmin, vmax=vmax
        )
        axis.set_xticks(range(len(table.columns)), table.columns, rotation=35, ha="right")
        axis.set_yticks(range(len(table.index)), table.index)
        axis.set_xlabel(x_label)
        axis.set_ylabel("Maximum sequence identity")
        axis.set_title(title)
        figure.colorbar(image, ax=axis, shrink=0.8)
        for row in range(len(table.index)):
            for column in range(len(table.columns)):
                match = data[
                    data["identity_bin"].eq(table.index[row])
                    & data["x_bin"].eq(table.columns[column])
                ]
                if match.empty:
                    continue
                record = match.iloc[0]
                if value == "evaluation_instances":
                    text = (
                        f"n={int(record.evaluation_instances)}\n"
                        f"P={int(record.protein_clusters)},S={int(record.scaffold_clusters)}"
                    )
                elif not record.supported:
                    text = "insufficient"
                else:
                    text = f"{record[value]:.2f}"
                axis.text(column, row, text, ha="center", va="center", fontsize=6.5)
    figure.suptitle(f"Applicability domain: {group}")
    figure.savefig(output / f"applicability_{x_key}_{group}.png", bbox_inches="tight", dpi=300)
    figure.savefig(output / f"applicability_{x_key}_{group}.pdf", bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage10a", required=True)
    parser.add_argument("--splits", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    target = Path(args.output)
    figures = target / "figures"
    target.mkdir(parents=True, exist_ok=True)
    figures.mkdir(parents=True, exist_ok=True)
    reactions, candidates = collect_runs(Path(args.stage10a), Path(args.splits))
    reactions.to_parquet(target / "applicability_reaction_seed_rows.parquet", index=False)
    all_cells = []
    for x_key, (_, edges, label) in X_DEFINITIONS.items():
        cells = calculate_cells(reactions, candidates, x_key, edges)
        all_cells.append(cells)
        for group in GROUPS:
            plot_group(cells, group, label, figures, x_key)
    pd.concat(all_cells, ignore_index=True).to_csv(target / "applicability_cells.csv", index=False)
    print(f"Applicability: {reactions['reaction_id'].nunique()} reactions, {len(all_cells)} maps")


if __name__ == "__main__":
    main()
