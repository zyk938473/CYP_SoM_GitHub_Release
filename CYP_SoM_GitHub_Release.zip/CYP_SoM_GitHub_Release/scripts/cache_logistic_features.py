from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from cyp_som.baseline import _bond_features


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bonds", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    target = Path(args.output)
    target.mkdir(parents=True, exist_ok=True)
    features_path = target / "features.npy"
    index_path = target / "index.parquet"
    if features_path.is_file() and index_path.is_file():
        print("logistic feature cache already exists")
        return
    bonds = pd.read_parquet(args.bonds)
    features = _bond_features(bonds)
    np.save(features_path, features, allow_pickle=False)
    bonds[["reaction_id", "bond_idx", "label", "atom_mapping_ok"]].to_parquet(
        index_path, index=False
    )
    manifest = {
        "rows": len(bonds),
        "feature_dim": int(features.shape[1]),
        "dtype": str(features.dtype),
        "bytes": features_path.stat().st_size,
    }
    (target / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
