from __future__ import annotations

import argparse
import json
import os
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

from cyp_som.reliability import reaction_weights, weighted_mcc


def bootstrap_job(arguments: tuple[str, str, str, str, str, int, int]) -> list[dict]:
    model, split, group, root_value, splits_value, replicates, seed = arguments
    root = Path(root_value)
    split_root = root / model / split
    frames = []
    for run in sorted(split_root.glob("seed_*/")):
        data = pd.read_parquet(run / "test_predictions.parquet")
        metrics = json.loads((run / "metrics.json").read_text(encoding="utf-8"))
        data = data[data["benchmark_group"].eq(group)]
        base = data[data["variant"].eq("R0_base")].copy()
        joint = data[data["variant"].eq("R4_joint")].copy()
        key = ["reaction_id", "bond_idx", "label"]
        frame = base[key + ["calibrated_probability"]].merge(
            joint[key + ["calibrated_probability"]],
            on=key,
            suffixes=("_base", "_joint"),
            validate="one_to_one",
        )
        frame["threshold_base"] = metrics["variants"]["R0_base"]["threshold"]
        frame["threshold_joint"] = metrics["variants"]["R4_joint"]["threshold"]
        frames.append(frame)
    reference_keys = frames[0][["reaction_id", "bond_idx", "label"]].reset_index(drop=True)
    for frame in frames[1:]:
        if not reference_keys.equals(
            frame[["reaction_id", "bond_idx", "label"]].reset_index(drop=True)
        ):
            raise ValueError(f"Candidate rows differ across seeds for {model}/{split}/{group}")
    metadata = pd.read_parquet(Path(splits_value) / split / "reaction_splits.parquet")[
        ["reaction_id", "protein_cluster", "scaffold"]
    ]
    frames = [frame.merge(metadata, on="reaction_id", validate="many_to_one") for frame in frames]
    reference = frames[0]
    proteins = reference["protein_cluster"].unique()
    scaffolds = reference["scaffold"].unique()
    protein_position = {value: index for index, value in enumerate(proteins)}
    scaffold_position = {value: index for index, value in enumerate(scaffolds)}
    p_index = reference["protein_cluster"].map(protein_position).to_numpy()
    s_index = reference["scaffold"].map(scaffold_position).to_numpy()
    base_reaction_weights = reaction_weights(reference["reaction_id"])
    truth = reference["label"].to_numpy(dtype=int)
    rng = np.random.default_rng(seed)
    rows = []
    for replicate in range(replicates):
        cluster_weight = (
            rng.poisson(1.0, len(proteins))[p_index] * rng.poisson(1.0, len(scaffolds))[s_index]
        )
        weights = base_reaction_weights * cluster_weight
        if weights.sum() == 0 or weights[truth == 1].sum() == 0:
            continue
        deltas = {"mcc": [], "pr_auc": [], "brier": []}
        for frame in frames:
            base = frame["calibrated_probability_base"].to_numpy()
            joint = frame["calibrated_probability_joint"].to_numpy()
            deltas["mcc"].append(
                weighted_mcc(truth, joint >= frame["threshold_joint"].iloc[0], weights)
                - weighted_mcc(truth, base >= frame["threshold_base"].iloc[0], weights)
            )
            deltas["pr_auc"].append(
                average_precision_score(truth, joint, sample_weight=weights)
                - average_precision_score(truth, base, sample_weight=weights)
            )
            deltas["brier"].append(
                np.average(np.square(joint - truth), weights=weights)
                - np.average(np.square(base - truth), weights=weights)
            )
        rows.append(
            {
                "model": model,
                "split": split,
                "group": group,
                "replicate": replicate,
                **{f"delta_{key}": float(np.mean(value)) for key, value in deltas.items()},
            }
        )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage10a", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--splits", required=True)
    parser.add_argument("--replicates", type=int, default=500)
    parser.add_argument("--workers", type=int, default=max(1, min(8, (os.cpu_count() or 2) // 2)))
    parser.add_argument("--seed", type=int, default=20260831)
    args = parser.parse_args()
    root = Path(args.stage10a)
    jobs = []
    for model_dir in sorted(path for path in root.iterdir() if path.is_dir()):
        for split_dir in sorted(model_dir.glob("outer_*/")):
            sample = next(split_dir.glob("seed_*/test_predictions.parquet"), None)
            if sample is None:
                continue
            groups = pd.read_parquet(sample, columns=["benchmark_group"])[
                "benchmark_group"
            ].unique()
            for group in groups:
                jobs.append(
                    (
                        model_dir.name,
                        split_dir.name,
                        str(group),
                        str(root),
                        args.splits,
                        args.replicates,
                        args.seed + len(jobs),
                    )
                )
    rows = []
    with ProcessPoolExecutor(max_workers=min(args.workers, len(jobs))) as pool:
        for result in pool.map(bootstrap_job, jobs):
            rows.extend(result)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(rows)
    frame.to_parquet(output, index=False)
    summary = frame.groupby(["model", "group"])[["delta_mcc", "delta_pr_auc", "delta_brier"]].agg(
        ["mean", lambda values: values.quantile(0.025), lambda values: values.quantile(0.975)]
    )
    summary.to_csv(output.with_suffix(".summary.csv"))


if __name__ == "__main__":
    main()
