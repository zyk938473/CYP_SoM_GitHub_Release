from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

BANK_COLUMNS = [
    "reaction_id",
    "pair_id",
    "sequence_hash",
    "protein_sequence",
    "protein_pocket",
    "protein_srs",
    "canonical_smiles",
    "inchikey",
    "scaffold",
    "canonical_positive_sites",
    "evidence_tier",
]


def main() -> None:
    parser = argparse.ArgumentParser(description="Build leakage-audited train-only retrieval banks")
    parser.add_argument("--reactions", required=True)
    parser.add_argument("--splits", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    reactions = pd.read_parquet(args.reactions)
    split = pd.read_parquet(args.splits)[["reaction_id", "benchmark_group"]]
    data = reactions.merge(split, on="reaction_id", how="inner", validate="one_to_one")
    train = data[data["benchmark_group"].eq("train")].copy()
    held_out = data[~data["benchmark_group"].eq("train")].copy()
    if train.empty or held_out.empty:
        raise ValueError("Both train and held-out reactions are required")

    target = Path(args.output)
    target.mkdir(parents=True, exist_ok=True)
    banks = {
        "sequence": train.drop_duplicates("sequence_hash"),
        "pocket": train.drop_duplicates(["sequence_hash", "protein_pocket"]),
        "molecule": train.drop_duplicates("inchikey"),
        "scaffold": train.drop_duplicates("scaffold"),
        "pair": train.drop_duplicates("pair_id"),
    }
    for name, bank in banks.items():
        columns = [column for column in BANK_COLUMNS if column in bank.columns]
        bank[columns].to_parquet(target / f"{name}_bank.parquet", index=False)

    audit = {
        "train_reactions": len(train),
        "held_out_reactions": len(held_out),
        "banks": {},
        "policy": "Only benchmark_group=train rows may populate retrieval banks.",
    }
    for name, bank in banks.items():
        key = {
            "sequence": "sequence_hash",
            "pocket": "sequence_hash",
            "molecule": "inchikey",
            "scaffold": "scaffold",
            "pair": "pair_id",
        }[name]
        train_keys = set(train[key].dropna())
        held_keys = set(held_out[key].dropna())
        audit["banks"][name] = {
            "rows": len(bank),
            "unique_keys": len(train_keys),
            "held_out_key_overlap_expected": len(train_keys & held_keys),
            "note": "Feature-level overlap can be legitimate for control groups; bank membership is still train-only.",
        }
    (target / "manifest.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
