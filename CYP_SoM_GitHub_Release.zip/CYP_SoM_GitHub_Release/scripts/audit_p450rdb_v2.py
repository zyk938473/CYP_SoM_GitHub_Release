from __future__ import annotations

import argparse
import hashlib
import json
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import pandas as pd

from cyp_som.chem import standardize_smiles
from cyp_som.reaction_mapping import infer_existing_bond_sites
from cyp_som.utils import stable_id


def map_one(payload: tuple[int, str, str]) -> dict[str, object]:
    row_index, substrate_smiles, product_smiles = payload
    result = infer_existing_bond_sites(substrate_smiles, product_smiles)
    return {
        "source_row": row_index,
        "mapping_status": result.status,
        "canonical_site_keys": json.dumps(result.site_keys),
        "site_kinds": json.dumps(result.site_kinds),
        "changed_substrate_bonds": json.dumps(result.changed_substrate_bonds),
        "hydrogen_substitution_atoms": json.dumps(result.hydrogen_substitution_atoms),
        "new_mapped_bonds": json.dumps(result.new_mapped_bonds),
        "mapped_heavy_atoms": result.mapped_heavy_atoms,
        "substrate_heavy_atoms": result.substrate_heavy_atoms,
        "product_heavy_atoms": result.product_heavy_atoms,
        "mapping_coverage": result.mapped_heavy_atoms / max(1, result.substrate_heavy_atoms),
        "edit_count": result.edit_count,
        "mapping_warning": result.warning,
    }


def relation(left: set[str], right: set[str]) -> str:
    if left == right:
        return "IDENTICAL"
    if left and left < right:
        return "INFERRED_SUBSET_OF_CYPMOL_UNION"
    if right and right < left:
        return "CYPMOL_SUBSET_OF_INFERRED"
    if left & right:
        return "PARTIAL_OVERLAP"
    return "DISJOINT"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reactions", required=True)
    parser.add_argument("--cypmol-reactions", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()

    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    reactions = pd.read_csv(args.reactions, encoding="gb18030", low_memory=False).reset_index(
        names="source_row"
    )
    reactions["sequence"] = (
        reactions["sequence"].astype(str).str.replace(r"\s+", "", regex=True).str.upper()
    )
    reactions["sequence_hash"] = reactions["sequence"].map(
        lambda value: hashlib.sha256(value.encode()).hexdigest()
    )

    molecule_rows = []
    for row in reactions.itertuples(index=False):
        try:
            molecule = standardize_smiles(row.sub_Smiles1)
            molecule_rows.append(
                {
                    "source_row": row.source_row,
                    "canonical_smiles": molecule.canonical_smiles,
                    "inchikey": molecule.inchikey,
                    "scaffold": molecule.scaffold_smiles,
                    "molecule_error": "" if molecule.inchikey else "EMPTY_INCHIKEY",
                }
            )
        except (ValueError, RuntimeError) as exc:
            molecule_rows.append(
                {
                    "source_row": row.source_row,
                    "canonical_smiles": "",
                    "inchikey": "",
                    "scaffold": "",
                    "molecule_error": str(exc),
                }
            )
    molecule_frame = pd.DataFrame(molecule_rows)

    payloads = [
        (row.source_row, str(row.sub_Smiles1), str(row.pro_Smiles1))
        for row in reactions.itertuples(index=False)
    ]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        mapped = list(pool.map(map_one, payloads, chunksize=16))
    mapping_frame = pd.DataFrame(mapped)
    audit = reactions.merge(molecule_frame, on="source_row").merge(mapping_frame, on="source_row")
    audit["source_reaction_id"] = audit.apply(
        lambda row: stable_id(
            "p450rdb_v2",
            row["source_row"],
            row["sequence_hash"],
            row["inchikey"],
            prefix="p450r_",
        ),
        axis=1,
    )
    audit["pair_id"] = audit.apply(
        lambda row: stable_id(row["sequence_hash"], row["inchikey"], prefix="pair_"), axis=1
    )
    audit["has_reaction_provenance"] = (
        audit[["PMID", "DOI", "Patent ID", "Title"]].notna().any(axis=1)
    )
    audit["candidate_for_existing_bond_benchmark"] = (
        audit["mapping_status"].eq("MAPPED")
        & audit["molecule_error"].eq("")
        & audit["has_reaction_provenance"]
        & audit["mapping_coverage"].ge(0.7)
        & audit["canonical_site_keys"].ne("[]")
    )

    cypmol = pd.read_parquet(args.cypmol_reactions)
    cypmol_sites = {
        (row.sequence_hash, row.inchikey): set(json.loads(row.canonical_positive_sites))
        for row in cypmol.itertuples(index=False)
    }
    comparisons = []
    for row in audit.itertuples(index=False):
        key = (row.sequence_hash, row.inchikey)
        if key not in cypmol_sites:
            continue
        inferred = set(json.loads(row.canonical_site_keys))
        known = cypmol_sites[key]
        comparisons.append(
            {
                "source_row": row.source_row,
                "source_reaction_id": row.source_reaction_id,
                "pair_id": row.pair_id,
                "mapping_status": row.mapping_status,
                "inferred_sites": json.dumps(sorted(inferred)),
                "cypmol_union_sites": json.dumps(sorted(known)),
                "relation": relation(inferred, known),
            }
        )
    comparison_frame = pd.DataFrame(comparisons)

    audit.to_parquet(output / "reaction_mapping_audit.parquet", index=False)
    audit.to_csv(output / "reaction_mapping_audit.csv", index=False)
    comparison_frame.to_csv(output / "cypmol_site_validation.csv", index=False)
    candidate = audit[audit["candidate_for_existing_bond_benchmark"]].copy()
    candidate.to_parquet(output / "candidate_reactions.parquet", index=False)
    candidate.to_csv(output / "candidate_reactions.csv", index=False)

    cypmol_sequences = set(cypmol["sequence_hash"])
    new_sequence_candidates = candidate[~candidate["sequence_hash"].isin(cypmol_sequences)]
    mapped_comparisons = comparison_frame[comparison_frame["mapping_status"] == "MAPPED"]
    summary = {
        "source_rows": len(audit),
        "unique_sequences": int(audit["sequence_hash"].nunique()),
        "unique_pairs": int(audit["pair_id"].nunique()),
        "species_categories": audit["Species"].value_counts(dropna=False).to_dict(),
        "mapping_status": audit["mapping_status"].value_counts(dropna=False).to_dict(),
        "candidate_reactions": len(candidate),
        "candidate_pairs": int(candidate["pair_id"].nunique()),
        "candidate_sequences": int(candidate["sequence_hash"].nunique()),
        "new_sequence_candidate_reactions": len(new_sequence_candidates),
        "new_sequence_candidate_pairs": int(new_sequence_candidates["pair_id"].nunique()),
        "new_candidate_sequences_vs_cypmol": int(
            new_sequence_candidates["sequence_hash"].nunique()
        ),
        "cypmol_overlap_reaction_rows": len(comparison_frame),
        "mapped_overlap_relations": mapped_comparisons["relation"].value_counts().to_dict(),
        "source_license_status": "Website states open access for academic research; no standard dataset license identified. Do not redistribute without written clarification.",
    }
    (output / "audit_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
