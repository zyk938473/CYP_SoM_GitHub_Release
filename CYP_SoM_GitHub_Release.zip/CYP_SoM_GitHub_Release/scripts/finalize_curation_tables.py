from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import pandas as pd
from rdkit import Chem


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--processed-raw", required=True)
    parser.add_argument("--any-site", required=True)
    parser.add_argument("--curation-report", required=True)
    parser.add_argument("--strict-output", required=True)
    args = parser.parse_args()

    raw = Path(args.processed_raw)
    any_site = Path(args.any_site)
    report = Path(args.curation_report)
    strict_output = Path(args.strict_output)
    strict_output.mkdir(parents=True, exist_ok=True)

    reactions_raw = pd.read_parquet(raw / "reactions.parquet")
    bonds_raw = pd.read_parquet(raw / "candidate_bonds.parquet")
    reactions = pd.read_parquet(any_site / "reactions.parquet")
    bonds = pd.read_parquet(any_site / "candidate_bonds.parquet")
    queue = pd.read_csv(report / "pair_review_queue.csv")
    evidence = pd.read_csv(report / "evidence/metacyp_evidence_matches.csv")

    zero = set(reactions_raw.loc[reactions_raw["positive_bond_count"] == 0, "reaction_id"])
    pair_zero = (
        reactions_raw[reactions_raw["reaction_id"].isin(zero)]
        .groupby("pair_id")["reaction_id"]
        .agg(list)
        .to_dict()
    )
    resolution = queue.merge(
        evidence[
            [
                "pair_id",
                "metacyp_compound_name",
                "pubchem_cid",
                "evidence_match",
                "references",
                "comments",
            ]
        ],
        on="pair_id",
        how="left",
    )
    resolution["zero_positive_source_records"] = resolution["pair_id"].map(
        lambda value: json.dumps(pair_zero.get(value, []))
    )
    resolution["resolution_action_any_site"] = resolution["canonical_relation"].map(
        lambda value: (
            "MERGE_IDENTICAL" if value == "IDENTICAL" else "UNION_ALL_CANONICAL_POSITIVE_SITES"
        )
    )
    included_pairs = set(reactions["pair_id"])
    resolution["inclusive_dataset_status"] = resolution["pair_id"].map(
        lambda value: "INCLUDED" if value in included_pairs else "EXCLUDED_UNREPRESENTABLE"
    )
    resolution["human_review_required_if_any_site_endpoint"] = False
    resolution["human_review_required_if_major_site_endpoint"] = resolution[
        "canonical_relation"
    ].ne("IDENTICAL")
    resolution.to_csv(report / "pair_resolution_any_site.csv", index=False)

    unsupported = []
    for reaction in reactions_raw[reactions_raw["positive_bond_count"] == 0].itertuples(
        index=False
    ):
        group = bonds_raw[bonds_raw["reaction_id"] == reaction.reaction_id]
        smiles = str(group.iloc[0]["molecule"])
        molecule = Chem.AddHs(Chem.MolFromSmiles(smiles))
        tokens = [int(value) for value in re.findall(r"\d+", str(reaction.reaction_site_raw))]
        valid = [value for value in tokens if value < molecule.GetNumAtoms()]
        bonded = []
        for position, atom1 in enumerate(valid):
            for atom2 in valid[position + 1 :]:
                bond = molecule.GetBondBetweenAtoms(atom1, atom2)
                if bond is not None:
                    bonded.append([atom1, atom2, bond.GetIdx()])
        unsupported.append(
            {
                "reaction_id": reaction.reaction_id,
                "pair_id": reaction.pair_id,
                "protein_name": reaction.protein_name,
                "canonical_smiles": reaction.canonical_smiles,
                "reaction_site_raw": reaction.reaction_site_raw,
                "site_tokens": json.dumps(tokens),
                "valid_tokens": json.dumps(valid),
                "bonds_among_tokens": json.dumps(bonded),
                "technical_class": "NO_EXISTING_CANDIDATE_BOND"
                if not bonded
                else "LABEL_CONSTRUCTION_MISMATCH",
                "released_split": reaction.released_split,
            }
        )
    pd.DataFrame(unsupported).to_csv(
        report / "unsupported_zero_positive_reactions.csv", index=False
    )

    excluded_multiset_pairs = set(
        resolution.loc[resolution["canonical_relation"] != "IDENTICAL", "pair_id"]
    )
    strict_reactions = reactions[~reactions["pair_id"].isin(excluded_multiset_pairs)].copy()
    strict_ids = set(strict_reactions["reaction_id"])
    strict_bonds = bonds[bonds["reaction_id"].isin(strict_ids)].copy()
    strict_reactions.to_parquet(strict_output / "reactions.parquet", index=False)
    strict_reactions.to_csv(strict_output / "reactions.csv", index=False)
    strict_bonds.to_parquet(strict_output / "candidate_bonds.parquet", index=False)
    manifest = {
        "endpoint": "STRICT_SINGLE_CANONICAL_SITE_SET_SENSITIVITY",
        "site_key_version": 3,
        "reactions": len(strict_reactions),
        "candidate_bonds": len(strict_bonds),
        "positive_bonds": int(strict_bonds["label"].sum()),
        "excluded_multiset_pairs": len(excluded_multiset_pairs),
        "note": "Sensitivity dataset only; exclusion of known multi-product CYP pairs can bias chemistry and CYP coverage.",
    }
    (strict_output / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
