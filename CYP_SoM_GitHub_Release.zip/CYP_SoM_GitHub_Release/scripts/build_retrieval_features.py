from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from rdkit import Chem, DataStructs
from rdkit.Chem import rdFingerprintGenerator

from cyp_som.retrieval_mapping import transfer_neighbor_labels


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build train-only molecule-conditioned sequence retrieval features"
    )
    parser.add_argument("--reactions", required=True)
    parser.add_argument("--bonds", required=True)
    parser.add_argument("--splits", required=True)
    parser.add_argument("--identity", required=True)
    parser.add_argument("--predictions", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--provenance-output")
    parser.add_argument("--top-k", type=int, default=8)
    parser.add_argument("--preselect", type=int, default=32)
    parser.add_argument("--minimum-mcs-coverage", type=float, default=0.5)
    parser.add_argument("--temperature", type=float, default=0.1)
    parser.add_argument(
        "--ranking-mode", choices=["molecule", "joint", "sequence"], default="joint"
    )
    args = parser.parse_args()

    reactions = pd.read_parquet(args.reactions)[
        [
            "reaction_id",
            "sequence_hash",
            "canonical_smiles",
            "inchikey",
            "scaffold",
            "pair_id",
        ]
    ]
    bonds = pd.read_parquet(args.bonds)[
        [
            "reaction_id",
            "bond_idx",
            "atom1_idx",
            "atom2_idx",
            "canonical_site_key",
            "label",
        ]
    ]
    split = pd.read_parquet(args.splits)[["reaction_id", "benchmark_group"]]
    predictions = pd.read_parquet(args.predictions)
    probability_columns = [column for column in predictions if column.endswith("_probability")]
    if len(probability_columns) != 1:
        raise ValueError("Predictions must contain exactly one *_probability column")
    base_column = probability_columns[0]

    identity_payload = np.load(args.identity, allow_pickle=True)
    hashes = identity_payload["sequence_hash"].astype(str)
    identity = identity_payload["identity"]
    position = {value: index for index, value in enumerate(hashes)}
    metadata = reactions.merge(split, on="reaction_id", how="inner", validate="one_to_one")
    train = metadata[metadata["benchmark_group"].eq("train")].copy()
    train_bonds = {key: group for key, group in bonds.groupby("reaction_id", sort=False)}
    train_by_scaffold = {key: group for key, group in train.groupby("scaffold", sort=False)}

    generator = rdFingerprintGenerator.GetMorganGenerator(radius=2, fpSize=2048)
    fingerprint_cache = {}
    for row in metadata.itertuples(index=False):
        if row.inchikey not in fingerprint_cache:
            fingerprint_cache[row.inchikey] = generator.GetFingerprint(
                Chem.MolFromSmiles(row.canonical_smiles)
            )

    query = predictions.merge(
        bonds,
        on=["reaction_id", "bond_idx", "label"],
        how="left",
        validate="one_to_one",
    ).merge(
        metadata[
            [
                "reaction_id",
                "sequence_hash",
                "canonical_smiles",
                "inchikey",
                "scaffold",
                "pair_id",
            ]
        ],
        on="reaction_id",
        how="left",
        validate="many_to_one",
    )
    rows = []
    provenance_rows = []
    mapped_neighbor_edges = 0
    for reaction_id, group in query.groupby("reaction_id", sort=False):
        first = group.iloc[0]
        candidates = train_by_scaffold.get(first["scaffold"], train)
        query_fp = fingerprint_cache[first["inchikey"]]
        scored = []
        query_position = position.get(first["sequence_hash"])
        for candidate in candidates.itertuples(index=False):
            if candidate.pair_id == first["pair_id"]:
                continue
            molecule_similarity = float(
                DataStructs.TanimotoSimilarity(query_fp, fingerprint_cache[candidate.inchikey])
            )
            sequence_similarity = (
                float(identity[query_position, position[candidate.sequence_hash]])
                if query_position is not None and candidate.sequence_hash in position
                else 0.0
            )
            ranking_score = {
                "molecule": molecule_similarity,
                "joint": molecule_similarity * (0.5 + 0.5 * sequence_similarity),
                "sequence": sequence_similarity,
            }[args.ranking_mode]
            scored.append((ranking_score, molecule_similarity, sequence_similarity, candidate))
        scored = sorted(scored, key=lambda item: item[0], reverse=True)[: args.preselect]
        neighbors = []
        query_bonds = group[["bond_idx", "atom1_idx", "atom2_idx", "canonical_site_key", "label"]]
        for joint, molecule_similarity, sequence_similarity, candidate in scored:
            transferred, ambiguity, coverage = transfer_neighbor_labels(
                candidate.canonical_smiles,
                first["canonical_smiles"],
                train_bonds[candidate.reaction_id],
                query_bonds,
                minimum_coverage=args.minimum_mcs_coverage,
            )
            if np.isfinite(transferred).any():
                neighbors.append(
                    (
                        joint,
                        molecule_similarity,
                        sequence_similarity,
                        coverage,
                        transferred,
                        ambiguity,
                        candidate.reaction_id,
                        candidate.canonical_smiles,
                        candidate.sequence_hash,
                    )
                )
            if len(neighbors) >= args.top_k:
                break
        for rank, neighbor in enumerate(neighbors, start=1):
            provenance_rows.append(
                {
                    "query_reaction_id": reaction_id,
                    "neighbor_rank": rank,
                    "neighbor_reaction_id": neighbor[6],
                    "neighbor_smiles": neighbor[7],
                    "neighbor_sequence_hash": neighbor[8],
                    "ranking_score": neighbor[0],
                    "molecule_similarity": neighbor[1],
                    "sequence_identity": neighbor[2],
                    "mcs_coverage": neighbor[3],
                    "mapped_query_bonds": int(np.isfinite(neighbor[4]).sum()),
                    "transferred_positive_bonds": int(np.nansum(neighbor[4] > 0.5)),
                    "mean_mapping_ambiguity": float(np.nanmean(neighbor[5])),
                }
            )
        for output_index, row in enumerate(group.itertuples(index=False)):
            available = [
                neighbor for neighbor in neighbors if np.isfinite(neighbor[4][output_index])
            ]
            if available:
                joint_scores = np.asarray([neighbor[0] for neighbor in available])
                weights = np.exp((joint_scores - joint_scores.max()) / max(args.temperature, 1e-8))
                weights /= weights.sum()
                retrieved = float(
                    np.dot(weights, [neighbor[4][output_index] for neighbor in available])
                )
                mapped_neighbor_edges += len(available)
            else:
                weights = np.asarray([])
                retrieved = np.nan
            rows.append(
                {
                    "reaction_id": reaction_id,
                    "bond_idx": int(row.bond_idx),
                    "label": int(row.label),
                    "benchmark_group": row.benchmark_group,
                    "base_probability": float(getattr(row, base_column)),
                    "retrieval_probability": retrieved,
                    "retrieval_available": bool(available),
                    "retrieval_neighbor_count": len(available),
                    "retrieval_max_sequence_identity": max(
                        (neighbor[2] for neighbor in available), default=0.0
                    ),
                    "retrieval_max_molecule_similarity": max(
                        (neighbor[1] for neighbor in available), default=0.0
                    ),
                    "retrieval_max_mcs_coverage": max(
                        (neighbor[3] for neighbor in available), default=0.0
                    ),
                    "retrieval_effective_neighbors": float(1.0 / np.square(weights).sum())
                    if len(weights)
                    else 0.0,
                }
            )
    output = pd.DataFrame(rows)
    target = Path(args.output)
    target.parent.mkdir(parents=True, exist_ok=True)
    output.to_parquet(target, index=False)
    if args.provenance_output:
        provenance_target = Path(args.provenance_output)
        provenance_target.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(provenance_rows).to_parquet(provenance_target, index=False)
    manifest = {
        "policy": "Train-only; Morgan/scaffold preselection; configurable ranking; MCS site transfer",
        "ranking_mode": args.ranking_mode,
        "query_reactions": int(output["reaction_id"].nunique()),
        "retrieval_coverage_reactions": int(
            output.loc[output["retrieval_available"], "reaction_id"].nunique()
        ),
        "retrieval_coverage_bonds": int(output["retrieval_available"].sum()),
        "mapped_neighbor_edges": mapped_neighbor_edges,
        "top_k": args.top_k,
        "preselect": args.preselect,
        "minimum_mcs_coverage": args.minimum_mcs_coverage,
        "no_neighbor_policy": "NaN retrieval signal; gate must fall back to base model",
    }
    target.with_suffix(".json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
