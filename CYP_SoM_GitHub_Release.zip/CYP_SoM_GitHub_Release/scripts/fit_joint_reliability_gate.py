from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from cyp_som.metrics import binary_metrics
from cyp_som.reliability import (
    RELIABILITY_COLUMNS,
    MonotonicReliabilityGate,
    best_weighted_mcc_threshold,
    platt_fit,
    reaction_weights,
    weighted_metrics,
)

REGULARIZATION_GRID = (0.01, 0.1, 1.0, 10.0)
VARIANTS = ("R0_base", "R1_always", "R2_sequence", "R3_mapping", "R4_joint")


def raw_scores(frame: pd.DataFrame, variant: str, gate=None) -> np.ndarray:
    base = frame["base_probability"].to_numpy(dtype=float)
    if variant == "R0_base":
        return base
    if variant == "R1_always":
        available = frame["retrieval_available"].to_numpy(dtype=bool)
        retrieved = frame["retrieval_probability"].fillna(0.0).to_numpy(dtype=float)
        output = base.copy()
        output[available] = retrieved[available]
        return np.clip(output, 0.0, 1.0)
    if gate is None:
        raise ValueError(f"{variant} requires a fitted gate")
    return gate.predict(frame)


def weighted_logloss(frame: pd.DataFrame, scores: np.ndarray) -> float:
    truth = frame["label"].to_numpy(dtype=float)
    weights = reaction_weights(frame["reaction_id"])
    scores = np.clip(scores, 1e-7, 1 - 1e-7)
    return float(
        -np.average(truth * np.log(scores) + (1 - truth) * np.log1p(-scores), weights=weights)
    )


def select_regularization(frames: list[pd.DataFrame], columns: list[str]) -> float:
    results = []
    for regularization in REGULARIZATION_GRID:
        losses = []
        for held in range(len(frames)):
            train = pd.concat(
                [frame for index, frame in enumerate(frames) if index != held], ignore_index=True
            )
            gate = MonotonicReliabilityGate(columns, regularization).fit(train)
            losses.append(weighted_logloss(frames[held], gate.predict(frames[held])))
        results.append((float(np.mean(losses)), regularization))
    return min(results)[1]


def crossfit(
    frames: list[pd.DataFrame], variant: str
) -> tuple[pd.DataFrame, np.ndarray, dict[str, object], object | None]:
    combined = []
    scores = []
    fold_models = []
    final_gate = None
    if variant in {"R0_base", "R1_always"}:
        for fold, frame in enumerate(frames):
            part = frame.copy()
            part["inner_fold"] = fold
            combined.append(part)
            scores.append(raw_scores(frame, variant))
        return pd.concat(combined, ignore_index=True), np.concatenate(scores), {}, None

    key = variant.removeprefix("R2_").removeprefix("R3_").removeprefix("R4_")
    columns = RELIABILITY_COLUMNS[key]
    for held in range(len(frames)):
        training_frames = [frame for index, frame in enumerate(frames) if index != held]
        regularization = select_regularization(training_frames, columns)
        gate = MonotonicReliabilityGate(columns, regularization).fit(
            pd.concat(training_frames, ignore_index=True)
        )
        part = frames[held].copy()
        part["inner_fold"] = held
        combined.append(part)
        scores.append(gate.predict(frames[held]))
        fold_models.append(gate.to_dict())
    final_regularization = select_regularization(frames, columns)
    final_gate = MonotonicReliabilityGate(columns, final_regularization).fit(
        pd.concat(frames, ignore_index=True)
    )
    metadata = {
        "columns": columns,
        "fold_models": fold_models,
        "final_model": final_gate.to_dict(),
    }
    return pd.concat(combined, ignore_index=True), np.concatenate(scores), metadata, final_gate


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--calibration", nargs=3, required=True)
    parser.add_argument("--test", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    frames = [pd.read_parquet(path) for path in args.calibration]
    tests = pd.read_parquet(args.test)
    if set(pd.concat(frames)["reaction_id"]) & set(tests["reaction_id"]):
        raise ValueError("Inner OOF and outer test reactions overlap")
    target = Path(args.output)
    target.mkdir(parents=True, exist_ok=True)
    summary = {}
    prediction_frames = []
    for variant in VARIANTS:
        oof, oof_raw, gate_metadata, final_gate = crossfit(frames, variant)
        weights = reaction_weights(oof["reaction_id"])
        platt = platt_fit(oof_raw, oof["label"].to_numpy(dtype=int), weights)
        calibrated_oof = platt.predict_proba(oof_raw.reshape(-1, 1))[:, 1]
        threshold, threshold_mcc = best_weighted_mcc_threshold(
            oof["label"].to_numpy(dtype=int), calibrated_oof, weights
        )
        test_raw = raw_scores(tests, variant, final_gate)
        calibrated = platt.predict_proba(test_raw.reshape(-1, 1))[:, 1]
        output_columns = [
            "reaction_id",
            "bond_idx",
            "label",
            "benchmark_group",
            "retrieval_available",
            *RELIABILITY_COLUMNS["joint"],
        ]
        output = tests[output_columns].copy()
        output["variant"] = variant
        output["raw_probability"] = test_raw
        output["calibrated_probability"] = calibrated
        output["threshold"] = threshold
        if final_gate is not None:
            output["gate_reliability"] = final_gate.gate(tests)
        else:
            output["gate_reliability"] = (
                tests["retrieval_available"].astype(float).to_numpy()
                if variant == "R1_always"
                else 0.0
            )
        prediction_frames.append(output)
        groups = {}
        for group, frame in output.groupby("benchmark_group", sort=False):
            group_weights = reaction_weights(frame["reaction_id"])
            groups[group] = {
                **binary_metrics(frame["label"], frame["calibrated_probability"], threshold),
                **weighted_metrics(
                    frame["label"],
                    frame["calibrated_probability"],
                    group_weights,
                    threshold,
                ),
            }
        summary[variant] = {
            "threshold": threshold,
            "threshold_oof_weighted_mcc": threshold_mcc,
            "gate": gate_metadata,
            "groups": groups,
        }
        joblib.dump(platt, target / f"{variant}_platt.joblib")
    pd.concat(prediction_frames, ignore_index=True).to_parquet(
        target / "test_predictions.parquet", index=False
    )
    payload = {
        "selection_data": "three train-derived inner OOF folds only",
        "weighting": "each reaction has equal total weight",
        "variants": summary,
    }
    (target / "metrics.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({"variants": list(summary), "output": str(target)}, indent=2))


if __name__ == "__main__":
    main()
