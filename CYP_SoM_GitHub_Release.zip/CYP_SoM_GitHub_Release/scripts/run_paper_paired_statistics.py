from __future__ import annotations

import argparse
import json
import os
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

from cyp_som.reliability import reaction_weights, weighted_mcc

GROUPS = ["G00_control", "G01_protein_ood", "G10_scaffold_ood", "G11_double_ood"]
KEY = ["reaction_id", "bond_idx", "label"]


def reaction_logloss(frame: pd.DataFrame, probability: str) -> pd.Series:
    score = np.clip(frame[probability].to_numpy(float), 1e-7, 1 - 1e-7)
    truth = frame["label"].to_numpy(float)
    loss = -(truth * np.log(score) + (1 - truth) * np.log1p(-score))
    return pd.Series(loss, index=frame.index).groupby(frame["reaction_id"]).mean()


def reaction_ap(frame: pd.DataFrame, probability: str) -> pd.Series:
    def score(group: pd.DataFrame) -> float:
        if group["label"].nunique() < 2:
            return float("nan")
        return float(average_precision_score(group["label"], group[probability]))

    return frame.groupby("reaction_id", sort=False).apply(score, include_groups=False)


def load_stage11(
    root: Path, comparison: str, split: str, seed: str, group: str
) -> tuple[pd.DataFrame, float, float]:
    correct_dir = root / "cloud_download/global_esm2_film" / split / f"seed_{seed}"
    if comparison == "molecule":
        control_dir = root / "cloud_download/molecule_gnn_formal" / split / f"seed_{seed}"
        control_column = "molecule_only_probability"
    else:
        control_dir = (
            root / "reports/supplementary/protein_controls" / comparison / split / f"seed_{seed}"
        )
        control_column = "global_esm2_probability"
    correct = pd.read_parquet(correct_dir / f"{group}_predictions.parquet")
    control = pd.read_parquet(control_dir / f"{group}_predictions.parquet")
    correct = correct[KEY + ["global_esm2_probability"]].rename(
        columns={"global_esm2_probability": "probability_a"}
    )
    control = control[KEY + [control_column]].rename(columns={control_column: "probability_b"})
    frame = correct.merge(control, on=KEY, validate="one_to_one")
    correct_metrics = json.loads((correct_dir / "metrics.json").read_text(encoding="utf-8"))
    control_metrics = json.loads((control_dir / "metrics.json").read_text(encoding="utf-8"))
    return frame, float(correct_metrics["threshold"]), float(control_metrics["threshold"])


def load_stage12(
    root: Path, model: str, split: str, seed: str, group: str
) -> tuple[pd.DataFrame, float, float]:
    directories = [
        root / "reports/supplementary/stage12" / mode / model / split / f"seed_{seed}" / "gated"
        for mode in ["joint", "molecule"]
    ]
    frames = []
    thresholds = []
    for directory in directories:
        data = pd.read_parquet(directory / "test_predictions.parquet")
        data = data[data["benchmark_group"].eq(group)]
        frames.append(data[KEY + ["calibrated_probability"]])
        metrics = json.loads((directory / "metrics.json").read_text(encoding="utf-8"))
        thresholds.append(float(metrics["threshold"]))
    frame = frames[0].merge(frames[1], on=KEY, suffixes=("_a", "_b"), validate="one_to_one")
    frame = frame.rename(
        columns={
            "calibrated_probability_a": "probability_a",
            "calibrated_probability_b": "probability_b",
        }
    )
    return frame, thresholds[0], thresholds[1]


def metric_delta(frame: pd.DataFrame, threshold_a: float, threshold_b: float) -> dict[str, float]:
    truth = frame["label"].to_numpy(int)
    a = np.clip(frame["probability_a"].to_numpy(float), 0, 1)
    b = np.clip(frame["probability_b"].to_numpy(float), 0, 1)
    weights = reaction_weights(frame["reaction_id"])
    ap_a = reaction_ap(frame, "probability_a")
    ap_b = reaction_ap(frame, "probability_b")
    reaction_delta = reaction_logloss(frame, "probability_a") - reaction_logloss(
        frame, "probability_b"
    )
    return {
        "delta_mcc": weighted_mcc(truth, a >= threshold_a, weights)
        - weighted_mcc(truth, b >= threshold_b, weights),
        "delta_pr_auc": float(average_precision_score(truth, a, sample_weight=weights))
        - float(average_precision_score(truth, b, sample_weight=weights)),
        "delta_brier": float(np.average(np.square(a - truth), weights=weights))
        - float(np.average(np.square(b - truth), weights=weights)),
        "delta_reaction_macro_ap": float((ap_a - ap_b).mean()),
        "negative_transfer_rate": float((reaction_delta > 0).mean()),
        "mean_delta_logloss": float(reaction_delta.mean()),
    }


def bootstrap_job(arguments: tuple) -> tuple[list[dict], dict]:
    (
        stage,
        comparison,
        model,
        split,
        group,
        root_value,
        splits_value,
        replicates,
        random_seed,
    ) = arguments
    root = Path(root_value)
    frames = []
    thresholds = []
    observed = []
    for seed in range(20260829, 20260834):
        if stage == "stage11":
            frame, threshold_a, threshold_b = load_stage11(
                root, comparison, split, str(seed), group
            )
        else:
            frame, threshold_a, threshold_b = load_stage12(root, model, split, str(seed), group)
        frame = frame.sort_values(KEY).reset_index(drop=True)
        if frames and not frame[KEY].equals(frames[0][KEY]):
            raise ValueError(f"Candidate mismatch: {stage}/{comparison}/{model}/{split}/{group}")
        frames.append(frame)
        thresholds.append((threshold_a, threshold_b))
        observed.append(metric_delta(frame, threshold_a, threshold_b))
    metadata = pd.read_parquet(Path(splits_value) / split / "reaction_splits.parquet")[
        [
            "reaction_id",
            "protein_cluster",
            "scaffold",
        ]
    ]
    frames = [frame.merge(metadata, on="reaction_id", validate="many_to_one") for frame in frames]
    reference = frames[0]
    proteins = sorted(reference["protein_cluster"].unique())
    scaffolds = sorted(reference["scaffold"].unique())
    p_position = {value: index for index, value in enumerate(proteins)}
    s_position = {value: index for index, value in enumerate(scaffolds)}
    p_index = reference["protein_cluster"].map(p_position).to_numpy()
    s_index = reference["scaffold"].map(s_position).to_numpy()
    base_weights = reaction_weights(reference["reaction_id"])
    truth = reference["label"].to_numpy(int)
    reaction_meta = reference[["reaction_id", "protein_cluster", "scaffold"]].drop_duplicates()
    reaction_meta = reaction_meta.set_index("reaction_id")
    reaction_deltas = []
    reaction_ap_deltas = []
    for frame in frames:
        reaction_deltas.append(
            reaction_logloss(frame, "probability_a") - reaction_logloss(frame, "probability_b")
        )
        reaction_ap_deltas.append(
            reaction_ap(frame, "probability_a") - reaction_ap(frame, "probability_b")
        )
    mean_reaction_delta = (
        pd.concat(reaction_deltas, axis=1).mean(axis=1).reindex(reaction_meta.index)
    )
    mean_reaction_ap_delta = (
        pd.concat(reaction_ap_deltas, axis=1).mean(axis=1).reindex(reaction_meta.index)
    )
    rp_index = reaction_meta["protein_cluster"].map(p_position).to_numpy()
    rs_index = reaction_meta["scaffold"].map(s_position).to_numpy()
    rng = np.random.default_rng(random_seed)
    rows = []
    for replicate in range(replicates):
        protein_weight = rng.poisson(1.0, len(proteins))
        scaffold_weight = rng.poisson(1.0, len(scaffolds))
        cluster_weight = protein_weight[p_index] * scaffold_weight[s_index]
        weights = base_weights * cluster_weight
        if weights.sum() == 0 or weights[truth == 1].sum() == 0:
            continue
        metric_values = {"delta_mcc": [], "delta_pr_auc": [], "delta_brier": []}
        for frame, (threshold_a, threshold_b) in zip(frames, thresholds, strict=True):
            a = frame["probability_a"].to_numpy(float)
            b = frame["probability_b"].to_numpy(float)
            metric_values["delta_mcc"].append(
                weighted_mcc(truth, a >= threshold_a, weights)
                - weighted_mcc(truth, b >= threshold_b, weights)
            )
            metric_values["delta_pr_auc"].append(
                average_precision_score(truth, a, sample_weight=weights)
                - average_precision_score(truth, b, sample_weight=weights)
            )
            metric_values["delta_brier"].append(
                np.average(np.square(a - truth), weights=weights)
                - np.average(np.square(b - truth), weights=weights)
            )
        reaction_cluster_weight = protein_weight[rp_index] * scaffold_weight[rs_index]
        valid_ap = mean_reaction_ap_delta.notna().to_numpy()
        row = {
            "stage": stage,
            "comparison": comparison,
            "model": model,
            "split": split,
            "group": group,
            "replicate": replicate,
            **{key: float(np.mean(value)) for key, value in metric_values.items()},
            "delta_reaction_macro_ap": float(
                np.average(
                    mean_reaction_ap_delta.to_numpy()[valid_ap],
                    weights=reaction_cluster_weight[valid_ap],
                )
            )
            if reaction_cluster_weight[valid_ap].sum()
            else float("nan"),
            "negative_transfer_rate": float(
                np.average(mean_reaction_delta.to_numpy() > 0, weights=reaction_cluster_weight)
            )
            if reaction_cluster_weight.sum()
            else float("nan"),
            "mean_delta_logloss": float(
                np.average(mean_reaction_delta.to_numpy(), weights=reaction_cluster_weight)
            )
            if reaction_cluster_weight.sum()
            else float("nan"),
        }
        rows.append(row)
    observed_row = {
        "stage": stage,
        "comparison": comparison,
        "model": model,
        "split": split,
        "group": group,
        **{key: float(np.mean([value[key] for value in observed])) for key in observed[0]},
        "reactions": int(reference["reaction_id"].nunique()),
        "protein_clusters": len(proteins),
        "scaffold_clusters": len(scaffolds),
    }
    return rows, observed_row


def summarize_bootstrap(frame: pd.DataFrame) -> pd.DataFrame:
    metrics = [
        "delta_mcc",
        "delta_pr_auc",
        "delta_brier",
        "delta_reaction_macro_ap",
        "negative_transfer_rate",
        "mean_delta_logloss",
    ]
    equal_split = (
        frame.groupby(["stage", "comparison", "model", "group", "replicate"])[metrics]
        .mean()
        .reset_index()
    )
    rows = []
    for keys, group in equal_split.groupby(["stage", "comparison", "model", "group"]):
        row = dict(zip(["stage", "comparison", "model", "group"], keys, strict=True))
        for metric in metrics:
            values = group[metric].dropna()
            row[f"{metric}_bootstrap_mean"] = values.mean()
            row[f"{metric}_ci_low"] = values.quantile(0.025)
            row[f"{metric}_ci_high"] = values.quantile(0.975)
        rows.append(row)
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=["stage11", "stage12"], required=True)
    parser.add_argument("--splits", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--replicates", type=int, default=1000)
    parser.add_argument("--workers", type=int, default=max(1, min(8, (os.cpu_count() or 2) // 2)))
    parser.add_argument("--seed", type=int, default=20260831)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    split_names = sorted(path.name for path in Path(args.splits).glob("outer_*"))
    comparisons = (
        [(value, "global") for value in ["molecule", "mean", "permuted"]]
        if args.stage == "stage11"
        else [("joint_minus_molecule_ranking", value) for value in ["molecule", "global"]]
    )
    jobs = []
    for comparison, model in comparisons:
        for split in split_names:
            for group in GROUPS:
                jobs.append(
                    (
                        args.stage,
                        comparison,
                        model,
                        split,
                        group,
                        str(root),
                        args.splits,
                        args.replicates,
                        args.seed + len(jobs),
                    )
                )
    bootstrap_rows, observed_rows = [], []
    with ProcessPoolExecutor(max_workers=min(args.workers, len(jobs))) as pool:
        for bootstrap, observed in pool.map(bootstrap_job, jobs):
            bootstrap_rows.extend(bootstrap)
            observed_rows.append(observed)
    target = Path(args.output)
    target.mkdir(parents=True, exist_ok=True)
    bootstrap = pd.DataFrame(bootstrap_rows)
    observed = pd.DataFrame(observed_rows)
    bootstrap.to_parquet(target / "paired_cluster_bootstrap.parquet", index=False)
    observed.to_csv(target / "paired_split_metrics.csv", index=False)
    summary = summarize_bootstrap(bootstrap)
    directions = (
        observed.groupby(["stage", "comparison", "model", "group"])
        .agg(
            splits=("split", "nunique"),
            positive_mcc_splits=("delta_mcc", lambda value: int((value > 0).sum())),
            positive_pr_auc_splits=("delta_pr_auc", lambda value: int((value > 0).sum())),
            harmful_logloss_splits=("mean_delta_logloss", lambda value: int((value > 0).sum())),
            observed_delta_mcc=("delta_mcc", "mean"),
            observed_delta_pr_auc=("delta_pr_auc", "mean"),
            observed_delta_reaction_macro_ap=("delta_reaction_macro_ap", "mean"),
            observed_negative_transfer_rate=("negative_transfer_rate", "mean"),
            observed_mean_delta_logloss=("mean_delta_logloss", "mean"),
        )
        .reset_index()
    )
    summary = directions.merge(
        summary, on=["stage", "comparison", "model", "group"], validate="one_to_one"
    )
    summary.to_csv(target / "paired_cluster_summary.csv", index=False)
    print(f"{args.stage}: {len(jobs)} jobs, {len(bootstrap):,} bootstrap rows")


if __name__ == "__main__":
    main()
