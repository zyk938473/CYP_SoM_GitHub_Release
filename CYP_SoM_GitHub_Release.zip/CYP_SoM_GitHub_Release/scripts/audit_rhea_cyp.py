from __future__ import annotations

import argparse
import hashlib
import json
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import pandas as pd
from rdkit import Chem

from cyp_som.chem import standardize_smiles
from cyp_som.reaction_mapping import infer_existing_bond_sites
from cyp_som.utils import stable_id


def map_reaction(payload: tuple[int, str]) -> dict[str, object]:
    rhea_id, reaction_smiles = payload
    try:
        left, right = reaction_smiles.split(">>")
        substrate = left.split(".")[0]
        product = right.split(".")[0]
    except ValueError:
        return {"RHEA_ID": rhea_id, "mapping_status": "INVALID_REACTION_SMILES"}
    result = infer_existing_bond_sites(substrate, product)
    try:
        standardized = standardize_smiles(substrate)
        canonical_smiles = standardized.canonical_smiles
        inchikey = standardized.inchikey
        scaffold = standardized.scaffold_smiles
        molecule_error = "" if inchikey else "EMPTY_INCHIKEY"
    except (ValueError, RuntimeError) as exc:
        canonical_smiles = inchikey = scaffold = ""
        molecule_error = str(exc)
    molecule = Chem.MolFromSmiles(substrate)
    product_molecule = Chem.MolFromSmiles(product)
    first_component_plausible = bool(
        molecule is not None
        and product_molecule is not None
        and molecule.GetNumHeavyAtoms() >= 3
        and not any(atom.GetAtomicNum() == 0 for atom in molecule.GetAtoms())
        and not any(atom.GetAtomicNum() > 20 for atom in molecule.GetAtoms())
    )
    return {
        "RHEA_ID": rhea_id,
        "substrate_smiles": substrate,
        "product_smiles": product,
        "canonical_smiles": canonical_smiles,
        "inchikey": inchikey,
        "scaffold": scaffold,
        "molecule_error": molecule_error,
        "first_component_plausible": first_component_plausible,
        "mapping_status": result.status,
        "canonical_site_keys": json.dumps(result.site_keys),
        "site_kinds": json.dumps(result.site_kinds),
        "changed_substrate_bonds": json.dumps(result.changed_substrate_bonds),
        "hydrogen_substitution_atoms": json.dumps(result.hydrogen_substitution_atoms),
        "new_mapped_bonds": json.dumps(result.new_mapped_bonds),
        "mapped_heavy_atoms": result.mapped_heavy_atoms,
        "substrate_heavy_atoms": result.substrate_heavy_atoms,
        "product_heavy_atoms": result.product_heavy_atoms,
        "mapping_coverage": result.mapped_heavy_atoms / max(1, result.substrate_heavy_atoms),
        "edit_count": result.edit_count,
        "mapping_warning": result.warning,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rhea-smiles", required=True)
    parser.add_argument("--rhea-uniprot", required=True)
    parser.add_argument("--uniprot-p450", required=True)
    parser.add_argument("--existing-reactions", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)

    smiles = pd.read_csv(
        args.rhea_smiles,
        sep="\t",
        header=None,
        names=["RHEA_ID", "reaction_smiles"],
    )
    mappings = pd.read_csv(args.rhea_uniprot, sep="\t")
    proteins = pd.read_csv(args.uniprot_p450, sep="\t").rename(
        columns={
            "Entry": "uniprot_id",
            "Entry Name": "entry_name",
            "Protein names": "protein_name",
            "Organism": "organism_name",
            "Organism (ID)": "organism_id",
            "Length": "sequence_length",
            "Sequence": "protein_sequence",
        }
    )
    directed = mappings[
        mappings["ID"].isin(set(proteins["uniprot_id"])) & mappings["DIRECTION"].isin(["LR", "RL"])
    ].copy()
    directed = directed.merge(smiles, on="RHEA_ID", how="left")
    unique_reactions = directed[["RHEA_ID", "reaction_smiles"]].drop_duplicates()
    payloads = [
        (int(row.RHEA_ID), str(row.reaction_smiles))
        for row in unique_reactions.itertuples(index=False)
    ]
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        mapped = list(executor.map(map_reaction, payloads, chunksize=16))
    reaction_audit = pd.DataFrame(mapped)
    audit = directed.merge(reaction_audit, on="RHEA_ID", how="left").merge(
        proteins,
        left_on="ID",
        right_on="uniprot_id",
        how="left",
    )
    audit["protein_sequence"] = audit["protein_sequence"].str.replace(r"\s+", "", regex=True)
    audit["sequence_hash"] = audit["protein_sequence"].map(
        lambda value: hashlib.sha256(value.encode()).hexdigest()
    )
    audit["pair_id"] = audit.apply(
        lambda row: stable_id(row["sequence_hash"], row["inchikey"], prefix="pair_"), axis=1
    )
    audit["site_count"] = (
        audit["canonical_site_keys"].fillna("[]").map(lambda value: len(json.loads(value)))
    )
    audit["candidate_high_confidence"] = (
        audit["mapping_status"].eq("MAPPED")
        & audit["mapping_coverage"].eq(1.0)
        & audit["site_count"].eq(1)
        & audit["edit_count"].isin([1, 3])
        & audit["first_component_plausible"].astype("boolean").fillna(False)
        & audit["molecule_error"].eq("")
    )
    existing = pd.read_parquet(args.existing_reactions)
    existing_pairs = set(existing["pair_id"])
    existing_sequences = set(existing["sequence_hash"])
    audit["overlaps_existing_pair"] = audit["pair_id"].isin(existing_pairs)
    audit["sequence_is_new"] = ~audit["sequence_hash"].isin(existing_sequences)

    audit.to_parquet(output / "rhea_cyp_mapping_audit.parquet", index=False)
    audit.to_csv(output / "rhea_cyp_mapping_audit.csv", index=False)
    candidates = audit[audit["candidate_high_confidence"]].copy()
    candidates.to_parquet(output / "candidate_reactions.parquet", index=False)
    candidates.to_csv(output / "candidate_reactions.csv", index=False)
    novel = candidates[~candidates["overlaps_existing_pair"]]
    summary = {
        "uniprot_reviewed_pf00067_sequences": len(proteins),
        "directed_cyp_uniprot_rhea_rows": len(audit),
        "directed_cyp_sequences": int(audit["sequence_hash"].nunique()),
        "directed_rhea_reactions": int(audit["RHEA_ID"].nunique()),
        "mapping_status": reaction_audit["mapping_status"].value_counts(dropna=False).to_dict(),
        "high_confidence_rows": len(candidates),
        "high_confidence_pairs": int(candidates["pair_id"].nunique()),
        "novel_pairs_vs_expanded_v1": int(novel["pair_id"].nunique()),
        "novel_sequences_vs_expanded_v1": int(
            novel.loc[novel["sequence_is_new"], "sequence_hash"].nunique()
        ),
        "license": "Rhea CC BY 4.0; UniProt terms apply to protein records.",
        "evidence_tier": "Curated-database evidence; primary-paper reaction provenance not yet attached.",
        "first_component_caution": "Rhea reaction SMILES component ordering is used to choose the primary substrate/product. Novel rows require overlap validation or targeted review before primary benchmark inclusion.",
    }
    (output / "audit_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
