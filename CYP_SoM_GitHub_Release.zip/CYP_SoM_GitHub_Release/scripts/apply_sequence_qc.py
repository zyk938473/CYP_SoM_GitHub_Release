from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark", required=True)
    parser.add_argument("--protein-qc", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    source = Path(args.benchmark)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    reactions = pd.read_parquet(source / "reactions.parquet")
    bonds = pd.read_parquet(source / "candidate_bonds.parquet")
    protein_qc = pd.read_parquet(args.protein_qc)
    passed = protein_qc[protein_qc["identity_qc"].str.startswith("PASS")].copy()
    passed_hashes = set(passed["sequence_hash"])

    kept_reactions = reactions[reactions["sequence_hash"].isin(passed_hashes)].copy()
    kept_ids = set(kept_reactions["reaction_id"])
    kept_bonds = bonds[bonds["reaction_id"].isin(kept_ids)].copy()
    excluded = reactions[~reactions["sequence_hash"].isin(passed_hashes)].merge(
        protein_qc[["sequence_hash", "identity_qc", "domain_qc"]],
        on="sequence_hash",
        how="left",
    )
    kept_reactions.to_parquet(output / "reactions.parquet", index=False)
    kept_reactions.to_csv(output / "reactions.csv", index=False)
    kept_bonds.to_parquet(output / "candidate_bonds.parquet", index=False)
    excluded.to_csv(output / "excluded_reactions_sequence_qc.csv", index=False)
    passed[["sequence_hash", "protein_name", "identity_sequence"]].rename(
        columns={"identity_sequence": "protein_sequence"}
    ).to_parquet(output / "proteins_for_identity.parquet", index=False)
    manifest = {
        "status": "INTERMEDIATE_SEQUENCE_QC_OUTPUT",
        "site_key_version": 3,
        "reactions": len(kept_reactions),
        "sequences": int(kept_reactions["sequence_hash"].nunique()),
        "molecules": int(kept_reactions["inchikey"].nunique()),
        "scaffolds": int(kept_reactions["scaffold"].nunique()),
        "candidate_bonds": len(kept_bonds),
        "positive_bonds": int(kept_bonds["label"].sum()),
        "excluded_reactions_sequence_qc": len(excluded),
        "excluded_sequences": int(excluded["sequence_hash"].nunique()),
        "identity_qc_counts": protein_qc["identity_qc"].value_counts().to_dict(),
        "redistribution_warning": "Contains provider-governed rows; do not redistribute row-level outputs.",
    }
    (output / "manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
