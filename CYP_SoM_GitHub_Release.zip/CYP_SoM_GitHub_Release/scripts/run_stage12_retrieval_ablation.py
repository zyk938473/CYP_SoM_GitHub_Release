from __future__ import annotations

import argparse
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path


def base_command(args, model_runs: str, output: str, mode: str) -> list[str]:
    return [
        sys.executable,
        "scripts/run_retrieval_matrix.py",
        "--reactions",
        args.reactions,
        "--bonds",
        args.bonds,
        "--identity",
        args.identity,
        "--splits",
        args.splits,
        "--model-runs",
        model_runs,
        "--output",
        output,
        "--ranking-mode",
        mode,
        "--top-k",
        str(args.top_k),
        "--preselect",
        str(args.preselect),
    ]


def execute(command: list[str]) -> None:
    environment = os.environ.copy()
    environment.update({"OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"})
    subprocess.run(command, check=True, env=environment)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reactions", required=True)
    parser.add_argument("--bonds", required=True)
    parser.add_argument("--identity", required=True)
    parser.add_argument("--splits", required=True)
    parser.add_argument("--molecule-runs", required=True)
    parser.add_argument("--global-runs", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--joint-source")
    parser.add_argument("--modes", nargs="+", default=["molecule", "joint"])
    parser.add_argument("--outer-workers", type=int, default=5)
    parser.add_argument(
        "--gate-workers", type=int, default=max(1, min(8, (os.cpu_count() or 2) // 2))
    )
    parser.add_argument("--top-k", type=int, default=8)
    parser.add_argument("--preselect", type=int, default=32)
    args = parser.parse_args()
    project = Path(__file__).resolve().parents[1]
    os.chdir(project)
    split_names = [path.name for path in sorted(Path(args.splits).glob("outer_*/"))]
    for mode in args.modes:
        mode_root = Path(args.output) / mode
        molecule_output = mode_root / "molecule"
        if mode == "joint" and args.joint_source:
            command = base_command(args, args.molecule_runs, str(molecule_output), mode) + [
                "--mapping-source",
                args.joint_source,
            ]
            execute(command)
        else:
            jobs = []
            for split in split_names:
                jobs.append(
                    base_command(args, args.molecule_runs, str(molecule_output), mode)
                    + ["--split-names", split, "--skip-summary"]
                )
            with ThreadPoolExecutor(max_workers=min(args.outer_workers, len(jobs))) as pool:
                futures = [pool.submit(execute, command) for command in jobs]
                for index, future in enumerate(as_completed(futures), start=1):
                    future.result()
                    print(f"{mode}: MCS split {index}/{len(jobs)} complete", flush=True)
            execute(base_command(args, args.molecule_runs, str(molecule_output), mode))
        global_output = mode_root / "global"
        execute(
            base_command(args, args.global_runs, str(global_output), mode)
            + ["--mapping-source", str(molecule_output)]
        )
        execute(
            [
                sys.executable,
                "scripts/run_stage10a_matrix.py",
                "--molecule-features",
                str(molecule_output),
                "--global-features",
                str(global_output),
                "--output",
                str(mode_root / "joint_gates"),
                "--workers",
                str(args.gate_workers),
            ]
        )
    print("Stage 12 retrieval ranking ablation complete")


if __name__ == "__main__":
    main()
