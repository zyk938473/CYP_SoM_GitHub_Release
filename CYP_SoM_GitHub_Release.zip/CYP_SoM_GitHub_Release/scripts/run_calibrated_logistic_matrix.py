from __future__ import annotations

import argparse
import json
import os
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression

from cyp_som.metrics import binary_metrics
from cyp_som.reliability import (
    best_weighted_mcc_threshold,
    platt_fit,
    reaction_weights,
    weighted_metrics,
)


def fit_model(x, frame: pd.DataFrame) -> LogisticRegression:
    truth = frame["label"].to_numpy(dtype=int)
    weights = reaction_weights(frame["reaction_id"])
    counts = np.bincount(truth, minlength=2)
    class_weight = len(truth) / (2 * np.maximum(counts, 1))
    weights *= class_weight[truth]
    weights *= len(weights) / weights.sum()
    model = LogisticRegression(max_iter=1000, solver="liblinear", random_state=20260829)
    model.fit(x[frame["row_index"].to_numpy()], truth, sample_weight=weights)
    return model


def run_split(arguments: tuple[str, str, str, str]) -> str:
    cache, split_dir_value, output_value, force_value = arguments
    os.environ.update({"OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"})
    split_dir = Path(split_dir_value)
    output = Path(output_value)
    if (output / "metrics.json").is_file() and force_value != "1":
        return str(output)
    x = np.load(Path(cache) / "features.npy", mmap_mode="r")
    index = pd.read_parquet(Path(cache) / "index.parquet").reset_index(names="row_index")
    split = pd.read_parquet(split_dir / "reaction_splits.parquet")
    data = index.merge(
        split[["reaction_id", "benchmark_group"]],
        on="reaction_id",
        how="inner",
        validate="many_to_one",
    )
    inner = pd.read_parquet(split_dir / "inner_cluster_folds.parquet")
    oof = []
    for fold in sorted(inner["inner_fold"].unique()):
        roles = inner[inner["inner_fold"].eq(fold)]
        train_ids = set(roles.loc[roles["inner_role"].eq("train"), "reaction_id"])
        validation_ids = set(roles.loc[roles["inner_role"].eq("validation"), "reaction_id"])
        train = data[data["reaction_id"].isin(train_ids)]
        validation = data[data["reaction_id"].isin(validation_ids)].copy()
        model = fit_model(x, train)
        validation["base_probability"] = model.predict_proba(x[validation["row_index"].to_numpy()])[
            :, 1
        ]
        validation["inner_fold"] = int(fold)
        oof.append(validation)
    oof_frame = pd.concat(oof, ignore_index=True)
    weights = reaction_weights(oof_frame["reaction_id"])
    platt = platt_fit(
        oof_frame["base_probability"].to_numpy(), oof_frame["label"].to_numpy(), weights
    )
    calibrated_oof = platt.predict_proba(oof_frame["base_probability"].to_numpy().reshape(-1, 1))[
        :, 1
    ]
    threshold, threshold_mcc = best_weighted_mcc_threshold(
        oof_frame["label"].to_numpy(), calibrated_oof, weights
    )
    train = data[data["benchmark_group"].eq("train")]
    final_model = fit_model(x, train)
    tests = data[data["benchmark_group"].str.startswith("G", na=False)].copy()
    tests["base_probability"] = final_model.predict_proba(x[tests["row_index"].to_numpy()])[:, 1]
    tests["calibrated_probability"] = platt.predict_proba(
        tests["base_probability"].to_numpy().reshape(-1, 1)
    )[:, 1]
    metrics = {
        "protocol_status": "FORMAL_INNER_OOF_CALIBRATED",
        "threshold": threshold,
        "threshold_oof_weighted_mcc": threshold_mcc,
        "groups": {},
    }
    for group, frame in tests.groupby("benchmark_group"):
        group_weights = reaction_weights(frame["reaction_id"])
        metrics["groups"][group] = {
            **binary_metrics(frame["label"], frame["calibrated_probability"], threshold),
            **weighted_metrics(
                frame["label"], frame["calibrated_probability"], group_weights, threshold
            ),
        }
    output.mkdir(parents=True, exist_ok=True)
    joblib.dump(final_model, output / "molecule_logistic.joblib")
    joblib.dump(platt, output / "platt.joblib")
    oof_frame[["reaction_id", "bond_idx", "label", "inner_fold", "base_probability"]].to_parquet(
        output / "inner_oof_predictions.parquet", index=False
    )
    tests[
        [
            "reaction_id",
            "bond_idx",
            "label",
            "benchmark_group",
            "base_probability",
            "calibrated_probability",
        ]
    ].to_parquet(output / "test_predictions.parquet", index=False)
    (output / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    return str(output)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache", required=True)
    parser.add_argument("--splits", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    target = Path(args.output)
    jobs = [
        (args.cache, str(split), str(target / split.name), "1" if args.force else "0")
        for split in sorted(Path(args.splits).glob("outer_*/"))
    ]
    with ProcessPoolExecutor(max_workers=min(args.workers, len(jobs))) as pool:
        futures = [pool.submit(run_split, job) for job in jobs]
        for future in as_completed(futures):
            print(f"completed {future.result()}", flush=True)
    rows = []
    for path in target.glob("outer_*/metrics.json"):
        payload = json.loads(path.read_text(encoding="utf-8"))
        for group, metrics in payload["groups"].items():
            rows.append({"split": path.parent.name, "group": group, **metrics})
    summary = pd.DataFrame(rows)
    summary.to_csv(target / "summary.csv", index=False)
    summary.groupby("group").mean(numeric_only=True).to_csv(target / "aggregate.csv")


if __name__ == "__main__":
    main()
