from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--outer-splits", required=True)
    parser.add_argument("--folds", type=int, default=3)
    args = parser.parse_args()
    root = Path(args.outer_splits)
    summary_rows = []
    for outer in sorted(path for path in root.iterdir() if path.is_dir()):
        split = pd.read_parquet(outer / "reaction_splits.parquet")
        train = split[split["benchmark_group"] == "train"].copy()
        cluster_sizes = (
            train.groupby("protein_cluster").size().sort_values(ascending=False).to_dict()
        )
        fold_loads = [0] * args.folds
        assignment = {}
        for cluster, size in cluster_sizes.items():
            fold = min(range(args.folds), key=lambda index: (fold_loads[index], index))
            assignment[cluster] = fold
            fold_loads[fold] += size
        fold_frames = []
        for fold in range(args.folds):
            frame = train.copy()
            frame["inner_fold"] = fold
            frame["inner_role"] = (
                frame["protein_cluster"]
                .map(assignment)
                .map(lambda value, fold=fold: "validation" if value == fold else "train")
            )
            fold_frames.append(frame)
            validation = frame[frame["inner_role"] == "validation"]
            inner_train = frame[frame["inner_role"] == "train"]
            overlap = set(validation["protein_cluster"]) & set(inner_train["protein_cluster"])
            if overlap:
                raise ValueError(f"{outer.name} fold {fold} protein-cluster leakage")
            summary_rows.append(
                {
                    "outer_split": outer.name,
                    "inner_fold": fold,
                    "train_reactions": len(inner_train),
                    "validation_reactions": len(validation),
                    "train_clusters": inner_train["protein_cluster"].nunique(),
                    "validation_clusters": validation["protein_cluster"].nunique(),
                    "validation_scaffolds": validation["scaffold"].nunique(),
                    "scaffold_overlap_train": len(
                        set(validation["scaffold"]) & set(inner_train["scaffold"])
                    ),
                }
            )
        inner = pd.concat(fold_frames, ignore_index=True)
        inner.to_parquet(outer / "inner_cluster_folds.parquet", index=False)

    summary = pd.DataFrame(summary_rows)
    summary.to_csv(root / "inner_cluster_fold_summary.csv", index=False)
    manifest = {
        "folds_per_outer_split": args.folds,
        "outer_splits": int(summary["outer_split"].nunique()),
        "minimum_validation_reactions": int(summary["validation_reactions"].min()),
        "minimum_validation_clusters": int(summary["validation_clusters"].min()),
        "selection_policy": "Hyperparameters and early stopping use only these outer-train-derived folds. Outer G groups must remain untouched until final evaluation.",
        "retrieval_policy": "For each inner fold, retrieval examples are restricted to inner_role=train.",
    }
    (root / "inner_cluster_fold_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
