from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def write_subset(
    name: str,
    allowed: set[str],
    reactions: pd.DataFrame,
    bonds: pd.DataFrame,
    identity: np.ndarray,
    hashes: np.ndarray,
    output: Path,
) -> None:
    target = output / name
    target.mkdir(parents=True, exist_ok=True)
    selected = reactions[reactions["evidence_tier"].isin(allowed)].copy()
    reaction_ids = set(selected["reaction_id"])
    selected_bonds = bonds[bonds["reaction_id"].isin(reaction_ids)].copy()
    active_hashes = set(selected["sequence_hash"])
    positions = [index for index, value in enumerate(hashes) if value in active_hashes]
    selected_identity = identity[np.ix_(positions, positions)]
    selected_hashes = hashes[positions]
    selected.to_parquet(target / "reactions.parquet", index=False)
    selected_bonds.to_parquet(target / "candidate_bonds.parquet", index=False)
    np.savez_compressed(
        target / "protein_global_identity.npz",
        identity=selected_identity,
        sequence_hash=selected_hashes,
    )
    manifest = {
        "subset": name,
        "allowed_evidence_tiers": sorted(allowed),
        "reactions": len(selected),
        "sequences": int(selected["sequence_hash"].nunique()),
        "molecules": int(selected["inchikey"].nunique()),
        "scaffolds": int(selected["scaffold"].nunique()),
        "candidate_bonds": len(selected_bonds),
        "positive_bonds": int(selected_bonds["label"].sum()),
    }
    (target / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    source = Path(args.benchmark)
    output = Path(args.output)
    reactions = pd.read_parquet(source / "reactions.parquet")
    bonds = pd.read_parquet(source / "candidate_bonds.parquet")
    payload = np.load(source / "protein_global_identity.npz", allow_pickle=True)
    identity = payload["identity"]
    hashes = payload["sequence_hash"].astype(str)
    write_subset(
        "high_and_curated_evidence",
        {"LITERATURE_LINKED_CURATED", "CURATED_DATABASE"},
        reactions,
        bonds,
        identity,
        hashes,
        output,
    )
    write_subset(
        "literature_linked_only",
        {"LITERATURE_LINKED_CURATED"},
        reactions,
        bonds,
        identity,
        hashes,
        output,
    )


if __name__ == "__main__":
    main()
