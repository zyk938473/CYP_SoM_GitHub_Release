from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--splits", required=True)
    parser.add_argument("--identity", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--threshold", type=float, default=0.4)
    args = parser.parse_args()
    split_root = Path(args.splits)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    payload = np.load(args.identity, allow_pickle=True)
    identity = payload["identity"]
    hashes = payload["sequence_hash"].astype(str)
    index = {value: position for position, value in enumerate(hashes)}

    audit_rows = []
    source_rows = []
    failures = []
    for split_dir in sorted(path for path in split_root.iterdir() if path.is_dir()):
        split = pd.read_parquet(split_dir / "reaction_splits.parquet")
        train = split[split["benchmark_group"] == "train"]
        train_clusters = set(train["protein_cluster"])
        train_scaffolds = set(train["scaffold"])
        train_hashes = set(train["sequence_hash"])
        train_indices = [index[value] for value in train_hashes]
        for group_name, group in split.groupby("benchmark_group"):
            query_indices = [index[value] for value in group["sequence_hash"].unique()]
            max_identity = (
                float(identity[np.ix_(query_indices, train_indices)].max())
                if query_indices and train_indices and group_name != "train"
                else None
            )
            protein_clusters = set(group["protein_cluster"])
            scaffolds = set(group["scaffold"])
            expected_protein_ood = group_name in {"G01_protein_ood", "G11_double_ood"}
            expected_scaffold_ood = group_name in {"G10_scaffold_ood", "G11_double_ood"}
            protein_overlap = len(protein_clusters & train_clusters)
            scaffold_overlap = len(scaffolds & train_scaffolds)
            if expected_protein_ood and protein_overlap:
                failures.append(f"{split_dir.name}:{group_name}:protein cluster overlap")
            if expected_protein_ood and max_identity is not None and max_identity >= args.threshold:
                failures.append(f"{split_dir.name}:{group_name}:identity threshold violation")
            if expected_scaffold_ood and scaffold_overlap:
                failures.append(f"{split_dir.name}:{group_name}:scaffold overlap")
            audit_rows.append(
                {
                    "split": split_dir.name,
                    "benchmark_group": group_name,
                    "reactions": len(group),
                    "proteins": group["sequence_hash"].nunique(),
                    "protein_clusters": group["protein_cluster"].nunique(),
                    "molecules": group["inchikey"].nunique(),
                    "scaffolds": group["scaffold"].nunique(),
                    "positive_bonds": int(group["positive_bond_count"].sum()),
                    "protein_cluster_overlap_train": protein_overlap,
                    "scaffold_overlap_train": scaffold_overlap,
                    "max_identity_to_train": max_identity,
                    "expected_protein_ood": expected_protein_ood,
                    "expected_scaffold_ood": expected_scaffold_ood,
                }
            )
            for tier, count in group["evidence_tier"].value_counts().items():
                source_rows.append(
                    {
                        "split": split_dir.name,
                        "benchmark_group": group_name,
                        "evidence_tier": tier,
                        "reactions": int(count),
                    }
                )
        if not split["reaction_id"].is_unique:
            failures.append(f"{split_dir.name}:duplicate reaction IDs")

    audit = pd.DataFrame(audit_rows)
    sources = pd.DataFrame(source_rows)
    audit.to_csv(output / "selected_split_audit.csv", index=False)
    sources.to_csv(output / "selected_split_evidence_tiers.csv", index=False)
    summary = {
        "status": "PASS" if not failures else "FAIL",
        "selected_splits": int(audit["split"].nunique()),
        "identity_threshold": args.threshold,
        "failures": failures,
        "minimum_G01_reactions": int(
            audit.loc[audit["benchmark_group"] == "G01_protein_ood", "reactions"].min()
        ),
        "minimum_G01_clusters": int(
            audit.loc[audit["benchmark_group"] == "G01_protein_ood", "protein_clusters"].min()
        ),
        "minimum_G11_reactions": int(
            audit.loc[audit["benchmark_group"] == "G11_double_ood", "reactions"].min()
        ),
        "minimum_G11_clusters": int(
            audit.loc[audit["benchmark_group"] == "G11_double_ood", "protein_clusters"].min()
        ),
        "retrieval_policy": "Only benchmark_group=train may populate retrieval banks for each outer split.",
    }
    (output / "selected_split_audit_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
