from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import pandas as pd

TEST_GROUPS = ("G00_control", "G01_protein_ood", "G10_scaffold_ood", "G11_double_ood")


def run(command: list[str], root: Path) -> None:
    subprocess.run(command, check=True, cwd=root)


def reuse_mapping(template: Path, predictions: Path, output: Path) -> None:
    features = pd.read_parquet(template).drop(columns="base_probability")
    prediction = pd.read_parquet(predictions)
    probability_columns = [column for column in prediction if column.endswith("_probability")]
    if len(probability_columns) != 1:
        raise ValueError("Predictions must contain exactly one *_probability column")
    probability = prediction[["reaction_id", "bond_idx", "label", probability_columns[0]]].rename(
        columns={probability_columns[0]: "base_probability"}
    )
    features = features.merge(
        probability,
        on=["reaction_id", "bond_idx", "label"],
        how="left",
        validate="one_to_one",
    )
    if features["base_probability"].isna().any():
        raise ValueError("Reused retrieval mapping does not match predictions")
    output.parent.mkdir(parents=True, exist_ok=True)
    features.to_parquet(output, index=False)
    template_manifest = template.with_suffix(".json")
    if template_manifest.is_file():
        output.with_suffix(".json").write_text(
            template_manifest.read_text(encoding="utf-8"), encoding="utf-8"
        )


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build nested train-only retrieval, gate and calibration for a model matrix"
    )
    parser.add_argument("--reactions", required=True)
    parser.add_argument("--bonds", required=True)
    parser.add_argument("--identity", required=True)
    parser.add_argument("--splits", required=True)
    parser.add_argument("--model-runs", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--top-k", type=int, default=8)
    parser.add_argument("--preselect", type=int, default=32)
    parser.add_argument(
        "--ranking-mode", choices=["molecule", "joint", "sequence"], default="joint"
    )
    parser.add_argument("--split-names", nargs="+")
    parser.add_argument("--mapping-source")
    parser.add_argument("--skip-summary", action="store_true")
    args = parser.parse_args()
    project = Path(__file__).resolve().parents[1]
    output_root = Path(args.output)
    output_root.mkdir(parents=True, exist_ok=True)
    metrics_rows = []
    split_dirs = sorted(Path(args.splits).glob("outer_*/"))
    if args.split_names:
        requested = set(args.split_names)
        split_dirs = [path for path in split_dirs if path.name in requested]
        if {path.name for path in split_dirs} != requested:
            raise ValueError("One or more requested split names do not exist")
    for split_dir in split_dirs:
        inner = pd.read_parquet(split_dir / "inner_cluster_folds.parquet")
        split_template: Path | None = None
        if args.mapping_source:
            candidates = sorted((Path(args.mapping_source) / split_dir.name).glob("seed_*/"))
            split_template = next(
                (
                    path
                    for path in candidates
                    if (path / "test_retrieval_features.parquet").is_file()
                    and all(
                        (path / f"inner_fold_{fold}" / "retrieval_features.parquet").is_file()
                        for fold in range(3)
                    )
                ),
                None,
            )
            if split_template is None:
                raise FileNotFoundError(
                    f"No complete mapping template for {split_dir.name} in {args.mapping_source}"
                )
        for run_dir in sorted((Path(args.model_runs) / split_dir.name).glob("seed_*/")):
            if not (run_dir / "metrics.json").is_file():
                continue
            destination = output_root / split_dir.name / run_dir.name
            destination.mkdir(parents=True, exist_ok=True)
            gated = destination / "gated"
            if (gated / "metrics.json").is_file():
                if split_template is None:
                    split_template = destination
                metrics = json.loads((gated / "metrics.json").read_text(encoding="utf-8"))
                for group, values in metrics["groups"].items():
                    metrics_rows.append(
                        {
                            "split": split_dir.name,
                            "seed": run_dir.name.removeprefix("seed_"),
                            "group": group,
                            **values,
                        }
                    )
                continue
            test_predictions = destination / "test_predictions.parquet"
            pd.concat(
                [
                    pd.read_parquet(run_dir / f"{group}_predictions.parquet")
                    for group in TEST_GROUPS
                ],
                ignore_index=True,
            ).to_parquet(test_predictions, index=False)
            test_features = destination / "test_retrieval_features.parquet"
            if not test_features.is_file() and split_template is not None:
                reuse_mapping(
                    split_template / "test_retrieval_features.parquet",
                    test_predictions,
                    test_features,
                )
            if not test_features.is_file():
                run(
                    [
                        sys.executable,
                        "scripts/build_retrieval_features.py",
                        "--reactions",
                        args.reactions,
                        "--bonds",
                        args.bonds,
                        "--splits",
                        str(split_dir / "reaction_splits.parquet"),
                        "--identity",
                        args.identity,
                        "--predictions",
                        str(test_predictions),
                        "--output",
                        str(test_features),
                        "--top-k",
                        str(args.top_k),
                        "--preselect",
                        str(args.preselect),
                        "--ranking-mode",
                        args.ranking_mode,
                    ],
                    project,
                )
            oof = pd.read_parquet(run_dir / "inner_oof_predictions.parquet")
            calibration_features = []
            for fold in sorted(oof["inner_fold"].unique()):
                fold_dir = destination / f"inner_fold_{fold}"
                fold_dir.mkdir(parents=True, exist_ok=True)
                frame = inner[inner["inner_fold"].eq(fold)][["reaction_id", "inner_role"]].copy()
                frame["benchmark_group"] = frame["inner_role"].map(
                    {"train": "train", "validation": "inner_validation"}
                )
                inner_split = fold_dir / "split.parquet"
                frame[["reaction_id", "benchmark_group"]].to_parquet(inner_split, index=False)
                inner_predictions = fold_dir / "predictions.parquet"
                fold_predictions = oof[oof["inner_fold"].eq(fold)].drop(columns="inner_fold").copy()
                fold_predictions["benchmark_group"] = "inner_validation"
                fold_predictions.to_parquet(inner_predictions, index=False)
                features = fold_dir / "retrieval_features.parquet"
                if not features.is_file() and split_template is not None:
                    reuse_mapping(
                        split_template / f"inner_fold_{fold}" / "retrieval_features.parquet",
                        inner_predictions,
                        features,
                    )
                if not features.is_file():
                    run(
                        [
                            sys.executable,
                            "scripts/build_retrieval_features.py",
                            "--reactions",
                            args.reactions,
                            "--bonds",
                            args.bonds,
                            "--splits",
                            str(inner_split),
                            "--identity",
                            args.identity,
                            "--predictions",
                            str(inner_predictions),
                            "--output",
                            str(features),
                            "--top-k",
                            str(args.top_k),
                            "--preselect",
                            str(args.preselect),
                            "--ranking-mode",
                            args.ranking_mode,
                        ],
                        project,
                    )
                calibration_features.append(str(features))
            run(
                [
                    sys.executable,
                    "scripts/fit_retrieval_gate_and_calibrate.py",
                    "--calibration",
                    *calibration_features,
                    "--test",
                    str(test_features),
                    "--output",
                    str(gated),
                ],
                project,
            )
            metrics = json.loads((gated / "metrics.json").read_text(encoding="utf-8"))
            if split_template is None:
                split_template = destination
            for group, values in metrics["groups"].items():
                metrics_rows.append(
                    {
                        "split": split_dir.name,
                        "seed": run_dir.name.removeprefix("seed_"),
                        "group": group,
                        **values,
                    }
                )
            if not args.skip_summary:
                pd.DataFrame(metrics_rows).to_csv(output_root / "summary.csv", index=False)
    if args.skip_summary:
        print(f"retrieval worker complete: {len(metrics_rows) // 4} model runs")
        return
    summary = pd.DataFrame(metrics_rows)
    summary.to_csv(output_root / "summary.csv", index=False)
    aggregate = (
        summary.groupby("group")
        .agg(
            runs=("seed", "count"),
            mcc_mean=("mcc", "mean"),
            mcc_std=("mcc", "std"),
            pr_auc_mean=("pr_auc", "mean"),
            pr_auc_std=("pr_auc", "std"),
            brier_mean=("brier", "mean"),
            ece_mean=("ece_15", "mean"),
        )
        .reset_index()
    )
    aggregate.to_csv(output_root / "aggregate.csv", index=False)
    print(f"retrieval matrix complete: {len(summary) // 4} model runs")


if __name__ == "__main__":
    main()
