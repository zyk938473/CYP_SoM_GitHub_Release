from __future__ import annotations

import argparse
import json
import os
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

from cyp_som.reliability import reaction_weights, weighted_metrics

IDENTITY_BINS = [-0.001, 0.2, 0.4, 0.6, 0.8, 1.001]
MOLECULE_BINS = [-0.001, 0.3, 0.5, 0.7, 0.9, 1.001]


def reaction_loss(frame: pd.DataFrame, probability: str) -> pd.Series:
    score = np.clip(frame[probability].to_numpy(dtype=float), 1e-7, 1 - 1e-7)
    loss = -(frame["label"].to_numpy() * np.log(score) + (1 - frame["label"]) * np.log1p(-score))
    return pd.Series(loss, index=frame.index).groupby(frame["reaction_id"]).mean()


def macro_metrics(frame: pd.DataFrame) -> dict[str, float]:
    values = []
    top1 = []
    for _, group in frame.groupby("reaction_id", sort=False):
        if group["label"].nunique() == 2:
            values.append(average_precision_score(group["label"], group["calibrated_probability"]))
        top1.append(int(group.loc[group["calibrated_probability"].idxmax(), "label"] == 1))
    return {
        "reaction_macro_pr_auc": float(np.mean(values)) if values else float("nan"),
        "reaction_top1": float(np.mean(top1)),
    }


def risk_coverage(frame: pd.DataFrame, ranking: str) -> list[dict[str, float]]:
    data = frame.copy()
    confidence = 2 * np.abs(data["calibrated_probability"].to_numpy() - 0.5)
    reliability = data["gate_reliability"].to_numpy()
    if ranking == "confidence":
        data["rank_score"] = confidence
    elif ranking == "reliability":
        data["rank_score"] = reliability
    else:
        data["rank_score"] = confidence * reliability
    reaction_rank = data.groupby("reaction_id")["rank_score"].mean().sort_values(ascending=False)
    rows = []
    for coverage in np.linspace(0.1, 1.0, 10):
        keep = set(reaction_rank.head(max(1, round(len(reaction_rank) * coverage))).index)
        selected = data[data["reaction_id"].isin(keep)]
        weights = reaction_weights(selected["reaction_id"])
        metrics = weighted_metrics(
            selected["label"],
            selected["calibrated_probability"],
            weights,
            float(selected["threshold"].iloc[0]),
        )
        rows.append({"ranking": ranking, "coverage": coverage, "reactions": len(keep), **metrics})
    return rows


def analyze_run(arguments: tuple[str, str, str]) -> tuple[list[dict], list[dict], list[dict]]:
    model, path_value, split_path_value = arguments
    path = Path(path_value)
    split_path = Path(split_path_value)
    prediction = pd.read_parquet(path / "test_predictions.parquet")
    metadata = pd.read_parquet(split_path)[
        ["reaction_id", "protein_cluster", "scaffold", "evidence_tier", "sequence_hash"]
    ]
    prediction = prediction.merge(metadata, on="reaction_id", how="left", validate="many_to_one")
    metric_rows = []
    bin_rows = []
    risk_rows = []
    for (variant, group), frame in prediction.groupby(["variant", "benchmark_group"], sort=False):
        weights = reaction_weights(frame["reaction_id"])
        metrics = weighted_metrics(
            frame["label"],
            frame["calibrated_probability"],
            weights,
            float(frame["threshold"].iloc[0]),
        )
        metric_rows.append(
            {
                "model": model,
                "split": path.parent.name,
                "seed": path.name.removeprefix("seed_"),
                "variant": variant,
                "group": group,
                **metrics,
                **macro_metrics(frame),
            }
        )
        if variant == "R4_joint":
            frame = frame.copy()
            frame["identity_bin"] = pd.cut(
                frame["retrieval_max_sequence_identity"], IDENTITY_BINS, right=False
            ).astype(str)
            frame["molecule_bin"] = pd.cut(
                frame["retrieval_max_molecule_similarity"], MOLECULE_BINS, right=False
            ).astype(str)
            for (identity_bin, molecule_bin), subset in frame.groupby(
                ["identity_bin", "molecule_bin"], observed=True
            ):
                if subset["reaction_id"].nunique() < 3:
                    continue
                subset_weights = reaction_weights(subset["reaction_id"])
                bin_rows.append(
                    {
                        "model": model,
                        "split": path.parent.name,
                        "seed": path.name.removeprefix("seed_"),
                        "group": group,
                        "identity_bin": identity_bin,
                        "molecule_bin": molecule_bin,
                        "reactions": subset["reaction_id"].nunique(),
                        "protein_clusters": subset["protein_cluster"].nunique(),
                        "scaffolds": subset["scaffold"].nunique(),
                        "mean_reliability": subset["gate_reliability"].mean(),
                        **weighted_metrics(
                            subset["label"],
                            subset["calibrated_probability"],
                            subset_weights,
                            float(subset["threshold"].iloc[0]),
                        ),
                    }
                )
            for ranking in ["confidence", "reliability", "combined"]:
                for row in risk_coverage(frame, ranking):
                    risk_rows.append(
                        {
                            "model": model,
                            "split": path.parent.name,
                            "seed": path.name.removeprefix("seed_"),
                            "group": group,
                            **row,
                        }
                    )
    return metric_rows, bin_rows, risk_rows


def negative_transfer(root: Path) -> pd.DataFrame:
    rows = []
    for path in root.glob("*/outer_*/seed_*/test_predictions.parquet"):
        data = pd.read_parquet(path)
        base = data[data["variant"].eq("R0_base")]
        joint = data[data["variant"].eq("R4_joint")]
        base_loss = reaction_loss(base, "calibrated_probability")
        joint_loss = reaction_loss(joint, "calibrated_probability")
        delta = (joint_loss - base_loss).sort_values()
        for rank_type, selected in [("benefit", delta.head(3)), ("harm", delta.tail(3))]:
            for reaction_id, value in selected.items():
                record = joint[joint["reaction_id"].eq(reaction_id)].iloc[0]
                rows.append(
                    {
                        "model": path.parents[2].name,
                        "split": path.parents[1].name,
                        "seed": path.parent.name.removeprefix("seed_"),
                        "reaction_id": reaction_id,
                        "rank_type": rank_type,
                        "delta_logloss": value,
                        "group": record["benchmark_group"],
                        "sequence_identity": record["retrieval_max_sequence_identity"],
                        "molecule_similarity": record["retrieval_max_molecule_similarity"],
                        "mcs_coverage": record["retrieval_max_mcs_coverage"],
                        "effective_neighbors": record["retrieval_effective_neighbors"],
                        "reliability": record["gate_reliability"],
                    }
                )
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage10a", required=True)
    parser.add_argument("--splits", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--workers", type=int, default=max(1, min(8, (os.cpu_count() or 2) // 2)))
    args = parser.parse_args()
    root = Path(args.stage10a)
    jobs = []
    for path in root.glob("*/outer_*/seed_*/metrics.json"):
        model = path.parents[2].name
        split = path.parents[1].name
        jobs.append(
            (
                model,
                str(path.parent),
                str(Path(args.splits) / split / "reaction_splits.parquet"),
            )
        )
    metric_rows, bin_rows, risk_rows = [], [], []
    with ProcessPoolExecutor(max_workers=min(args.workers, len(jobs))) as pool:
        for metrics, bins, risks in pool.map(analyze_run, jobs):
            metric_rows.extend(metrics)
            bin_rows.extend(bins)
            risk_rows.extend(risks)
    target = Path(args.output)
    target.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(metric_rows).to_csv(target / "reaction_weighted_metrics.csv", index=False)
    pd.DataFrame(bin_rows).to_csv(target / "applicability_bins.csv", index=False)
    pd.DataFrame(risk_rows).to_csv(target / "risk_coverage.csv", index=False)
    negative_transfer(root).to_csv(target / "negative_transfer_cases.csv", index=False)
    manifest = {
        "runs": len(jobs),
        "weighting": "each reaction has equal total weight",
        "applicability_bins": {
            "identity": IDENTITY_BINS,
            "molecule_similarity": MOLECULE_BINS,
        },
        "bootstrap": "implemented separately to preserve cluster-level paired sampling",
    }
    (target / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
