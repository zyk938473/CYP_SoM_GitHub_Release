from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
from rdkit import Chem

from cyp_som.sites import build_site_context, canonicalize_bond_site
from cyp_som.utils import stable_id


def values(series: pd.Series) -> list[str]:
    return sorted({str(value) for value in series if pd.notna(value) and str(value)})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidates", required=True)
    parser.add_argument("--existing-reactions", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    candidates = pd.read_parquet(args.candidates)
    existing = pd.read_parquet(args.existing_reactions)
    existing_pairs = set(existing["pair_id"])

    reaction_rows = []
    bond_frames = []
    exclusions = []
    for pair_id, group in candidates.groupby("pair_id", sort=True):
        first = group.iloc[0]
        positive_sites = sorted(
            {site for encoded in group["canonical_site_keys"] for site in json.loads(encoded)}
        )
        smiles = first["canonical_smiles"]
        molecule = Chem.MolFromSmiles(smiles)
        if molecule is None:
            exclusions.append({"pair_id": pair_id, "reason": "INVALID_CANONICAL_SMILES"})
            continue
        explicit = Chem.AddHs(molecule)
        context = build_site_context(smiles)
        available = set()
        rows = []
        for bond in explicit.GetBonds():
            begin, end = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
            try:
                site = canonicalize_bond_site(context, begin, end)
                key, error = site.key, ""
            except (ValueError, IndexError) as exc:
                key, error = "", str(exc)
            available.add(key)
            rows.append(
                {
                    "protein_name": first["protein_name"],
                    "protein_seq": first["protein_sequence"],
                    "protein_pocket": "",
                    "protein_SRS": "",
                    "molecule": smiles,
                    "bond_type": float(bond.GetBondTypeAsDouble()),
                    "bond_idx": bond.GetIdx(),
                    "atom1_type": explicit.GetAtomWithIdx(begin).GetSymbol(),
                    "atom2_type": explicit.GetAtomWithIdx(end).GetSymbol(),
                    "atom1_idx": begin,
                    "atom2_idx": end,
                    "label": int(key in positive_sites),
                    "sequence_hash": first["sequence_hash"],
                    "canonical_smiles": smiles,
                    "inchikey": first["inchikey"],
                    "scaffold": first["scaffold"],
                    "pair_id": pair_id,
                    "canonical_site_key": key,
                    "site_mapping_error": error,
                    "curation_endpoint": "ANY_OBSERVED_SITE_UNION",
                    "source": "Rhea_UniProt_reviewed_v1",
                }
            )
        missing = set(positive_sites) - available
        if missing:
            exclusions.append(
                {
                    "pair_id": pair_id,
                    "reason": "POSITIVE_SITE_NOT_REPRESENTABLE",
                    "missing_sites": json.dumps(sorted(missing)),
                }
            )
            continue
        reaction_id = stable_id(pair_id, "rhea_uniprot_reviewed_v1", prefix="curated_")
        bond_frame = pd.DataFrame(rows)
        bond_frame["reaction_id"] = reaction_id
        bond_frames.append(bond_frame)
        reaction_rows.append(
            {
                "reaction_id": reaction_id,
                "pair_id": pair_id,
                "source": "Rhea_UniProt_reviewed_v1",
                "protein_name": first["protein_name"],
                "sequence_hash": first["sequence_hash"],
                "protein_sequence": first["protein_sequence"],
                "protein_pocket": "",
                "protein_srs": "",
                "canonical_smiles": smiles,
                "inchikey": first["inchikey"],
                "scaffold": first["scaffold"],
                "canonical_positive_sites": json.dumps(positive_sites),
                "source_record_count": len(group),
                "rhea_ids": json.dumps(sorted(group["RHEA_ID"].astype(int).unique().tolist())),
                "rhea_master_ids": json.dumps(
                    sorted(group["MASTER_ID"].astype(int).unique().tolist())
                ),
                "uniprot_ids": json.dumps(values(group["uniprot_id"])),
                "organism_names": json.dumps(values(group["organism_name"]), ensure_ascii=False),
                "product_smiles": json.dumps(values(group["product_smiles"])),
                "candidate_bond_count": len(bond_frame),
                "positive_bond_count": int(bond_frame["label"].sum()),
                "curation_endpoint": "ANY_OBSERVED_SITE_UNION",
                "atom_mapping_ok": True,
                "overlaps_existing_pair": pair_id in existing_pairs,
                "evidence_tier": "CURATED_DATABASE",
                "redistribution_status": "RHEA_CC_BY_4_0_UNIPROT_TERMS",
            }
        )

    reactions = pd.DataFrame(reaction_rows)
    bonds = pd.concat(bond_frames, ignore_index=True)
    excluded = pd.DataFrame(exclusions)
    reactions.to_parquet(output / "reactions.parquet", index=False)
    reactions.to_csv(output / "reactions.csv", index=False)
    bonds.to_parquet(output / "candidate_bonds.parquet", index=False)
    excluded.to_csv(output / "excluded_pairs.csv", index=False)
    novel = reactions[~reactions["overlaps_existing_pair"]]
    summary = {
        "site_key_version": 3,
        "source": "Rhea directed reactions + reviewed UniProt PF00067 proteins",
        "curated_pairs": len(reactions),
        "candidate_bonds": len(bonds),
        "positive_bonds": int(bonds["label"].sum()),
        "excluded_pairs": len(excluded),
        "novel_pairs_vs_expanded_v1": len(novel),
        "novel_sequences_vs_expanded_v1": int(
            novel.loc[
                ~novel["sequence_hash"].isin(existing["sequence_hash"]), "sequence_hash"
            ].nunique()
        ),
        "overlap_validation": "97.9% of high-confidence overlapping source rows are identical or a subset of existing any-site labels; 97.5% after pair aggregation.",
        "license": "Rhea CC BY 4.0; UniProt terms apply.",
        "evidence_limitation": "Primary-paper citations are not attached at reaction-row level; treat as curated-database tier until targeted provenance enrichment.",
    }
    (output / "manifest.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
