from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
from rdkit import Chem

from cyp_som.sites import build_site_context, canonicalize_bond_site
from cyp_som.utils import stable_id


def clean_values(series: pd.Series) -> list[str]:
    return sorted(
        {
            str(value).strip()
            for value in series
            if pd.notna(value) and str(value).strip() not in {"", "/", "nan"}
        }
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit", required=True)
    parser.add_argument("--cypmol-reactions", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    audit = pd.read_parquet(args.audit)
    cypmol = pd.read_parquet(args.cypmol_reactions)
    cypmol_pairs = set(cypmol["pair_id"])
    audit["site_count"] = audit["canonical_site_keys"].map(lambda value: len(json.loads(value)))
    high = audit[
        audit["candidate_for_existing_bond_benchmark"]
        & audit["mapping_coverage"].eq(1.0)
        & audit["site_count"].eq(1)
        & audit["edit_count"].isin([1, 3])
        & audit["reaction"].eq("Oxidation")
        & audit[["PMID", "DOI", "Patent ID"]].notna().any(axis=1)
    ].copy()

    reaction_rows = []
    bond_frames = []
    exclusions = []
    for pair_id, group in high.groupby("pair_id", sort=True):
        first = group.iloc[0]
        positive_sites = sorted(
            {site for encoded in group["canonical_site_keys"] for site in json.loads(encoded)}
        )
        smiles = first["canonical_smiles"]
        molecule = Chem.MolFromSmiles(smiles)
        if molecule is None:
            exclusions.append({"pair_id": pair_id, "reason": "CANONICAL_SMILES_PARSE_FAILED"})
            continue
        explicit = Chem.AddHs(molecule)
        context = build_site_context(smiles)
        candidate_rows = []
        candidate_site_keys = set()
        for bond in explicit.GetBonds():
            begin, end = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
            try:
                site = canonicalize_bond_site(context, begin, end)
                site_key = site.key
                error = ""
            except (ValueError, IndexError) as exc:
                site_key = ""
                error = str(exc)
            candidate_site_keys.add(site_key)
            candidate_rows.append(
                {
                    "protein_name": f"Cytochrome P450 {first['Symbol']}",
                    "protein_seq": first["sequence"],
                    "protein_pocket": "",
                    "protein_SRS": "",
                    "molecule": smiles,
                    "bond_type": float(bond.GetBondTypeAsDouble()),
                    "bond_idx": bond.GetIdx(),
                    "atom1_type": explicit.GetAtomWithIdx(begin).GetSymbol(),
                    "atom2_type": explicit.GetAtomWithIdx(end).GetSymbol(),
                    "atom1_idx": begin,
                    "atom2_idx": end,
                    "reaction_site": json.dumps(positive_sites),
                    "dataset_type": "unassigned",
                    "label": int(site_key in positive_sites),
                    "source": "P450Rdb_v2_high_confidence_v1",
                    "source_row": int(first["source_row"]),
                    "sequence_hash": first["sequence_hash"],
                    "canonical_smiles": smiles,
                    "inchikey": first["inchikey"],
                    "scaffold": first["scaffold"],
                    "standard_atom1_idx": begin if begin < molecule.GetNumAtoms() else None,
                    "standard_atom2_idx": end if end < molecule.GetNumAtoms() else None,
                    "atom_mapping_ok": not error,
                    "pair_id": pair_id,
                    "canonical_site_key": site_key,
                    "site_mapping_error": error,
                    "original_label": int(site_key in positive_sites),
                    "source_reaction_id": first["source_reaction_id"],
                    "curation_endpoint": "ANY_OBSERVED_SITE_UNION",
                }
            )
        missing = set(positive_sites) - candidate_site_keys
        if missing:
            exclusions.append(
                {
                    "pair_id": pair_id,
                    "reason": "POSITIVE_SITE_NOT_REPRESENTABLE_ON_CANONICAL_GRAPH",
                    "missing_sites": json.dumps(sorted(missing)),
                }
            )
            continue
        reaction_id = stable_id(pair_id, "p450rdb_v2_high_confidence_v1", prefix="curated_")
        bond_frame = pd.DataFrame(candidate_rows)
        bond_frame["reaction_id"] = reaction_id
        bond_frames.append(bond_frame)
        reaction_rows.append(
            {
                "reaction_id": reaction_id,
                "pair_id": pair_id,
                "source": "P450Rdb_v2_high_confidence_v1",
                "protein_name": f"Cytochrome P450 {first['Symbol']}",
                "sequence_hash": first["sequence_hash"],
                "protein_sequence": first["sequence"],
                "protein_pocket": "",
                "protein_srs": "",
                "canonical_smiles": smiles,
                "inchikey": first["inchikey"],
                "scaffold": first["scaffold"],
                "canonical_positive_sites": json.dumps(positive_sites),
                "source_reaction_ids": json.dumps(clean_values(group["source_reaction_id"])),
                "source_rows": json.dumps(sorted(group["source_row"].astype(int).tolist())),
                "source_reaction_count": len(group),
                "products": json.dumps(clean_values(group["Product1"]), ensure_ascii=False),
                "product_smiles": json.dumps(clean_values(group["pro_Smiles1"])),
                "pmids": json.dumps(clean_values(group["PMID"])),
                "dois": json.dumps(clean_values(group["DOI"])),
                "patent_ids": json.dumps(clean_values(group["Patent ID"])),
                "titles": json.dumps(clean_values(group["Title"]), ensure_ascii=False),
                "species_name": first["Species name"],
                "species_category": first["Species"],
                "uniprot_id": first["Uniprot ID"],
                "candidate_bond_count": len(bond_frame),
                "positive_bond_count": int(bond_frame["label"].sum()),
                "curation_endpoint": "ANY_OBSERVED_SITE_UNION",
                "atom_mapping_ok": True,
                "overlaps_cypmol_pair": pair_id in cypmol_pairs,
                "redistribution_status": "RESTRICTED_PROVIDER_TERMS_NO_ROW_REDISTRIBUTION",
            }
        )

    reactions = pd.DataFrame(reaction_rows)
    bonds = pd.concat(bond_frames, ignore_index=True)
    exclusions_frame = pd.DataFrame(exclusions)
    reactions.to_parquet(output / "reactions.parquet", index=False)
    reactions.to_csv(output / "reactions.csv", index=False)
    bonds.to_parquet(output / "candidate_bonds.parquet", index=False)
    exclusions_frame.to_csv(output / "excluded_pairs.csv", index=False)
    novel = reactions[~reactions["overlaps_cypmol_pair"]]
    summary = {
        "site_key_version": 3,
        "selection_rule": "MAPPED; coverage=1; one canonical site per source row; edit_count in {1,3}; Oxidation; PMID/DOI/patent present. Edit-count 3 primarily captures one-bond epoxidation and has 95.8% overlap/subset validation against CYPMol.",
        "selected_source_rows": len(high),
        "curated_pairs": len(reactions),
        "candidate_bonds": len(bonds),
        "positive_bonds": int(bonds["label"].sum()),
        "excluded_pairs": len(exclusions_frame),
        "novel_pairs_vs_cypmol": len(novel),
        "novel_sequences_vs_cypmol": int(
            novel.loc[
                ~novel["sequence_hash"].isin(cypmol["sequence_hash"]), "sequence_hash"
            ].nunique()
        ),
        "novel_pair_species_categories": novel["species_category"].value_counts().to_dict(),
        "license_note": "P450Rdb v2 records are provider-governed. Apply the provider terms and applicable written permission; do not redistribute row-level records in this repository.",
    }
    (output / "manifest.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
