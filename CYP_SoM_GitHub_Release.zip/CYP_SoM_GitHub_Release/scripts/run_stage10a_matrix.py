from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import pandas as pd


def execute_job(job: tuple[list[str], str]) -> str:
    command, output = job
    environment = os.environ.copy()
    environment.update(
        {
            "OMP_NUM_THREADS": "1",
            "MKL_NUM_THREADS": "1",
            "OPENBLAS_NUM_THREADS": "1",
            "NUMEXPR_NUM_THREADS": "1",
        }
    )
    subprocess.run(command, check=True, env=environment)
    return output


def collect(root: Path) -> pd.DataFrame:
    rows = []
    for path in root.glob("*/outer_*/seed_*/metrics.json"):
        payload = json.loads(path.read_text(encoding="utf-8"))
        model = path.parents[2].name
        split = path.parents[1].name
        seed = path.parent.name.removeprefix("seed_")
        for variant, values in payload["variants"].items():
            for group, metrics in values["groups"].items():
                rows.append(
                    {
                        "model": model,
                        "split": split,
                        "seed": seed,
                        "variant": variant,
                        "group": group,
                        **metrics,
                    }
                )
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--molecule-features", required=True)
    parser.add_argument("--global-features", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--workers", type=int, default=max(1, min(8, (os.cpu_count() or 2) // 2)))
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    target = Path(args.output)
    jobs = []
    for model, source in [
        ("molecule", Path(args.molecule_features)),
        ("global", Path(args.global_features)),
    ]:
        for run in sorted(source.glob("outer_*/seed_*/")):
            output = target / model / run.parent.name / run.name
            if (output / "metrics.json").is_file() and not args.force:
                continue
            calibration = [
                str(run / f"inner_fold_{fold}" / "retrieval_features.parquet") for fold in range(3)
            ]
            if not all(Path(path).is_file() for path in calibration):
                raise FileNotFoundError(f"Incomplete inner features: {run}")
            command = [
                sys.executable,
                "scripts/fit_joint_reliability_gate.py",
                "--calibration",
                *calibration,
                "--test",
                str(run / "test_retrieval_features.parquet"),
                "--output",
                str(output),
            ]
            jobs.append((command, str(output)))
    target.mkdir(parents=True, exist_ok=True)
    if jobs:
        with ProcessPoolExecutor(max_workers=min(args.workers, len(jobs))) as pool:
            futures = [pool.submit(execute_job, job) for job in jobs]
            for index, future in enumerate(as_completed(futures), start=1):
                print(f"completed {index}/{len(futures)}: {future.result()}", flush=True)
                summary = collect(target)
                summary.to_csv(target / "summary.partial.csv", index=False)
    summary = collect(target)
    summary.to_csv(target / "summary.csv", index=False)
    aggregate = (
        summary.groupby(["model", "variant", "group"])
        .agg(
            runs=("seed", "count"),
            mcc_mean=("mcc", "mean"),
            mcc_std=("mcc", "std"),
            pr_auc_mean=("pr_auc", "mean"),
            pr_auc_std=("pr_auc", "std"),
            weighted_mcc_mean=("weighted_mcc", "mean"),
            weighted_pr_auc_mean=("weighted_pr_auc", "mean"),
            weighted_brier_mean=("weighted_brier", "mean"),
            weighted_ece_mean=("weighted_ece_15", "mean"),
        )
        .reset_index()
    )
    aggregate.to_csv(target / "aggregate.csv", index=False)
    print(f"Stage 10A complete: {len(summary)} metric rows")


if __name__ == "__main__":
    main()
