from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
from rdkit import Chem

from cyp_som.sites import build_site_context, canonicalize_bond_site
from cyp_som.utils import stable_id


def decoded_union(values: pd.Series) -> list[str]:
    return sorted({item for value in values for item in json.loads(value)})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cypmol-reactions", required=True)
    parser.add_argument("--p450rdb-reactions", required=True)
    parser.add_argument("--rhea-reactions")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)

    cypmol = pd.read_parquet(args.cypmol_reactions).copy()
    p450rdb = pd.read_parquet(args.p450rdb_reactions).copy()
    cypmol["source_dataset"] = "CYPMol_any_site_v1"
    p450rdb["source_dataset"] = "P450Rdb_v2_high_confidence_v1"
    sources = [cypmol, p450rdb]
    if args.rhea_reactions:
        rhea = pd.read_parquet(args.rhea_reactions).copy()
        rhea["source_dataset"] = "Rhea_UniProt_reviewed_v1"
        sources.append(rhea)
    combined = pd.concat(sources, ignore_index=True, sort=False)

    reactions = []
    bond_frames = []
    exclusions = []
    for pair_id, group in combined.groupby("pair_id", sort=True):
        preferred = group[group["source_dataset"] == "CYPMol_any_site_v1"]
        first = (preferred if not preferred.empty else group).iloc[0]
        positive_sites = decoded_union(group["canonical_positive_sites"])
        smiles = first["canonical_smiles"]
        molecule = Chem.MolFromSmiles(smiles)
        if molecule is None:
            exclusions.append({"pair_id": pair_id, "reason": "CANONICAL_SMILES_PARSE_FAILED"})
            continue
        explicit = Chem.AddHs(molecule)
        context = build_site_context(smiles)
        candidates = []
        available = set()
        for bond in explicit.GetBonds():
            begin, end = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
            try:
                site = canonicalize_bond_site(context, begin, end)
                site_key, error = site.key, ""
            except (ValueError, IndexError) as exc:
                site_key, error = "", str(exc)
            available.add(site_key)
            candidates.append(
                {
                    "protein_name": first["protein_name"],
                    "protein_seq": first["protein_sequence"],
                    "protein_pocket": first.get("protein_pocket", ""),
                    "protein_SRS": first.get("protein_srs", ""),
                    "molecule": smiles,
                    "bond_type": float(bond.GetBondTypeAsDouble()),
                    "bond_idx": bond.GetIdx(),
                    "atom1_type": explicit.GetAtomWithIdx(begin).GetSymbol(),
                    "atom2_type": explicit.GetAtomWithIdx(end).GetSymbol(),
                    "atom1_idx": begin,
                    "atom2_idx": end,
                    "label": int(site_key in positive_sites),
                    "sequence_hash": first["sequence_hash"],
                    "canonical_smiles": smiles,
                    "inchikey": first["inchikey"],
                    "scaffold": first["scaffold"],
                    "pair_id": pair_id,
                    "canonical_site_key": site_key,
                    "site_mapping_error": error,
                    "atom_mapping_ok": not error,
                    "curation_endpoint": "ANY_OBSERVED_SITE_UNION",
                }
            )
        missing = set(positive_sites) - available
        if missing:
            exclusions.append(
                {
                    "pair_id": pair_id,
                    "reason": "POSITIVE_SITE_NOT_REPRESENTABLE_ON_CANONICAL_GRAPH",
                    "missing_sites": json.dumps(sorted(missing)),
                }
            )
            continue
        reaction_id = stable_id(pair_id, "expanded_benchmark_v1", prefix="curated_")
        bonds = pd.DataFrame(candidates)
        bonds["reaction_id"] = reaction_id
        bond_frames.append(bonds)
        datasets = sorted(group["source_dataset"].unique())
        reactions.append(
            {
                "reaction_id": reaction_id,
                "pair_id": pair_id,
                "source": "+".join(datasets),
                "source_datasets": json.dumps(datasets),
                "protein_name": first["protein_name"],
                "sequence_hash": first["sequence_hash"],
                "protein_sequence": first["protein_sequence"],
                "protein_pocket": first.get("protein_pocket", ""),
                "protein_srs": first.get("protein_srs", ""),
                "canonical_smiles": smiles,
                "inchikey": first["inchikey"],
                "scaffold": first["scaffold"],
                "canonical_positive_sites": json.dumps(positive_sites),
                "source_record_count": len(group),
                "candidate_bond_count": len(bonds),
                "positive_bond_count": int(bonds["label"].sum()),
                "curation_endpoint": "ANY_OBSERVED_SITE_UNION",
                "atom_mapping_ok": True,
                "contains_p450rdb_data": "P450Rdb_v2_high_confidence_v1" in datasets,
                "evidence_tier": (
                    "LITERATURE_LINKED_CURATED"
                    if "P450Rdb_v2_high_confidence_v1" in datasets
                    else (
                        "CURATED_DATABASE"
                        if "Rhea_UniProt_reviewed_v1" in datasets
                        else "SOURCE_DATASET_UNTRACED"
                    )
                ),
                "redistribution_status": (
                    "RESTRICTED_PROVIDER_TERMS_NO_ROW_REDISTRIBUTION"
                    if "P450Rdb_v2_high_confidence_v1" in datasets
                    else (
                        "RHEA_CC_BY_4_0_UNIPROT_TERMS"
                        if "Rhea_UniProt_reviewed_v1" in datasets
                        else "FOLLOW_CYPMOL_SOURCE_TERMS"
                    )
                ),
            }
        )

    reaction_frame = pd.DataFrame(reactions)
    bond_frame = pd.concat(bond_frames, ignore_index=True)
    exclusion_frame = pd.DataFrame(exclusions)
    reaction_frame.to_parquet(output / "reactions.parquet", index=False)
    reaction_frame.to_csv(output / "reactions.csv", index=False)
    bond_frame.to_parquet(output / "candidate_bonds.parquet", index=False)
    exclusion_frame.to_csv(output / "excluded_pairs.csv", index=False)

    source_combinations = reaction_frame["source"].value_counts().to_dict()
    manifest = {
        "version": output.name,
        "status": "INTERMEDIATE_MERGED_BENCHMARK_OUTPUT",
        "endpoint": "ANY_OBSERVED_SITE_UNION",
        "site_key_version": 3,
        "reactions": len(reaction_frame),
        "sequences": int(reaction_frame["sequence_hash"].nunique()),
        "molecules": int(reaction_frame["inchikey"].nunique()),
        "scaffolds": int(reaction_frame["scaffold"].nunique()),
        "candidate_bonds": len(bond_frame),
        "positive_bonds": int(bond_frame["label"].sum()),
        "source_combinations": source_combinations,
        "excluded_pairs": len(exclusion_frame),
        "redistribution_warning": "Contains P450Rdb-derived rows. Do not redistribute merged row-level tables; apply provider terms and written permission.",
    }
    (output / "manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
