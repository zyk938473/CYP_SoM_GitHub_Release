from __future__ import annotations

import argparse
import hashlib
import json
import random
from pathlib import Path

import numpy as np
import pandas as pd

from cyp_som.gnn import build_bond_centered_gnn, require_torch
from cyp_som.graph_data import load_bond_samples_for_reactions
from cyp_som.metrics import best_mcc_threshold, binary_metrics
from cyp_som.training import (
    group_by_reaction,
    predict_reactions,
    select_epoch_on_inner_fold,
    train_epochs,
)

TEST_GROUPS = ("G00_control", "G01_protein_ood", "G10_scaffold_ood", "G11_double_ood")


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch, _ = require_torch()
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def load_embeddings(path: str | Path) -> dict[str, np.ndarray]:
    payload = np.load(path, allow_pickle=False)
    return {
        str(key): value.astype(np.float32)
        for key, value in zip(payload["sequence_hash"], payload["embedding"])
    }


def make_control_embeddings(
    embeddings: dict[str, np.ndarray],
    pool_hashes: set[str],
    target_hashes: set[str],
    mode: str,
    seed: int,
) -> dict[str, np.ndarray]:
    if mode == "correct":
        return embeddings
    pool = sorted(pool_hashes & set(embeddings))
    if not pool:
        raise ValueError("Protein-control embedding pool is empty")
    if mode == "mean":
        mean = np.mean([embeddings[key] for key in pool], axis=0).astype(np.float32)
        return {key: mean for key in target_hashes}
    if mode == "permuted":
        output = {}
        for key in target_hashes:
            digest = hashlib.sha256(f"{seed}:{key}".encode()).digest()
            source = pool[int.from_bytes(digest[:8], "little") % len(pool)]
            output[key] = embeddings[source]
        return output
    raise ValueError(f"Unknown protein control: {mode}")


def positive_weight(groups) -> float:
    labels = [sample.label for group in groups for sample in group]
    positives = sum(labels)
    return (len(labels) - positives) / max(positives, 1)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Train an interaction-capable global ESM-2 conditioned bond GNN"
    )
    parser.add_argument("--bonds", required=True)
    parser.add_argument("--reactions", required=True)
    parser.add_argument("--embeddings", required=True)
    parser.add_argument("--splits", required=True)
    parser.add_argument("--inner-folds", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--model-name", default="GLOBAL_ESM2_FILM_BOND_GNN")
    parser.add_argument("--allow-missing-embeddings", action="store_true")
    parser.add_argument(
        "--protein-control", choices=["correct", "mean", "permuted"], default="correct"
    )
    parser.add_argument("--seed", type=int, default=20260829)
    parser.add_argument("--max-epochs", type=int, default=40)
    parser.add_argument("--patience", type=int, default=6)
    parser.add_argument("--lr", type=float, default=2e-3)
    args = parser.parse_args()
    torch, _ = require_torch()
    seed_everything(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    embeddings = load_embeddings(args.embeddings)
    protein_dim = len(next(iter(embeddings.values())))
    reactions = pd.read_parquet(args.reactions)[["reaction_id", "sequence_hash"]]
    reaction_to_sequence = dict(zip(reactions["reaction_id"], reactions["sequence_hash"]))
    missing = set(reaction_to_sequence.values()) - set(embeddings)
    if missing and not args.allow_missing_embeddings:
        raise ValueError(f"Missing ESM embeddings for {len(missing)} protein sequences")
    available_reactions = {
        reaction_id
        for reaction_id, sequence_hash in reaction_to_sequence.items()
        if sequence_hash in embeddings
    }

    split = pd.read_parquet(args.splits)
    outer_train_ids = (
        set(split.loc[split["benchmark_group"].eq("train"), "reaction_id"]) & available_reactions
    )
    outer_train_groups = group_by_reaction(
        load_bond_samples_for_reactions(args.bonds, outer_train_ids)
    )
    inner = pd.read_parquet(args.inner_folds)
    selected_epochs: list[int] = []
    inner_records = []
    oof_truth: list[np.ndarray] = []
    oof_scores: list[np.ndarray] = []
    oof_frames: list[pd.DataFrame] = []
    for fold in sorted(inner["inner_fold"].unique()):
        frame = inner[inner["inner_fold"].eq(fold)]
        train_ids = (
            set(frame.loc[frame["inner_role"].eq("train"), "reaction_id"]) & available_reactions
        )
        validation_ids = (
            set(frame.loc[frame["inner_role"].eq("validation"), "reaction_id"])
            & available_reactions
        )
        if train_ids & validation_ids or not train_ids or not validation_ids:
            raise ValueError(f"Invalid inner fold {fold}")
        train_groups = group_by_reaction(load_bond_samples_for_reactions(args.bonds, train_ids))
        validation_groups = group_by_reaction(
            load_bond_samples_for_reactions(args.bonds, validation_ids)
        )
        fold_embeddings = make_control_embeddings(
            embeddings,
            {reaction_to_sequence[value] for value in train_ids},
            {reaction_to_sequence[value] for value in train_ids | validation_ids},
            args.protein_control,
            args.seed + int(fold),
        )
        seed_everything(args.seed + int(fold))
        model = build_bond_centered_gnn(protein_dim=protein_dim).to(device)
        epoch, _, truth, scores, identifiers = select_epoch_on_inner_fold(
            model,
            train_groups,
            validation_groups,
            device,
            args.max_epochs,
            args.lr,
            positive_weight(train_groups),
            args.patience,
            fold_embeddings,
            reaction_to_sequence,
        )
        selected_epochs.append(epoch)
        oof_truth.append(truth)
        oof_scores.append(scores)
        oof_frame = pd.DataFrame(identifiers, columns=["reaction_id", "bond_idx"])
        oof_frame["label"] = truth
        oof_frame["global_esm2_probability"] = scores
        oof_frame["inner_fold"] = int(fold)
        oof_frames.append(oof_frame)
        inner_records.append(
            {
                "fold": int(fold),
                "selected_epoch": epoch,
                "validation_pr_auc": binary_metrics(truth, scores)["pr_auc"],
                "validation_reactions": len(validation_groups),
            }
        )
    threshold, threshold_mcc = best_mcc_threshold(
        np.concatenate(oof_truth), np.concatenate(oof_scores)
    )
    final_epochs = max(1, round(float(np.median(selected_epochs))))
    final_embeddings = make_control_embeddings(
        embeddings,
        {reaction_to_sequence[value] for value in outer_train_ids},
        {reaction_to_sequence[value] for value in available_reactions},
        args.protein_control,
        args.seed,
    )
    seed_everything(args.seed)
    model = build_bond_centered_gnn(protein_dim=protein_dim).to(device)
    train_epochs(
        model,
        outer_train_groups,
        device,
        final_epochs,
        args.lr,
        positive_weight(outer_train_groups),
        final_embeddings,
        reaction_to_sequence,
    )
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), output / "global_esm2_film_gnn.pt")
    pd.concat(oof_frames, ignore_index=True).to_parquet(
        output / "inner_oof_predictions.parquet", index=False
    )
    metrics = {
        "protocol_status": "FORMAL_INNER_FOLD_SELECTED",
        "model": args.model_name,
        "seed": args.seed,
        "device": str(device),
        "protein_dim": protein_dim,
        "protein_control": args.protein_control,
        "selected_final_epochs": final_epochs,
        "inner_folds": inner_records,
        "train_reactions": len(outer_train_groups),
        "threshold": threshold,
        "threshold_oof_mcc": threshold_mcc,
        "groups": {},
    }
    for group in TEST_GROUPS:
        group_ids = (
            set(split.loc[split["benchmark_group"].eq(group), "reaction_id"]) & available_reactions
        )
        if not group_ids:
            metrics["groups"][group] = {"status": "NO_EMBEDDING_SUPPORTED_REACTIONS"}
            continue
        groups = group_by_reaction(load_bond_samples_for_reactions(args.bonds, group_ids))
        truth, scores, identifiers = predict_reactions(
            model, groups, device, final_embeddings, reaction_to_sequence
        )
        metrics["groups"][group] = binary_metrics(truth, scores, threshold)
        prediction = pd.DataFrame(identifiers, columns=["reaction_id", "bond_idx"])
        prediction["label"] = truth
        prediction["global_esm2_probability"] = scores
        prediction["benchmark_group"] = group
        prediction.to_parquet(output / f"{group}_predictions.parquet", index=False)
    (output / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
