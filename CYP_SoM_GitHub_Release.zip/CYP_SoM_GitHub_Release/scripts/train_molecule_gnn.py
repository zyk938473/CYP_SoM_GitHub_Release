from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import numpy as np
import pandas as pd

from cyp_som.gnn import build_bond_centered_gnn, require_torch
from cyp_som.graph_data import load_bond_samples, load_bond_samples_for_reactions
from cyp_som.metrics import best_mcc_threshold, binary_metrics
from cyp_som.training import (
    group_by_reaction,
    predict_reactions,
    select_epoch_on_inner_fold,
    train_epochs,
)

TEST_GROUPS = ("G00_control", "G01_protein_ood", "G10_scaffold_ood", "G11_double_ood")


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch, _ = require_torch()
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def positive_weight(groups) -> float:
    labels = [sample.label for group in groups for sample in group]
    positives = sum(labels)
    return (len(labels) - positives) / max(positives, 1)


def main() -> None:
    parser = argparse.ArgumentParser(description="Train a reaction-weighted molecule-only GNN")
    parser.add_argument("--bonds", required=True)
    parser.add_argument("--splits", required=True)
    parser.add_argument("--inner-folds")
    parser.add_argument("--output", required=True)
    parser.add_argument("--seed", type=int, default=20260829)
    parser.add_argument("--max-epochs", type=int, default=40)
    parser.add_argument("--patience", type=int, default=6)
    parser.add_argument("--lr", type=float, default=2e-3)
    parser.add_argument("--max-train-reactions", type=int, default=0)
    args = parser.parse_args()
    torch, _ = require_torch()
    seed_everything(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    split = pd.read_parquet(args.splits)
    outer_train_ids = set(split.loc[split["benchmark_group"].eq("train"), "reaction_id"])
    if args.max_train_reactions:
        outer_train_ids = set(sorted(outer_train_ids)[: args.max_train_reactions])
    outer_train_groups = group_by_reaction(
        load_bond_samples_for_reactions(args.bonds, outer_train_ids)
    )

    selected_epochs: list[int] = []
    inner_records: list[dict[str, float | int]] = []
    oof_truth: list[np.ndarray] = []
    oof_scores: list[np.ndarray] = []
    oof_frames: list[pd.DataFrame] = []
    if args.inner_folds and not args.max_train_reactions:
        inner = pd.read_parquet(args.inner_folds)
        for fold in sorted(inner["inner_fold"].unique()):
            frame = inner[inner["inner_fold"].eq(fold)]
            train_ids = set(frame.loc[frame["inner_role"].eq("train"), "reaction_id"])
            validation_ids = set(frame.loc[frame["inner_role"].eq("validation"), "reaction_id"])
            if train_ids & validation_ids or not train_ids or not validation_ids:
                raise ValueError(f"Invalid inner fold {fold}")
            train_groups = group_by_reaction(load_bond_samples_for_reactions(args.bonds, train_ids))
            validation_groups = group_by_reaction(
                load_bond_samples_for_reactions(args.bonds, validation_ids)
            )
            seed_everything(args.seed + int(fold))
            model = build_bond_centered_gnn().to(device)
            epoch, _, truth, scores, identifiers = select_epoch_on_inner_fold(
                model,
                train_groups,
                validation_groups,
                device,
                args.max_epochs,
                args.lr,
                positive_weight(train_groups),
                args.patience,
            )
            selected_epochs.append(epoch)
            oof_truth.append(truth)
            oof_scores.append(scores)
            oof_frame = pd.DataFrame(identifiers, columns=["reaction_id", "bond_idx"])
            oof_frame["label"] = truth
            oof_frame["molecule_only_probability"] = scores
            oof_frame["inner_fold"] = int(fold)
            oof_frames.append(oof_frame)
            inner_records.append(
                {
                    "fold": int(fold),
                    "selected_epoch": epoch,
                    "validation_pr_auc": binary_metrics(truth, scores)["pr_auc"],
                    "validation_reactions": len(validation_groups),
                }
            )
        threshold, threshold_mcc = best_mcc_threshold(
            np.concatenate(oof_truth), np.concatenate(oof_scores)
        )
        final_epochs = max(1, round(float(np.median(selected_epochs))))
        protocol_status = "FORMAL_INNER_FOLD_SELECTED"
    else:
        validation_groups = group_by_reaction(
            load_bond_samples(args.bonds, args.splits, "V00_control")
        )
        seed_everything(args.seed)
        temporary = build_bond_centered_gnn().to(device)
        final_epochs, _, truth, scores, _ = select_epoch_on_inner_fold(
            temporary,
            outer_train_groups,
            validation_groups,
            device,
            min(args.max_epochs, 5) if args.max_train_reactions else args.max_epochs,
            args.lr,
            positive_weight(outer_train_groups),
            args.patience,
        )
        threshold, threshold_mcc = best_mcc_threshold(truth, scores)
        protocol_status = "NON_HEADLINE_INNER_VALIDATION_RUN"

    seed_everything(args.seed)
    model = build_bond_centered_gnn().to(device)
    train_epochs(
        model,
        outer_train_groups,
        device,
        final_epochs,
        args.lr,
        positive_weight(outer_train_groups),
    )
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), output / "molecule_gnn.pt")
    if oof_frames:
        pd.concat(oof_frames, ignore_index=True).to_parquet(
            output / "inner_oof_predictions.parquet", index=False
        )
    metrics = {
        "protocol_status": protocol_status,
        "seed": args.seed,
        "device": str(device),
        "selected_final_epochs": final_epochs,
        "inner_folds": inner_records,
        "train_reactions": len(outer_train_groups),
        "threshold": threshold,
        "threshold_oof_mcc": threshold_mcc,
        "groups": {},
    }
    for group in TEST_GROUPS:
        groups = group_by_reaction(load_bond_samples(args.bonds, args.splits, group))
        truth, scores, identifiers = predict_reactions(model, groups, device)
        metrics["groups"][group] = binary_metrics(truth, scores, threshold)
        prediction = pd.DataFrame(identifiers, columns=["reaction_id", "bond_idx"])
        prediction["label"] = truth
        prediction["molecule_only_probability"] = scores
        prediction["benchmark_group"] = group
        prediction.to_parquet(output / f"{group}_predictions.parquet", index=False)
    (output / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
