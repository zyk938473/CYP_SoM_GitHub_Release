from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import pandas as pd


def collect_completed(root: Path) -> pd.DataFrame:
    rows = []
    for metrics_path in root.glob("outer_*/seed_*/metrics.json"):
        metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
        for group, values in metrics["groups"].items():
            rows.append(
                {
                    "split": metrics_path.parents[1].name,
                    "seed": metrics["seed"],
                    "protocol_status": metrics["protocol_status"],
                    "selected_final_epochs": metrics["selected_final_epochs"],
                    "group": group,
                    **values,
                }
            )
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bonds", required=True)
    parser.add_argument("--splits", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=[20260829, 20260830, 20260831, 20260832, 20260833],
    )
    parser.add_argument("--max-epochs", type=int, default=40)
    parser.add_argument("--patience", type=int, default=6)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    root = Path(args.output)
    root.mkdir(parents=True, exist_ok=True)
    split_dirs = sorted(Path(args.splits).glob("outer_*/"))
    if len(split_dirs) != 5:
        raise ValueError(f"Expected exactly five frozen outer splits, found {len(split_dirs)}")
    for split_dir in split_dirs:
        inner = split_dir / "inner_cluster_folds.parquet"
        if not inner.is_file():
            raise FileNotFoundError(f"Missing train-derived inner folds: {inner}")
        for seed in args.seeds:
            run = root / split_dir.name / f"seed_{seed}"
            metrics_path = run / "metrics.json"
            if metrics_path.is_file() and not args.force:
                print(f"skip completed {split_dir.name} seed={seed}", flush=True)
                continue
            command = [
                sys.executable,
                "scripts/train_molecule_gnn.py",
                "--bonds",
                args.bonds,
                "--splits",
                str(split_dir / "reaction_splits.parquet"),
                "--inner-folds",
                str(inner),
                "--output",
                str(run),
                "--seed",
                str(seed),
                "--max-epochs",
                str(args.max_epochs),
                "--patience",
                str(args.patience),
            ]
            subprocess.run(command, check=True, cwd=Path(__file__).resolve().parents[1])
            completed = collect_completed(root)
            completed.to_csv(root / "summary.csv", index=False)
            print(
                f"completed {split_dir.name} seed={seed}; total runs={len(completed) // 4}",
                flush=True,
            )
    summary = collect_completed(root)
    summary.to_csv(root / "summary.csv", index=False)
    aggregate = (
        summary.groupby("group")
        .agg(
            runs=("seed", "count"),
            mcc_mean=("mcc", "mean"),
            mcc_std=("mcc", "std"),
            pr_auc_mean=("pr_auc", "mean"),
            pr_auc_std=("pr_auc", "std"),
            brier_mean=("brier", "mean"),
            ece_mean=("ece_15", "mean"),
        )
        .reset_index()
    )
    aggregate.to_csv(root / "aggregate.csv", index=False)
    print(f"matrix complete: {len(summary) // 4} runs")


if __name__ == "__main__":
    main()
