from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pandas as pd


def collect(root: Path) -> pd.DataFrame:
    rows = []
    for path in root.glob("outer_*/seed_*/metrics.json"):
        metrics = json.loads(path.read_text(encoding="utf-8"))
        for group, values in metrics["groups"].items():
            rows.append(
                {
                    "split": path.parents[1].name,
                    "seed": metrics["seed"],
                    "model": metrics["model"],
                    "protein_control": metrics.get("protein_control", "correct"),
                    "group": group,
                    **values,
                }
            )
    return pd.DataFrame(rows)


def execute(command: list[str]) -> str:
    environment = os.environ.copy()
    environment.update(
        {
            "OMP_NUM_THREADS": "1",
            "MKL_NUM_THREADS": "1",
            "PYTORCH_CUDA_ALLOC_CONF": "expandable_segments:True",
        }
    )
    output = Path(command[command.index("--output") + 1])
    output.mkdir(parents=True, exist_ok=True)
    with (output / "training.log").open("w", encoding="utf-8") as handle:
        subprocess.run(
            command,
            check=True,
            cwd=Path(__file__).resolve().parents[1],
            env=environment,
            stdout=handle,
            stderr=subprocess.STDOUT,
        )
    return str(output)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bonds", required=True)
    parser.add_argument("--reactions", required=True)
    parser.add_argument("--embeddings", required=True)
    parser.add_argument("--splits", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=[20260829, 20260830, 20260831, 20260832, 20260833],
    )
    parser.add_argument("--max-epochs", type=int, default=40)
    parser.add_argument("--patience", type=int, default=6)
    parser.add_argument(
        "--protein-control", choices=["correct", "mean", "permuted"], default="correct"
    )
    parser.add_argument("--parallel-runs", type=int, default=1)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    root = Path(args.output)
    root.mkdir(parents=True, exist_ok=True)
    split_dirs = sorted(Path(args.splits).glob("outer_*/"))
    if len(split_dirs) != 5:
        raise ValueError(f"Expected five frozen outer splits, found {len(split_dirs)}")
    jobs = []
    for split_dir in split_dirs:
        for seed in args.seeds:
            run = root / split_dir.name / f"seed_{seed}"
            if (run / "metrics.json").is_file() and not args.force:
                continue
            jobs.append(
                [
                    sys.executable,
                    "scripts/train_global_protein_model.py",
                    "--bonds",
                    args.bonds,
                    "--reactions",
                    args.reactions,
                    "--embeddings",
                    args.embeddings,
                    "--splits",
                    str(split_dir / "reaction_splits.parquet"),
                    "--inner-folds",
                    str(split_dir / "inner_cluster_folds.parquet"),
                    "--output",
                    str(run),
                    "--seed",
                    str(seed),
                    "--max-epochs",
                    str(args.max_epochs),
                    "--patience",
                    str(args.patience),
                    "--protein-control",
                    args.protein_control,
                    "--model-name",
                    f"GLOBAL_ESM2_FILM_{args.protein_control.upper()}",
                ]
            )
    if jobs:
        with ThreadPoolExecutor(max_workers=min(args.parallel_runs, len(jobs))) as pool:
            futures = [pool.submit(execute, command) for command in jobs]
            for index, future in enumerate(as_completed(futures), start=1):
                print(f"complete {index}/{len(jobs)}: {future.result()}", flush=True)
                collect(root).to_csv(root / "summary.partial.csv", index=False)
    summary = collect(root)
    summary.to_csv(root / "summary.csv", index=False)
    aggregate = (
        summary.groupby(["protein_control", "group"])
        .agg(
            runs=("seed", "count"),
            mcc_mean=("mcc", "mean"),
            mcc_std=("mcc", "std"),
            pr_auc_mean=("pr_auc", "mean"),
            pr_auc_std=("pr_auc", "std"),
            brier_mean=("brier", "mean"),
            ece_mean=("ece_15", "mean"),
        )
        .reset_index()
    )
    aggregate.to_csv(root / "aggregate.csv", index=False)
    print(f"matrix complete: {len(summary) // 4} runs")


if __name__ == "__main__":
    main()
