from __future__ import annotations

import argparse
import json
import shutil
import tempfile
from pathlib import Path

import pandas as pd

from cyp_som.splits import build_dual_ood_split


def jaccard_distance(left: set[object], right: set[object]) -> float:
    union = left | right
    return 1.0 - len(left & right) / len(union) if union else 0.0


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trials", required=True)
    parser.add_argument("--reactions", required=True)
    parser.add_argument("--identity", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--count", type=int, default=5)
    parser.add_argument("--threshold", type=float, default=0.4)
    args = parser.parse_args()
    output = Path(args.output)
    if output.exists():
        shutil.rmtree(output)
    output.mkdir(parents=True)

    trials = pd.read_csv(args.trials)
    feasible = trials[
        trials["G01_protein_ood_reactions"].ge(30)
        & trials["G01_protein_ood_clusters"].ge(5)
        & trials["G11_double_ood_reactions"].ge(30)
        & trials["G11_double_ood_clusters"].ge(5)
    ].copy()
    if len(feasible) < args.count:
        raise ValueError(f"Only {len(feasible)} support-qualified seeds for {args.count} splits")
    feasible["min_reactions"] = feasible[
        ["G01_protein_ood_reactions", "G11_double_ood_reactions"]
    ].min(axis=1)
    feasible["min_clusters"] = feasible[
        ["G01_protein_ood_clusters", "G11_double_ood_clusters"]
    ].min(axis=1)
    feasible = feasible.sort_values(
        ["min_clusters", "min_reactions", "seed"], ascending=[False, False, True]
    )

    candidates = {}
    with tempfile.TemporaryDirectory(prefix="qualified_outer_") as temporary:
        temporary_path = Path(temporary)
        for row in feasible.itertuples(index=False):
            destination = temporary_path / str(row.seed)
            summary = build_dual_ood_split(
                args.reactions,
                args.identity,
                destination,
                threshold=args.threshold,
                seed=int(row.seed),
            )
            split = pd.read_parquet(destination / "reaction_splits.parquet")
            test = split[split["benchmark_group"].str.startswith("G")]
            protein_ood = split[
                split["benchmark_group"].isin(["G01_protein_ood", "G11_double_ood"])
            ]
            candidates[int(row.seed)] = {
                "path": destination,
                "summary": summary,
                "test_reactions": set(test["reaction_id"]),
                "protein_ood_clusters": set(protein_ood["protein_cluster"]),
                "support": (
                    int(row.min_clusters),
                    int(row.min_reactions),
                    int(row.G01_protein_ood_reactions + row.G11_double_ood_reactions),
                ),
            }

        selected = []
        first_seed = int(feasible.iloc[0]["seed"])
        selected.append(first_seed)
        while len(selected) < args.count:
            best = None
            for seed, candidate in candidates.items():
                if seed in selected:
                    continue
                distances = []
                for chosen_seed in selected:
                    chosen = candidates[chosen_seed]
                    reaction_distance = jaccard_distance(
                        candidate["test_reactions"], chosen["test_reactions"]
                    )
                    cluster_distance = jaccard_distance(
                        candidate["protein_ood_clusters"], chosen["protein_ood_clusters"]
                    )
                    distances.append((reaction_distance + cluster_distance) / 2)
                score = (min(distances), candidate["support"], -seed)
                if best is None or score > best[0]:
                    best = (score, seed)
            assert best is not None
            selected.append(best[1])

        rows = []
        for rank, seed in enumerate(selected, start=1):
            target = output / f"outer_{rank:02d}_seed_{seed}"
            shutil.copytree(candidates[seed]["path"], target)
            summary = candidates[seed]["summary"]
            rows.append(
                {
                    "outer_rank": rank,
                    "seed": seed,
                    "G01_reactions": summary["G01_protein_ood"]["reactions"],
                    "G01_clusters": summary["G01_protein_ood"]["protein_clusters"],
                    "G11_reactions": summary["G11_double_ood"]["reactions"],
                    "G11_clusters": summary["G11_double_ood"]["protein_clusters"],
                    "test_reactions": len(candidates[seed]["test_reactions"]),
                    "protein_ood_clusters": len(candidates[seed]["protein_ood_clusters"]),
                }
            )

    selected_frame = pd.DataFrame(rows)
    selected_frame.to_csv(output / "selected_outer_splits.csv", index=False)
    manifest = {
        "status": "SELECTED_BY_PREDECLARED_RULE",
        "selection_uses_model_performance": False,
        "selection_rule": "Filter by predeclared G01/G11 support gate; rank first split by minimum cell support; greedily maximize test-reaction and protein-OOD-cluster Jaccard distance for remaining splits.",
        "qualified_seed_count": len(feasible),
        "selected_count": len(selected_frame),
        "selected": rows,
        "warning": "Freeze these manifests before any model training. Do not replace them based on model results.",
    }
    (output / "manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
