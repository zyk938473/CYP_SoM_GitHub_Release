from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt

GROUPS = ["G00_control", "G01_protein_ood", "G10_scaffold_ood", "G11_double_ood"]
GROUP_LABELS = ["G00", "G01", "G10", "G11"]


def forest(
    data: pd.DataFrame,
    series_column: str,
    series_order: list[str],
    metric: str,
    title: str,
    output: Path,
) -> None:
    figure, axes = plt.subplots(1, 4, figsize=(11.2, 3.2), sharey=True, constrained_layout=True)
    colors = plt.cm.Set2(np.linspace(0, 1, len(series_order)))
    for axis, group, label in zip(axes, GROUPS, GROUP_LABELS, strict=True):
        frame = data[data["group"].eq(group)].set_index(series_column)
        for index, (series, color) in enumerate(zip(series_order, colors, strict=True)):
            if series not in frame.index:
                continue
            row = frame.loc[series]
            value = row[f"observed_{metric}"]
            low = row[f"{metric}_ci_low"]
            high = row[f"{metric}_ci_high"]
            axis.errorbar(
                value,
                index,
                xerr=[[value - low], [high - value]],
                fmt="o",
                color=color,
                capsize=3,
            )
            direction = (
                row["positive_mcc_splits"]
                if metric == "delta_mcc"
                else row["positive_pr_auc_splits"]
            )
            axis.text(value, index + 0.18, f"{int(direction)}/5 +", fontsize=7, ha="center")
        axis.axvline(0, color="#374151", linewidth=0.8, linestyle="--")
        axis.set_title(label)
        axis.set_xlabel(metric.replace("delta_", "Δ ").replace("_", " ").upper())
        axis.set_yticks(range(len(series_order)), series_order if axis is axes[0] else [])
    figure.suptitle(title)
    figure.savefig(output.with_suffix(".png"), dpi=300, bbox_inches="tight")
    figure.savefig(output.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage11", required=True)
    parser.add_argument("--stage12", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    target = Path(args.output)
    target.mkdir(parents=True, exist_ok=True)
    stage11 = pd.read_csv(Path(args.stage11) / "paired_cluster_summary.csv")
    stage12 = pd.read_csv(Path(args.stage12) / "paired_cluster_summary.csv")
    forest(
        stage11,
        "comparison",
        ["molecule", "mean", "permuted"],
        "delta_mcc",
        "Correct protein pairing versus controls",
        target / "stage11_paired_mcc",
    )
    forest(
        stage11,
        "comparison",
        ["molecule", "mean", "permuted"],
        "delta_pr_auc",
        "Correct protein pairing versus controls",
        target / "stage11_paired_pr_auc",
    )
    forest(
        stage12,
        "model",
        ["molecule", "global"],
        "delta_mcc",
        "Joint versus molecule-only retrieval ranking",
        target / "stage12_ranking_mcc",
    )
    forest(
        stage12,
        "model",
        ["molecule", "global"],
        "delta_pr_auc",
        "Joint versus molecule-only retrieval ranking",
        target / "stage12_ranking_pr_auc",
    )
    print("Paired-statistics figures complete")


if __name__ == "__main__":
    main()
